These files (LGPL.txt, CDDL.txt, MIT-LICENSE.txt) are the license mentioned in
the source headers.

Most of the code in the Nuxeo EP project is copyright Nuxeo SA and
contributors, and licensed under the LGPL.

A few files have been reused from other open source projects, under the other
licenses listed here (CDDL, MIT).

When reusing code dual licensed under the GPL and another license, we choose
NOT to use the GPL, but the other license.

