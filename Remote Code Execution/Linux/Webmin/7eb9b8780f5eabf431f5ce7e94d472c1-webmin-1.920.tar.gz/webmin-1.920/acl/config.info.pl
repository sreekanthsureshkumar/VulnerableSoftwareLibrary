line1=Opcje konfiguracyjne,11
display=Tryb wy�wietlania u�ytkownik�w i grup,1,1-Tylko nazwy,0-Nazwy i modu�y
order=Porz�dkuj u�ytkownik�w i grupy wg,1,0-Kolejno�ci w zbiorze,1-Nazwy
line2=Konfiguracja systemu,11
ssleay=�cie�ka do programu openssl lub ssleay,0
