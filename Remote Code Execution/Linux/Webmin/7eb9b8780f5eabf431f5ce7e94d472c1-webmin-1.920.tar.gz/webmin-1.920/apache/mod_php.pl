# mod_php.pl
# Placeholder for mod_php directives

sub mod_php_directives
{
return ();
}

1;
