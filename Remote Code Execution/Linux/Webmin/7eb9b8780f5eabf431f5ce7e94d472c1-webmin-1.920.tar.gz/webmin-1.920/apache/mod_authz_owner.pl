# mod_authz_owner.pl
# This file only exists so that Webmin knows the module is installed

sub mod_authz_owner_directives
{
return ();
}


