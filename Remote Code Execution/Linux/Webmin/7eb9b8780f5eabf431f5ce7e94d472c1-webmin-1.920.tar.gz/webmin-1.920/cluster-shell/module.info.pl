desc_pl=Klaster - Polecenia pow�oki (Shell)
longdesc_pl=Uruchamiaj polecenia na wielu serwerach r�wnocze�nie.
