fstab_file=Plik zawiraj�cy list� system�w plik�w montowanych przy starcie,0
auto_file=Plik automatycznych montowa� po NFS,3
autofs_file=Plik automatycznych montowa� kernela,3
long_fstypes=U�ywaj d�ugich nazw typ�w system�w plik�w,1,1-Tak,0-Nie
smbclient_path=Pe�na �cie�ka do programu <tt>smbclient</tt>,3
nmblookup_path=Pe�na �cie�ka do programu <tt>nmblookup</tt>,3
browse_server=Serwer, z&nbsp;kt�rego pobierana jest <tt>browse list</tt>,3,localhost
