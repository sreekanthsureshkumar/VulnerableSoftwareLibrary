#!/bin/bash
pylint superset --errors-only
