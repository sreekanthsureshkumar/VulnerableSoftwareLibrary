Gallery
=======

.. image:: _static/img/viz_thumbnails/line.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/bubble.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/table.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/pie.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/bar.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/world_map.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/sankey.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/word_cloud.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/filter_box.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/pivot_table.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/directed_force.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/compare.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/sunburst.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/area.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/big_number.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/big_number_total.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/bullet.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/dist_bar.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/heatmap.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/markup.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/para.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/iframe.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/box_plot.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/treemap.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/cal_heatmap.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/horizon.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/mapbox.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/separator.png
   :scale: 25 %

.. image:: _static/img/viz_thumbnails/histogram.png
   :scale: 25 %
