Folder containing the sphinx-generated documentation
