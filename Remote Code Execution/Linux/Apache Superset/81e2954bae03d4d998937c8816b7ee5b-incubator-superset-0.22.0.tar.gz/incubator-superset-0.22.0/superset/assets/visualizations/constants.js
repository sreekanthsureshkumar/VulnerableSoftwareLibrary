export const TIME_CHOICES = [
  '1 hour ago',
  '12 hours ago',
  '1 day ago',
  '7 days ago',
  '28 days ago',
  '90 days ago',
  '1 year ago',
];

