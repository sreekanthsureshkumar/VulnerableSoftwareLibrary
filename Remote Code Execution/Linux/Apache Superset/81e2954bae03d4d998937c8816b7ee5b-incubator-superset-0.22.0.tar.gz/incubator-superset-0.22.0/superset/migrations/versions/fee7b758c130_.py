"""empty message

Revision ID: fee7b758c130
Revises: ('1d2ddd543133', '763d4b211ec9')
Create Date: 2016-03-26 15:09:43.583114

"""

# revision identifiers, used by Alembic.
revision = 'fee7b758c130'
down_revision = ('1d2ddd543133', '763d4b211ec9')


def upgrade():
    pass


def downgrade():
    pass
