"""empty message

Revision ID: ef8843b41dac
Revises: ('3b626e2a6783', 'ab3d66c4246e')
Create Date: 2016-10-02 10:35:38.825231

"""

# revision identifiers, used by Alembic.
revision = 'ef8843b41dac'
down_revision = ('3b626e2a6783', 'ab3d66c4246e')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
