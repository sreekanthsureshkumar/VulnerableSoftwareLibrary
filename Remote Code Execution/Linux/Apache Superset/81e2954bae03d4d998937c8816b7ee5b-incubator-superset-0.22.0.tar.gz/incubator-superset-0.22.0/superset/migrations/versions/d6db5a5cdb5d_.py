"""empty message

Revision ID: d6db5a5cdb5d
Revises: ('a99f2f7c195a', 'bcf3126872fc')
Create Date: 2017-02-10 17:58:20.149960

"""

# revision identifiers, used by Alembic.
revision = 'd6db5a5cdb5d'
down_revision = ('a99f2f7c195a', 'bcf3126872fc')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
