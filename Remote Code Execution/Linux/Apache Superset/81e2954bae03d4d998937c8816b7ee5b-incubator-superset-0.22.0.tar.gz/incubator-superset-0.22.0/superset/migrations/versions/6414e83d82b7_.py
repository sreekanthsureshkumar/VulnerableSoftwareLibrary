"""empty message

Revision ID: 6414e83d82b7
Revises: ('525c854f0005', 'f1f2d4af5b90')
Create Date: 2016-12-19 09:57:05.814013

"""

# revision identifiers, used by Alembic.
revision = '6414e83d82b7'
down_revision = ('525c854f0005', 'f1f2d4af5b90')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
