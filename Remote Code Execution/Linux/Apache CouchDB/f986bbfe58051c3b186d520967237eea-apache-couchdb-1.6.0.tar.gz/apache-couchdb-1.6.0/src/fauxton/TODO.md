# Fauxton todo
In no particular order

- [ ] docco docs
- [ ] user management
- [ ] view options
- [ ] view editor
- [ ] visual view builder
- [ ] new db as modal
- [ ] new view button
- [ ] show design docs only
- [ ] fix delete doc button UI bug
- [ ] delete multiple docs via _bulk_docs
- [x] show change events in database view
- [ ] pouchdb addon
- [ ] bespoke bootstrap style
- [ ] responsive interface
- [ ] sticky subnav for some UI components on _all_docs
- [ ] "show me" button in API bar doesn't
- [ ] edit index button doesn't
- [ ] replicate UI
- [x] delete database
- [x] format dates better (e.g. in logs plugin)
- [ ] format log entry better
- [ ] filter logs by method
- [ ] restore unfiltered data in logs UI
