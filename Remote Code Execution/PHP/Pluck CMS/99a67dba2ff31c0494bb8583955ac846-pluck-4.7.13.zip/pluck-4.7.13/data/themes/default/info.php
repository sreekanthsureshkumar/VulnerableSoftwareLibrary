<?php
//This is the default theme of pluck: "gTheme"
//Theme Made by: Kristaps, http://www.fyfi.net
//You can find pluck at http://www.pluck-cms.org

$themedir = 'default';
$themename = 'Default';
$module_space[0] = 'main';
$module_space[1] = 'footer';
