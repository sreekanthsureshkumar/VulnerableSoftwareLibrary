<?php
$lang['contactform']['module_name'] = 'yhteyslomake';
$lang['contactform']['module_intro'] = 'yhteyslomakkeella voi antaa vierailijoillesi mahdollisuuden lähettää sinulle viestin';
$lang['contactform']['fields'] = 'Et antanut tarvittavia tietoja oikein.';
$lang['contactform']['email_title'] = 'Viesti sivustolta';
$lang['contactform']['been_send'] = 'Viestisi on lähetetty onnistuneesti.';
$lang['contactform']['not_send'] = 'Viestiäsi ei voida lähettää, tapahtui virhe.';
?>