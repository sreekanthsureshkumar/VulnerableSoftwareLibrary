<?php
$lang['contactform']['module_name'] = 'contact form';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields'] = 'Nezadali ste všetky políčka správne.';
$lang['contactform']['email_title'] = 'Správa z Vašej stránky od';
$lang['contactform']['been_send'] = 'Vaša správa bola úspešne odoslaná';
$lang['contactform']['not_send'] = 'Vaša správa nemôže byť odoslaná, nastala chyba.';
?>