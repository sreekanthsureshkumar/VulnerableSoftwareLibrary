<?php
$lang['contactform']['module_name'] = 'טופס יצירת קשר';
$lang['contactform']['module_intro'] = 'עם טופס יצירת הקשר, תוכל לאפשר לגולשים לשלוח לך הודעות';
$lang['contactform']['fields'] = 'לא מילאת את כל השדות באופן תקין.';
$lang['contactform']['email_title'] = 'הודעה מאתרך מאת';
$lang['contactform']['been_send'] = 'ההודעה נשלחה בהצלחה.';
$lang['contactform']['not_send'] = 'ההודעה לא נשלחה, ארעה שגיאה.';
?>