<?php
$lang['contactform']['module_name'] = 'Kontakt-Formular';
$lang['contactform']['module_intro'] = 'Mit dem Kontakt-Formular ermöglichen Sie Ihren Besuchern, Ihnen Nachrichten zu schicken.';
$lang['contactform']['fields'] = 'Sie haben nicht alle Eingabefelder korrekt ausgefüllt.';
$lang['contactform']['email_title'] = 'Eine Nachricht zu Ihrer Webseite von';
$lang['contactform']['been_send'] = 'Ihre Nachricht wurde erfolgreich verschickt.';
$lang['contactform']['not_send'] = 'Ihre Nachricht konnte nicht verschickt werden, weil ein Fehler aufgetreten ist.';
?>