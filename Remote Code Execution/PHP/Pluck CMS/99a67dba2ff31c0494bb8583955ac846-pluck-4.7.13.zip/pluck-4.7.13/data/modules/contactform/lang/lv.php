<?php
$lang['contactform']['module_name'] = 'contact form';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields'] = 'You didn\'t fill in all fields correctly.';
$lang['contactform']['email_title'] = 'Jauns ziņojums no Jūsu mājas lapas';
$lang['contactform']['been_send'] = 'Ziņojums tika veiksmīgi nosūtīts.';
$lang['contactform']['not_send'] = 'Kļūda: ziņojums nevar tikt nosūtīts.';
?>