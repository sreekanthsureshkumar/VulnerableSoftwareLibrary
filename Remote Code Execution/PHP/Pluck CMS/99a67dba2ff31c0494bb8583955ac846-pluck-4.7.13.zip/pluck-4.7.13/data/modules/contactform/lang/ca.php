<?php
$lang['contactform']['module_name'] = 'formulari de contacte';
$lang['contactform']['module_intro'] = 'amb un formulari de contacte, els teus visitants poden enviar-te un missatge';
$lang['contactform']['fields'] = 'No has omplert tots els camps correctament.';
$lang['contactform']['email_title'] = 'Missatge des del teu lloc web de';
$lang['contactform']['been_send'] = 'El teu missatge s\'ha enviat correctament.';
$lang['contactform']['not_send'] = 'Hi ha hagut un error, el missatge no s\'ha enviat.';
?>