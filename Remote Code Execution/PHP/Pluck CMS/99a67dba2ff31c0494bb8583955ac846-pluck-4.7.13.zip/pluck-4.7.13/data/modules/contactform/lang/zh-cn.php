<?php
$lang['contactform']['module_name'] = '联络表格';
$lang['contactform']['module_intro'] = '通过联络表格，你可以让参观者寄讯息给你。';
$lang['contactform']['fields'] = '你并没有正确地输入所有项目。';
$lang['contactform']['email_title'] = '由你网站所来的讯息';
$lang['contactform']['been_send'] = '你的讯息已成功寄出。';
$lang['contactform']['not_send'] = '你的讯息不能寄出：发生错误。';
?>