<?php
$lang['tinymce']['module_name'] = 'tinymce';
$lang['tinymce']['module_intro'] = 'Voegt de TinyMCE-editor toe aan pluck. TinyMCE wordt ontwikkeld door <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a>.';
?>