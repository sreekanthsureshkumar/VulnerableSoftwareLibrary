<?php
$lang['tinymce']['module_name'] = 'tinymce';
$lang['tinymce']['module_intro'] = 'Añade el editor TinyMCE al pluck. TinyMCE ha sido desarrollado por <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a>.';
?>