<?php
$lang['tinymce']['module_name'] = 'tinymce';
$lang['tinymce']['module_intro'] = 'Afegeix l\'editor TinyMCE al pluck. TinyMCE ha estat desenvolupat per  <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a>.';
?>