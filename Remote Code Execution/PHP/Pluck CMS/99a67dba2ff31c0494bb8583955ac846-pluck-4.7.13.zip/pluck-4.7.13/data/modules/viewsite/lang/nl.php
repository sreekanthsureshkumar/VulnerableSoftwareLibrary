<?php
$lang['viewsite']['module_name'] = 'bekijk site link';
$lang['viewsite']['module_intro'] = 'Gemaakt om de hooks te laten zien aan module-ontwikkelaars. Voegt een directe link toe naar de website in het admin menu.';
$lang['viewsite']['message'] = 'bekijk site';
?>