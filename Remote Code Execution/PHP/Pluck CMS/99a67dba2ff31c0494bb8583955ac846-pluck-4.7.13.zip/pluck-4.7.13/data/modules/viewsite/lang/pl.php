<?php
$lang['viewsite']['module_name']	= 'łącze do strony';
$lang['viewsite']['module_intro']	= 'Stworzono by pokazać możliwości "haków". Dodaje bezpośredni link do strony w menu administracyjnym.';
$lang['viewsite']['message']	= 'Podgąd';
?>