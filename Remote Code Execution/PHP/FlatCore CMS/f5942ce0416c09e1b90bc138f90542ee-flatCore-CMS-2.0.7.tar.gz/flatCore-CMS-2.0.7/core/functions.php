<?php

/**
 * include all functions
 */

require 'functions/func_get_content.php';
require 'functions/func_textlib.php';
require 'functions/func_breadcrumbs.php';
require 'functions/func_navigation.php';
require 'functions/func_userdata.php';
require 'functions/func_get_lastedit.php';
require 'functions/func_get_most_clicked.php';
require 'functions/func_get_keywords.php';
require 'functions/func_basics.php';

?>