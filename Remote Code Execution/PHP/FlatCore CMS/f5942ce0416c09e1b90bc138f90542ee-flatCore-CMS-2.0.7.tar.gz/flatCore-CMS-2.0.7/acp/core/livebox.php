<div class="sidebar-footer">
	<?php
		echo '<a href="../">'.$icon['home'].' '.$lang['back_to_page'].'</a>';
		echo '<a href="../index.php?goto=logout">'.$icon['sign_out_alt'].' '.$lang['logout'].'</a>';
	?>
</div>