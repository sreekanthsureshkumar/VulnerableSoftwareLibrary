<?php

//prohibit unauthorized access
require("core/access.php");

$remove_files = array();

/*
$remove_files = array(
'test.html',
'acp/test.html'
);
*/



?>