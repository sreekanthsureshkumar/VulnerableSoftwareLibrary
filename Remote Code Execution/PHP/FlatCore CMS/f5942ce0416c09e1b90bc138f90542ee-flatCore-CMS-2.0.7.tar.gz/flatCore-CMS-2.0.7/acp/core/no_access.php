<?php

echo"<h2>SORRY</h2>";

echo"<hr><p>$lang[drm_no_access]</p>";



?>