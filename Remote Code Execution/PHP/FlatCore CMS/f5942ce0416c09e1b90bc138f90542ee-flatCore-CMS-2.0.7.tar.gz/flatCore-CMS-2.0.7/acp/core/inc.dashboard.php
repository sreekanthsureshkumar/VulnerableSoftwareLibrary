<?php

/*
main page | dashboard
*/

//prohibit unauthorized access
require 'core/access.php';


include 'dashboard.checks.php';
include 'dashboard.top.php';
include 'dashboard.addons.php';
include 'dashboard.system.php';



?>


