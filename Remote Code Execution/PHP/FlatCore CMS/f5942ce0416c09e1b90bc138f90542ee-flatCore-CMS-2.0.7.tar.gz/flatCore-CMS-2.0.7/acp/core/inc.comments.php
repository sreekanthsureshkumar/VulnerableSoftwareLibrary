<?php
//prohibit unauthorized access
require 'core/access.php';


include 'comments.list.php';

?>