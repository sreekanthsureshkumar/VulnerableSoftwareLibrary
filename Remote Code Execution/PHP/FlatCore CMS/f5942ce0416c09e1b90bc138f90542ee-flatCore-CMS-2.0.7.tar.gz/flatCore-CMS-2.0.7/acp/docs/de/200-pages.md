---
navigation: Inhalte
title: 
description:
---

### Seiten und Inhalte ###

Als geordnete Seiten werden die Seiten aufgeführt, welche eine Sortierungsnummer enthalten. Diese Seiten werden automatisch in der Navigation aufgeführt. Die ungeordneten Seiten sind nicht in die Navigation eingegliedert - werden aber dennoch in der Sitemap bzw. den Suchergebnissen berücksichtigt.

Über die Filterfunktion kann die Liste nach Status (Öffentlich, Unsichtbar, Privat, Entwurf) und nach Sprachen gefiltert werden. Zusätzlich kannst du die Liste mit dem Suchfeld filtern.

Außerdem gelangst Du von hier aus noch zu den "Textvorlagen", zum "RSS Feed" und zu "Seiten anpassen".