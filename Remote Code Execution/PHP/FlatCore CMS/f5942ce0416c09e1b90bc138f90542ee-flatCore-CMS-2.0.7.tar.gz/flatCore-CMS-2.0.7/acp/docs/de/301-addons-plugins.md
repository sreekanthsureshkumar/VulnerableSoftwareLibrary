---
navigation: Plugins
title: 
description:
---

### Plugins ###

Als Plugins werden kleine Scripte bezeichnet, welche per Shortcode in die Seiten geladen werden können.