---
navigation: Dateien/Uploads verwalten
title: 
description:
---

### Dateien verwalten ###

Hie siehst Du alle Deine Uploads auf einen Blick und Du kannst den Uploads Daten (wie z.B. Titel, Text, Schlüsselwörter etc.) zuweisen.

Bilder findest Du im Order __/images/__ oder in einem Unterordner davon. Alle diese Bilder erscheinen automatisch im Editor in der Bilder-Auswahl. Zum Beispiel, wenn Du eine Seite anlegst oder bearbeitest.

Alle anderen Dateien solltest Du in den Ordner __/files/__ kopieren.

Eine Auswahl, der verfügbaren Ordner bekommst Du übrigens angezeigt, wenn du - rechts unten - auf den Upload-Buttons klickst.