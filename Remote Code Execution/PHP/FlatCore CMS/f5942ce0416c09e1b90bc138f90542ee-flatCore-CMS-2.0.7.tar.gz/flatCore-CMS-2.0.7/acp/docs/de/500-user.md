---
navigation: Benutzer
title: 
description:
---

### Benutzer ###

Du kannst jederzeit neue Benutzer und Administratoren hinzufügen oder entfernen. Administratoren werden mit einem blauen Benutzersymbol gekennzeichnet.