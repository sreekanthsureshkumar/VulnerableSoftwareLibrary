---
navigation: Inhalte (Seiten)
title: 
description:
---

### Liste filtern ###

Über das Eingabefeld kannst Du die Inhalte der gespeicherten Seiten durchsuchen. Außerdem kannst Du über den *Status*, die *Sprache* und die *Labels* Seiten ein- und ausblenden. Die Labels kannst Du übrigens in den [Einstellungen](acp.php?tn=system) selbst erweitern und ändern.

### geordnete Seiten ###

Als geordnete Seiten werden die Seiten aufgeführt, welche eine Sortierungsnummer enthalten. Diese Seiten werden automatisch in der Navigation aufgeführt. 

### ungeordnete Seiten ###

Die ungeordneten Seiten sind nicht in die Navigation eingegliedert - werden aber dennoch in der Sitemap bzw. den Suchergebnissen berücksichtigt.