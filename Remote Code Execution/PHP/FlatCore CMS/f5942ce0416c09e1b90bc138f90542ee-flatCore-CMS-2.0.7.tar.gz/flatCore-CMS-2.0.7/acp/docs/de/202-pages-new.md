---
navigation: Neue Seiten anlegen
title: 
description:
---

### Neue Seiten erstellen ###

Du kannst beliebig viele Seiten zu deiner Webseite hinzufügen.

#### Position
Hier wählst Du aus, wo die Seite eingeordnet werden soll (Ebene). In der Auswahlliste erscheinen alle Seiten, die Du zuvor einsortiert hast.

#### Reihenfolge
Die Reihenfolge bestimmt die Position, welche die neue Seite auf der geählten Ebene einnimmt.

#### Linkname

#### Hash

#### Permalink

#### Weiterleitungen

##### Kurz-Link
Du kannst für jede Seite Kurz-Links vergeben. Die Anzahl der Klicks auf diesen Kurzlink erkennst Du an der Zahl, rechts neben dem Eingabefeld.

##### Trichter URI

Die Trichter kannst Du verwenden, wenn Du mehrere Seiten zu einer Seite zusammengefasstr hast. Es ist einfacher, die *alten* URLs hier einzutragen, als alle *alten* URLs per 301 Weiterleitung auf die neue Seite zu leiten.

##### Weiterleitung

Falls Du eine Weiterleitung einrichtest, werden alle Aufrufe auf die unter __Permalink__ eingegebene URL auf diese Seite weitergeleitet.