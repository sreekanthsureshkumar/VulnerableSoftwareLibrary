<?php 
redirect($redirect_to, 'location', 301);
?>