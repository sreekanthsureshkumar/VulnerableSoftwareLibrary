<?php

	chdir(substr(__DIR__,0,-5));

	define('IS_CRON',true);
	
//load core
	require('includes/application_core.php');
	
	$backup = new backup();
	
	$backup->create();