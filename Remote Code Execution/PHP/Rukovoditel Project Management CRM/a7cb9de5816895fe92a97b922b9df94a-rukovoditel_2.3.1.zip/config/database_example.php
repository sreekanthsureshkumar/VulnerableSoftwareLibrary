<?php

// define database connection
  define('DB_SERVER', 'localhost'); // eg, localhost - should not be empty for productive servers
  define('DB_SERVER_USERNAME', 'user-name');
  define('DB_SERVER_PASSWORD', 'user-password');
  define('DB_DATABASE', 'database-name');  
  