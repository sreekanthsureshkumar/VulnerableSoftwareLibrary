<h3>Language/Язык</h3>
<p><a href="index.php?step=checking_environment&lng=english"><img src="us.png" bolder="0" style="vertical-align:middle">&nbsp;English</a></p>
<p><a href="index.php?step=checking_environment&lng=russian"><img src="ru.png" bolder="0" style="vertical-align:middle">&nbsp;Русский</a></p>
