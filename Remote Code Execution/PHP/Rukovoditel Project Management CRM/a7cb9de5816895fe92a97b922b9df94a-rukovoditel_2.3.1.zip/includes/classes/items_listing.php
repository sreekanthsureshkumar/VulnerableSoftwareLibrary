<?php

class items_listing
{
  private $fields_in_listing;
  
  private $entities_id;
  
  public $rows_per_page;
  
  public $force_access_query;
  
  public $report_type;
  
  function __construct($reports_id)
  {
    $reports_info = db_find('app_reports',$reports_id);
    
    $this->fields_in_listing = $reports_info['fields_in_listing'];
    
    $this->entities_id = $reports_info['entities_id'];  
    
    $this->rows_per_page = $reports_info['rows_per_page'];
    
    $this->force_access_query = $reports_info['displays_assigned_only'];
    
    $this->report_type = $reports_info['reports_type'];
    
    $this->listing_type = $reports_info['listing_type'];
  }
  
  function get_fields_query()
  {
    if(strlen($this->fields_in_listing)>0)
    {
      $sql = "select f.*,if(length(f.short_name)>0,f.short_name,f.name) as name  from app_fields f where f.id in (" . $this->fields_in_listing . ") and  f.entities_id='" . db_input($this->entities_id) . "' order by field(f.id," . $this->fields_in_listing . ")";  
    }
    else
    {
      $sql = "select f.*,if(length(f.short_name)>0,f.short_name,f.name) as name  from app_fields f where f.listing_status=1 and  f.entities_id='" . db_input($this->entities_id) . "' order by f.listing_sort_order, f.name";
    }
    
    return $sql;
  }
  
  function get_listing_type()
  {  	  	
  	if(is_mobile())
  	{  		
  		if(listing_types::has_mobile($this->entities_id))
  		{  			
  			return 'mobile';
  		}
  	}
  	
  	return (strlen($this->listing_type) ? $this->listing_type : listing_types::get_default($this->entities_id));
  }
  
  function get_listing_type_info($type)
  {
  	$listing_type = [];
  	$sections = [];
  	
  	$listing_type_query = db_query("select * from app_listing_types where entities_id='" . $this->entities_id . "' and type='" . $type . "'");
  	if($listing_type = db_fetch_array($listing_type_query))
  	{
  		$listing_sections_query = db_query("select * from app_listing_sections where listing_types_id={$listing_type['id']} order by sort_order, name");
  		while($listing_sections = db_fetch_array($listing_sections_query))
  		{
  			$choices = [];
  			if(strlen($listing_sections['fields']))
  			{  				
  				$fields_query = db_query("select * from app_fields where id in (" . $listing_sections['fields'] . ") order by field(id," . $listing_sections['fields'] . ")");
  				while($fields = db_fetch_array($fields_query))
  				{
  					$choices[] = $fields;
  				}  				   				
  			}
  			
  			$sections[] = [
  					'name' => $listing_sections['name'],
  					'display_field_names' => $listing_sections['display_field_names'],
  					'display_as' => $listing_sections['display_as'],
  					'width' => $listing_sections['width'],
  					'align' => $listing_sections['text_align'],  					
  					'fields' => $choices,
  			];
  		}
  		
  		$listing_type = [
  				'width' => $listing_type['width'], 
  				'sections' => $sections,
  		];
  	}
  	
  	return $listing_type;
  }
}