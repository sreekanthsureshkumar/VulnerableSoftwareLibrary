<?php
      
	db_dev_log();  
  
