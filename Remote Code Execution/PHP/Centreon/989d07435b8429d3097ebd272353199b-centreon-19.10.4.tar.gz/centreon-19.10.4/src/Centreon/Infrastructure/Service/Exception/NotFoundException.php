<?php

namespace Centreon\Infrastructure\Service\Exception;

use RuntimeException;

class NotFoundException extends RuntimeException
{

}
