<?php

namespace Centreon\Domain\Entity;

class NagiosServer
{

    const TABLE = 'nagios_server';
    const ENTITY_IDENTIFICATOR_COLUMN = 'id';
}
