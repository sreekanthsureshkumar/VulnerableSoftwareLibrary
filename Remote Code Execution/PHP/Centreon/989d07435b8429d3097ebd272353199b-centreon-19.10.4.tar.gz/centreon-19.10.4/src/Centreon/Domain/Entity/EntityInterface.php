<?php

namespace Centreon\Domain\Entity;

interface EntityInterface
{
    public function toArray() : array;
}
