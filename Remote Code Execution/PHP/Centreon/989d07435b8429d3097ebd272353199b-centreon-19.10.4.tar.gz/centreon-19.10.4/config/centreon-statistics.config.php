<?php
// Url where the stats are sent.
const CENTREON_STATS_URL = 'https://statistics.centreon.com';
