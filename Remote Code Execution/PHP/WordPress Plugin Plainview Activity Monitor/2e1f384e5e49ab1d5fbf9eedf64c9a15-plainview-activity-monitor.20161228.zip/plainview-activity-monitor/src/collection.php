<?php

namespace plainview\wordpress\activity_monitor;

/**
	@brief		Base collection class for AM.
	@since		2015-07-25 10:54:34
**/
class collection
	extends \plainview\sdk_pvam\collections\collection
{
}
