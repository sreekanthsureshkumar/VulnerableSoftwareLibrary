<?php

namespace plainview\wordpress\activity_monitor\actions;

use \plainview\sdk_pvam\collections\collection;

/**
	@brief		The Plainview Activity Monitor has finished loading.
	@since		2014-05-09 11:58:26
**/
class loaded
	extends action
{
}
