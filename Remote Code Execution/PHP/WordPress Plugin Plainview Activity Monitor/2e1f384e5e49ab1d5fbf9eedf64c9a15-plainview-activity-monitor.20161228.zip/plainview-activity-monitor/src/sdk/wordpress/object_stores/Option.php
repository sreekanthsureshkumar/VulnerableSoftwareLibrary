<?php

namespace plainview\sdk_pvam\wordpress\object_stores;

/**
	@brief		Master class for storing in options.
	@since		2016-01-02 01:19:06
**/
trait Option
{
	use Store;
}
