<?php

namespace plainview\sdk_pvam\html\exceptions;

class InvalidKeyException extends \Exception
{
}
