<?php

namespace plainview\sdk_pvam\table;

/**
	@brief		Body section of table.
	@since		20130430
	@version	20130430
**/
class body
	extends section
{
	public $tag = 'tbody';
}
