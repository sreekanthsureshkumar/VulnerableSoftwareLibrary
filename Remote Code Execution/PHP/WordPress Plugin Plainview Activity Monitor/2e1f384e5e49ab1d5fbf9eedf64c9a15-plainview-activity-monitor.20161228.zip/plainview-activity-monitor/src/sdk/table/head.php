<?php

namespace plainview\sdk_pvam\table;

/**
	@brief		Head section of table.
	@since		20130430
	@version	20130430
**/
class head
	extends section
{
	public $tag = 'thead';
}
