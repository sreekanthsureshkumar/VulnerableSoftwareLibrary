<?php

$lista_citta = array();
$cod_citta = array();
$cod2_citta = array();
$cod3_citta = array();
$cod_regione_citta = array();

#$lista_citta[0] = "London";
#$cod_citta[0] = "000001";
#$cod_regione_citta[0] = "England";
#$lista_citta[1] = "Glasgow";
#$cod_citta[1] = "000002";
#$cod_regione_citta[1] = "Scotland";


?>