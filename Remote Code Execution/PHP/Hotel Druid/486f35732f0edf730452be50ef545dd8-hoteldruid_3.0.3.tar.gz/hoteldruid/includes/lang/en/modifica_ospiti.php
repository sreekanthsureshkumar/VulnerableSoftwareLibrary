<?php

switch ($messaggio) {

case "Modifica Ospiti":  			$messaggio = "Modify Guests"; break;
case "Modifica gli ospiti della prenotazione":	$messaggio = "Modify guests of reservation"; break;
case "Cliente titolare":  			$messaggio = "Titular client"; break;
case "Ospite della prenotazione":  		$messaggio = "Guest of reservation"; break;
case "nato il":  				$messaggio = "born the"; break;
case "nata il":  				$messaggio = "born the"; break;
case "CAP":  					$messaggio = "postal code"; break;
case "Telefono":  				$messaggio = "Telephone"; break;
case "2º telefono":  				$messaggio = "2nd telephone"; break;
case "3º telefono":  				$messaggio = "3rd telephone"; break;
case "Cognome":  				$messaggio = "Surname"; break;
case "nome":  					$messaggio = "name"; break;
case "sesso":  					$messaggio = "gender"; break;
case "Data di nascita":  			$messaggio = "Birthdate"; break;
case "anno con 4 cifre":  			$messaggio = "year with 4 digits"; break;
case "Documento":  				$messaggio = "Document"; break;
case "scadenza":  				$messaggio = "expiration"; break;
case "Altri ospiti":  				$messaggio = "Other guests"; break;
case "Modifica gli ospiti":  			$messaggio = "Modify guests"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "Gli ospiti della prenotazione":  		$messaggio = "The guests of reservation"; break;
case "sono stati modificati":  			$messaggio = "have been modified"; break;
case "nato":  					$messaggio = "born"; break;
case "nata":  					$messaggio = "born"; break;
case "il":  					$messaggio = "the"; break;
case " a":  					$messaggio = " in"; break;
case "scade":  					$messaggio = "expires"; break;
case "cittadinanza":  				$messaggio = "nationality"; break;
case "città di nascita":  			$messaggio = "city of birth"; break;
case "reg./prov. di nascita":  			$messaggio = "region of birth"; break;
case "nazione di nascita":  			$messaggio = "nation of birth"; break;
case "reg./prov.":  				$messaggio = "region"; break;
case "nazione":  				$messaggio = "nation"; break;
case "Nazione":  				$messaggio = "Nation"; break;
case "rilasciato da":  				$messaggio = "released by"; break;
case "nazione di rilascio":  			$messaggio = "releasing nation"; break;
case "Ospite principale":  			$messaggio = "Main guest"; break;
case "Parentela":  				$messaggio = "Relatedness"; break;
case "parentela":  				$messaggio = "relatedness"; break;
case "Codice fiscale":  			$messaggio = "Fiscal code"; break;
case "città":  					$messaggio = "city"; break;
case "Partita iva":  				$messaggio = "VAT number"; break;
case "Modifica gli ospiti delle prenotazioni":	$messaggio = "Modify guests of reservations"; break;
case "della prenotazione":  			$messaggio = "of reservation"; break;
case "Gli ospiti delle prenotazioni":  		$messaggio = "The guests of reservations"; break;
case "ln.":  					$messaggio = "ln."; break;
case "email":  					$messaggio = "email"; break;
case "2ª email":  				$messaggio = "2nd email"; break;
case "PEC/codice":  				$messaggio = "certified email"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>