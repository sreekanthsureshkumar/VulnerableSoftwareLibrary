<?php

switch ($messaggio) {

case "Torna al menù principale":  		$messaggio = "Back to main menu"; break;
case "Nuovo messaggio a":  			$messaggio = "New message to"; break;
case "da mostrare dopo le":  			$messaggio = "to be shown after"; break;
case "il":  					$messaggio = "the"; break;
case "testo del messaggio":  			$messaggio = "message text"; break;
case "Messaggi":  				$messaggio = "Messages"; break;
case "Spedisci":  				$messaggio = "Send"; break;
case "Messaggio inviato":  			$messaggio = "Message sent"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "N°":  					$messaggio = "N"; break;
case "Mittente":  				$messaggio = "Sender"; break;
case "Testo":  					$messaggio = "Text"; break;
case "Data":  					$messaggio = "Date"; break;
case "Azioni":  				$messaggio = "Actions"; break;
case "Elimina":  				$messaggio = "Delete"; break;
case "Messaggio eliminato":  			$messaggio = "Message deleted"; break;
case "tutti":  					$messaggio = "everybody"; break;
case "SI":  					$messaggio = "YES"; break;
case "Si è sicuri di voler eliminare la richiesta di prenotazione di":	$messaggio = "Are you sure you want to delete the reservation request from"; break;
case "non ancora inserita?":  			$messaggio = "not yet inserted?"; break;
case "Inserisci la prenotazione":  		$messaggio = "Insert the reservation"; break;
case "Visualizza il documento":  		$messaggio = "View document"; break;
case "di tipo":  				$messaggio = "type"; break;
case "Inserito":  				$messaggio = "Inserted"; break;
case "Elimina tutti i messaggi":  		$messaggio = "Delete all messages"; break;
case "Si è sicuri di voler eliminare <div style=\"display: inline; color: red;\"><b>tutti i messaggi</b></div>":	$messaggio = "Are you sure you want to delete <div style=\"display: inline; color: red;\"><b>all messages</b></div>"; break;
case "Messaggi eliminati":  			$messaggio = "Messages deleted"; break;
case "arrivati":  				$messaggio = "arrived"; break;
case "prima del":  				$messaggio = "before"; break;
case "dopo il":  				$messaggio = "after"; break;
case "Scarica messaggi email":  		$messaggio = "Download email messages"; break;
case "Nessun nuovo messaggio":  		$messaggio = "No new message"; break;
case "Nuovi messaggi":  			$messaggio = "New messages"; break;
case "Scaricati":  				$messaggio = "Downloaded"; break;
case "Connessione al server":  			$messaggio = "The connection to server"; break;
case "non riuscita!":  				$messaggio = "was refused!"; break;
case "Controllare i dati immessi in":  		$messaggio = "Check data inserted in"; break;
case "configura e personalizza":  		$messaggio = "configure and customize"; break;
case "Dati ricavati dal messaggio email":  	$messaggio = "Data extracted from email message"; break;
case "Controlla disponibilità":  		$messaggio = "Check availability"; break;
case "Modifica":  				$messaggio = "Modify"; break;
case "Nome":  					$messaggio = "Name"; break;
case "Email":  					$messaggio = "Email"; break;
case "arrivo":  				$messaggio = "arrival"; break;
case "partenza":  				$messaggio = "departure"; break;
case "notti":  					$messaggio = "nights"; break;
case "persone":  				$messaggio = "people"; break;
case "individui":  				$messaggio = "persons"; break;
case "ospiti":  				$messaggio = "guests"; break;
case "adulti":  				$messaggio = "adults"; break;
case "bambini":  				$messaggio = "children"; break;
case "gruppo":  				$messaggio = "party"; break;
case "date":  					$messaggio = "dates"; break;
case "viaggiatori":  				$messaggio = "travelers"; break;
case "periodo":  				$messaggio = "period"; break;
case "Per gli account su gmail potrebbe essere necessario abilitare l'opzione":	$messaggio = "For gmail accounts you may have to enable the option"; break;
case "e/o per una volta usare prima la funzione":	$messaggio = "and/or for once use beforehand the function"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>