<?php

switch ($messaggio) {

case "Tabella Mese":  				$messaggio = "Month Table"; break;
case "situazione alle":  			$messaggio = "situation at"; break;
case "del":  					$messaggio = "of"; break;
case "Tabella prenotazioni del":  		$messaggio = "Reservations table of"; break;
case "ERRORE":  				$messaggio = "ERROR"; break;
case "Torna al menù principale":  		$messaggio = "Back to main menu"; break;
case "Visualizza la tabella per la stampa":  	$messaggio = "View the table for printing"; break;
case "Visualizza la tabella con i giorni":  	$messaggio = "View the table with days"; break;
case "documento di tipo":  			$messaggio = "document type"; break;
case "visualizza":  				$messaggio = "view"; break;
case "Prenotazione non confermata":  		$messaggio = "Reservation not confirmed"; break;
case "Prenotazione confermata, caparra non pagata":	$messaggio = "Reservation confirmed, deposit not paid"; break;
case "Caparra pagata":  			$messaggio = "Deposit paid"; break;
case "Tutto pagato":  				$messaggio = "All paid"; break;
case "durante l'inserimento dei dati del cliente quando si inserisce una nuova prenotazione":	$messaggio = "during the insertion of client data when you insert a new reservation"; break;
case "Utilizzando il tasto 'cancella' dalla pagina di inserimento dei dati del cliente anche questa prenotazione verrà cancellata":	$messaggio = "By using the 'cancel' button from the client data insertion page, this reservation will be cancelled too"; break;
case "L'utente amministratore può disabilitare o cambiare la durata di queste prenotazioni da 'configura e personalizza'":	$messaggio = "The administrator user can disable or change the duration of these reservations from 'configure and customize'"; break;
case "Trascinare l'inizio o la fine di una prenotazione per cambiare la data di arrivo o partenza":	$messaggio = "Drag the beginning or ending of a reservation to change its arrival or departure date"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>