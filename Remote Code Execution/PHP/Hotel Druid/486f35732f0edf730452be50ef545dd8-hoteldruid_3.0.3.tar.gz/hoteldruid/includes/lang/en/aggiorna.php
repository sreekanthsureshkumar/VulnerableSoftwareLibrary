<?php

switch ($messaggio) {

case "Database aggiornato alla versione":  	$messaggio = "Database updated to version"; break;
case "Niente da aggiornare":  			$messaggio = "Nothing to be updated"; break;
case "Vai al menù principale":  		$messaggio = "Go to main menu"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>