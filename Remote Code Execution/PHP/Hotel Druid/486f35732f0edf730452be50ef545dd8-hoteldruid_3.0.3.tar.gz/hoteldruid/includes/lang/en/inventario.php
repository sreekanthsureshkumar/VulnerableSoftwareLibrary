<?php

switch ($messaggio) {

case "Inventario":  				$messaggio = "Inventory"; break;
case "Inventario del magazzino":  		$messaggio = "Inventory of stockroom"; break;
case "Nome bene":  				$messaggio = "Item name"; break;
case "Quantità minima predefinita":  		$messaggio = "Default minimum quantity"; break;
case "Quantità attuale":  			$messaggio = "Current quantity"; break;
case "Nuova quantità":  			$messaggio = "New quantity"; break;
case "Modifica":  				$messaggio = "Modify"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "Modifica le quantità attuali":  		$messaggio = "Modify current quantities"; break;
case "aggiungi":  				$messaggio = "add"; break;
case "cancella":  				$messaggio = "delete"; break;
case "Bene":  					$messaggio = "Item"; break;
case "cancellato":  				$messaggio = "deleted"; break;
case "Quantità aggiornate":  			$messaggio = "Quatities updated"; break;
case "Nuovo bene":  				$messaggio = "New item"; break;
case "aggiunto":  				$messaggio = "added"; break;
case "ricarica":  				$messaggio = "refill"; break;
case "Si è sicuri di voler eliminare il bene":	$messaggio = "Are you sure you want to delete the item"; break;
case "dall'inventario":  			$messaggio = "from inventory"; break;
case "del magazzino":  				$messaggio = "of stockroom"; break;
case "SI":  					$messaggio = "YES"; break;
case "NO":  					$messaggio = "NO"; break;
case "Bene ricaricato":  			$messaggio = "Item refilled"; break;
case "Ricarica il bene":  			$messaggio = "Refill item"; break;
case "da":  					$messaggio = "from"; break;
case "magazzino":  				$messaggio = "stockroom"; break;
case "Nessun posto da cui ricaricare":  	$messaggio = "No refilling place available"; break;
case "mancanti":  				$messaggio = "missing"; break;
case "Continua":  				$messaggio = "Continue"; break;
case "richiesto_per registrare entrata":  	$messaggio = "needed for checkin"; break;
case "si":  					$messaggio = "yes"; break;
case "no":  					$messaggio = "no"; break;
case "Aggiungi":  				$messaggio = "Add"; break;
case "Sottrai":  				$messaggio = "Subtract"; break;
case "crea un <em>costo aggiuntivo</em>":  	$messaggio = "create an <em>extra cost</em>"; break;
case "per il punto vendita":  			$messaggio = "for point of sale"; break;
case "<em>Nome</em> del costo aggiuntivo":  	$messaggio = "<em>Name</em> of the extra cost"; break;
case "Categoria":  				$messaggio = "Category"; break;
case "nuova":  					$messaggio = "new"; break;
case "esistente":  				$messaggio = "existing"; break;
case "<em>Prezzo</em> del costo aggiuntivo":	$messaggio = "<em>Price</em> of the extra cost"; break;
case "Costo aggiuntivo non inserito":  		$messaggio = "Extra cost not inserted"; break;
case "costo già esistente":  			$messaggio = "already existing cost"; break;
case "prezzo sbagliato":  			$messaggio = "wrong price"; break;
case "Attenzione":  				$messaggio = "Warning"; break;
case "esiste già un costo aggiuntivo associato a questo bene in questo magazzino":	$messaggio = "an extra cost linked to this item in this stockroom already exists"; break;
case "Vai a fondo pagina":  			$messaggio = "Go to page bottom"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>