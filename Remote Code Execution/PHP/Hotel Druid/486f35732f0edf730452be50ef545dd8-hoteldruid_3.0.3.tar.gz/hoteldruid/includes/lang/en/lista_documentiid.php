<?php

$lista_documentiid = array();
$cod_documentiid = array();
$cod2_documentiid = array();
$cod3_documentiid = array();

#$lista_documentiid[0] = "Passport";
#$cod_documentiid[0] = "001";
#$lista_documentiid[1] = "National ID";
#$cod_documentiid[1] = "002";

?>