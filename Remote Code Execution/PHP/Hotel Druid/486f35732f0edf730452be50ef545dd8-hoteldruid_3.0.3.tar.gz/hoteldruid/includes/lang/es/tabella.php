<?php

switch ($messaggio) {

case "Tabella Mese":  				$messaggio = "Tabla del Mes"; break;
case "situazione alle":  			$messaggio = "situación a las"; break;
case "del":  					$messaggio = "del"; break;
case "Tabella prenotazioni del":  		$messaggio = "Tabla de reservas del"; break;
case "ERRORE":  				$messaggio = "ERROR"; break;
case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "Visualizza la tabella per la stampa":  	$messaggio = "Ver la tabla para imprimir"; break;
case "Visualizza la tabella con i giorni":  	$messaggio = "Ver la tabla con los días"; break;
case "documento di tipo":  			$messaggio = "documento tipo"; break;
case "visualizza":  				$messaggio = "Ver"; break;
case "Prenotazione non confermata":  		$messaggio = "Reserva no confirmada"; break;
case "Prenotazione confermata, caparra non pagata":	$messaggio = "Reserva confirmada, fianza no pagada"; break;
case "Caparra pagata":  			$messaggio = "Fianza pagada"; break;
case "Tutto pagato":  				$messaggio = "Todo pagado"; break;
case "durante l'inserimento dei dati del cliente quando si inserisce una nuova prenotazione":	$messaggio = "durante la inserción de los datos del cliente cuando se inserta una nueva reserva"; break;
case "Utilizzando il tasto 'cancella' dalla pagina di inserimento dei dati del cliente anche questa prenotazione verrà cancellata":	$messaggio = "Al utilizar el botón 'cancelar' en la página de inserción de los datos del cliente, esta reserva también será cancelada"; break;
case "L'utente amministratore può disabilitare o cambiare la durata di queste prenotazioni da 'configura e personalizza'":	$messaggio = "El usuario administrador puede desactivar o cambiar la duración de estas reservas desde 'configurar y personalizar'"; break;
case "Trascinare l'inizio o la fine di una prenotazione per cambiare la data di arrivo o partenza":	$messaggio = "Arrastrar el principio o el final de una reserva para cambiar la fecha de llegada o salida"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>