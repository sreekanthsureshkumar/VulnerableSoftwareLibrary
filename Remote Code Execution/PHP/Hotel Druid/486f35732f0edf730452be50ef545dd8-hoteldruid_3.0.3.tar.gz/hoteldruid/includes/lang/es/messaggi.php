<?php

switch ($messaggio) {

case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "Nuovo messaggio a":  			$messaggio = "Nuevo mensaje a"; break;
case "da mostrare dopo le":  			$messaggio = "a enseñar después de las"; break;
case "il":  					$messaggio = "el"; break;
case "testo del messaggio":  			$messaggio = "texto del mensaje"; break;
case "Messaggi":  				$messaggio = "Mensajes"; break;
case "Spedisci":  				$messaggio = "Enviar"; break;
case "Messaggio inviato":  			$messaggio = "Mensaje enviado"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "N°":  					$messaggio = "N°"; break;
case "Mittente":  				$messaggio = "Remitente"; break;
case "Testo":  					$messaggio = "Texto"; break;
case "Data":  					$messaggio = "Fecha"; break;
case "Azioni":  				$messaggio = "Acciones"; break;
case "Elimina":  				$messaggio = "Eliminar"; break;
case "Messaggio eliminato":  			$messaggio = "Mensaje eliminado"; break;
case "tutti":  					$messaggio = "todos"; break;
case "SI":  					$messaggio = "SI"; break;
case "Si è sicuri di voler eliminare la richiesta di prenotazione di":	$messaggio = "Estás seguro de querer eliminar el pedido de reserva de"; break;
case "non ancora inserita?":  			$messaggio = "todavía no insertado?"; break;
case "Inserisci la prenotazione":  		$messaggio = "Insertar la reserva"; break;
case "Visualizza il documento":  		$messaggio = "Mira el documento"; break;
case "di tipo":  				$messaggio = "tipo"; break;
case "Inserito":  				$messaggio = "Insertado"; break;
case "Elimina tutti i messaggi":  		$messaggio = "Eliminar todos los mensajes"; break;
case "Si è sicuri di voler eliminare <div style=\"display: inline; color: red;\"><b>tutti i messaggi</b></div>":	$messaggio = "Estás seguro de querer eliminar <div style=\"display: inline; color: red;\"><b>todos los mensajes</b></div>"; break;
case "Messaggi eliminati":  			$messaggio = "Mensajes eliminados"; break;
case "arrivati":  				$messaggio = "llegados"; break;
case "prima del":  				$messaggio = "antes del"; break;
case "dopo il":  				$messaggio = "después del"; break;
case "Scarica messaggi email":  		$messaggio = "Descargar mensajes email"; break;
case "Nessun nuovo messaggio":  		$messaggio = "Ningún mensaje nuevo"; break;
case "Nuovi messaggi":  			$messaggio = "Nuevos mensajes"; break;
case "Scaricati":  				$messaggio = "Descargados"; break;
case "Connessione al server":  			$messaggio = "La conexión al servidor"; break;
case "non riuscita!":  				$messaggio = "ha sido rechazada!"; break;
case "Controllare i dati immessi in":		$messaggio = "Controlar los datos insertados en"; break;
case "configura e personalizza":  		$messaggio = "configurar y personalizar"; break;
case "Dati ricavati dal messaggio email":  	$messaggio = "Datos extraídos del mensaje email"; break;
case "Controlla disponibilità":  		$messaggio = "Controlar disponibilidad"; break;
case "Modifica":  				$messaggio = "Modificar"; break;
case "Nome":  					$messaggio = "Nombre"; break;
case "Email":  					$messaggio = "Email"; break;
case "arrivo":  				$messaggio = "llegada"; break;
case "partenza":  				$messaggio = "salida"; break;
case "notti":  					$messaggio = "noches"; break;
case "persone":  				$messaggio = "personas"; break;
case "individui":  				$messaggio = "individuos"; break;
case "ospiti":  				$messaggio = "huéspedes"; break;
case "adulti":  				$messaggio = "adultos"; break;
case "bambini":  				$messaggio = "niños"; break;
case "gruppo":  				$messaggio = "grupo"; break;
case "date":  					$messaggio = "fechas"; break;
case "viaggiatori":  				$messaggio = "viajeros"; break;
case "periodo":  				$messaggio = "período"; break;
case "Per gli account su gmail potrebbe essere necessario abilitare l'opzione":	$messaggio = "Para las cuentas de gmail puede que haya que habilitar la opción"; break;
case "e/o per una volta usare prima la funzione":	$messaggio = "y/o por una vez usar de antemano la función"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>