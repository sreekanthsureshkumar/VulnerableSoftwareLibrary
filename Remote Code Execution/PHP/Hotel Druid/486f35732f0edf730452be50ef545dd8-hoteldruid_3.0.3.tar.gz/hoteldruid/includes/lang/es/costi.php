<?php

switch ($messaggio) {

case "Costi Gestione":  			$messaggio = "Gastos de Gestión"; break;
case "Si deve inserire un nome per l' entrata":	$messaggio = "Hay que poner un nombre para la entrada"; break;
case "Si deve inserire il valore dell' entrata":	$messaggio = "Hay que poner la cantidad de la entrada"; break;
case "L'entrata è stata inserita":  		$messaggio = "La entrada ha sido insertada"; break;
case "Si deve inserire un nome per la spesa":	$messaggio = "Hay que poner un nombre para el gasto"; break;
case "Si deve inserire il valore della spesa":	$messaggio = "Hay que poner la cantidad del gasto"; break;
case "La spesa è stata inserita":  		$messaggio = "El gasto ha sido insertado"; break;
case "Inserisci i costi di gestione per l'anno":	$messaggio = "Insertar los gastos de gestión del año"; break;
case "Natura spesa":  				$messaggio = "Motivo del gasto"; break;
case "Importo":  				$messaggio = "Catidad"; break;
case "Persona che inserisce":  			$messaggio = "Persona que inserta"; break;
case "opzionale":  				$messaggio = "opcional"; break;
case "Inserisci la spesa":  			$messaggio = "Insertar el gasto"; break;
case "Inserisci le entrate in cassa per l'anno":	$messaggio = "Insertar las entradas del año"; break;
case "Natura entrata":  			$messaggio = "Motivo de la entrada"; break;
case "Inserisci l' entrata":  			$messaggio = "Insertar la entrada"; break;
case "Sottrai l'importo dal totale delle prenotazioni":	$messaggio = "Subtraer esta cantidad desde el total de las reservas"; break;
case "Visualizza la tabella con tutte le spese e le entrate":	$messaggio = "Mirar la tabla con todos los gastos y las entradas"; break;
case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "Il valore dell' entrata è sbagliato":  	$messaggio = "La cantidad de la entrada está equivocada"; break;
case "Il valore della spesa è sbagliato":  	$messaggio = "La cantidad del gasto está equivocada"; break;
case "Nessuna cassa disponibile":  		$messaggio = "Ninguna caja disponible"; break;
case "Cassa":  					$messaggio = "Caja"; break;
case "cassa principale":  			$messaggio = "caja principal"; break;
case "Metodo di pagamento":  			$messaggio = "Método de pago"; break;
case "OK":  					$messaggio = "OK"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>