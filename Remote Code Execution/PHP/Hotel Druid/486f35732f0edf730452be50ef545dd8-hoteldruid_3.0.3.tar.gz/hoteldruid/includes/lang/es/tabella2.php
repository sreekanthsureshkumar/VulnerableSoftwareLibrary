<?php

switch ($messaggio) {

case "Tabelle Mesi":  				$messaggio = "Tablas de los Meses"; break;
case "situazione alle":  			$messaggio = "situación a las"; break;
case "del":  					$messaggio = "del"; break;
case "Tabella prenotazioni del":  		$messaggio = "Tabla de reservas del"; break;
case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "Visualizza la tabella normale":  		$messaggio = "Ver la tabla normal"; break;
case "Visualizza tutti i mesi":  		$messaggio = "Ver todos los meses"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>