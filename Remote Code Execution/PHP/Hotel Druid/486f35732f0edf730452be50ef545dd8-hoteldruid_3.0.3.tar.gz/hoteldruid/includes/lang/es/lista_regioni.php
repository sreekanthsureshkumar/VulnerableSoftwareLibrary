<?php

$lista_regioni = array();
$cod_regioni = array();
$cod2_regioni = array();
$cod3_regioni = array();
$cod_nazione_regioni = array();

#$lista_regioni[0] = "Andalucía";
#$cod_regioni[0] = "00001";
#$cod_nazione_regioni[0] = "ES";
#$lista_regioni[1] = "Aragón";
#$cod_regioni[1] = "00002";
#$cod_nazione_regioni[1] = "ES";


?>