<?php

switch ($messaggio) {

case "Database aggiornato alla versione":  	$messaggio = "Base de datos actualizada a la versión"; break;
case "Niente da aggiornare":  			$messaggio = "Nada para actualizar"; break;
case "Vai al menù principale":  		$messaggio = "Ir al menu principal"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>