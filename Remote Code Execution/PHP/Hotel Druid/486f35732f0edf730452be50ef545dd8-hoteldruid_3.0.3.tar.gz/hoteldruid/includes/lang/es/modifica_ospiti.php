<?php

switch ($messaggio) {

case "Modifica Ospiti":  			$messaggio = "Modificar Huéspedes"; break;
case "Modifica gli ospiti della prenotazione":	$messaggio = "Modificar los huéspedes de la reserva"; break;
case "Cliente titolare":  			$messaggio = "Cliente titular"; break;
case "Ospite della prenotazione":  		$messaggio = "Huésped de la reserva"; break;
case "nato il":  				$messaggio = "nacido el"; break;
case "nata il":  				$messaggio = "nacida el"; break;
case "CAP":  					$messaggio = "código postal"; break;
case "Telefono":  				$messaggio = "Teléfono"; break;
case "2º telefono":  				$messaggio = "2° teléfono"; break;
case "3º telefono":  				$messaggio = "3er teléfono"; break;
case "Cognome":  				$messaggio = "Apellido"; break;
case "nome":  					$messaggio = "nombre"; break;
case "sesso":  					$messaggio = "sexo"; break;
case "Data di nascita":  			$messaggio = "Fecha de nacimiento"; break;
case "anno con 4 cifre":  			$messaggio = "año con 4 cifras"; break;
case "Documento":  				$messaggio = "Documento"; break;
case "scadenza":  				$messaggio = "expiración"; break;
case "Altri ospiti":  				$messaggio = "Otros huéspedes"; break;
case "Modifica gli ospiti":  			$messaggio = "Modificar los huéspedes"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "Gli ospiti della prenotazione":  		$messaggio = "Los huéspedes de la reserva"; break;
case "sono stati modificati":  			$messaggio = "han sido modificados"; break;
case "nato":  					$messaggio = "nacido"; break;
case "nata":  					$messaggio = "nacida"; break;
case "il":  					$messaggio = "el"; break;
case " a":  					$messaggio = " en"; break;
case "scade":  					$messaggio = "caduca"; break;
case "cittadinanza":  				$messaggio = "nacionalidad"; break;
case "città di nascita":  			$messaggio = "ciudad de nacimiento"; break;
case "reg./prov. di nascita":  			$messaggio = "región de nacimiento"; break;
case "nazione di nascita":  			$messaggio = "nación de nacimiento"; break;
case "reg./prov.":  				$messaggio = "región"; break;
case "nazione":  				$messaggio = "nación"; break;
case "Nazione":  				$messaggio = "Nación"; break;
case "rilasciato da":  				$messaggio = "emitido por"; break;
case "nazione di rilascio":  			$messaggio = "nación emisora"; break;
case "Ospite principale":  			$messaggio = "Huésped principal"; break;
case "Parentela":  				$messaggio = "Emparentado"; break;
case "parentela":  				$messaggio = "emparentado"; break;
case "Codice fiscale":  			$messaggio = "N.I.F."; break;
case "città":  					$messaggio = "ciudad"; break;
case "Partita iva":  				$messaggio = "C.I.F."; break;
case "Modifica gli ospiti delle prenotazioni":	$messaggio = "Modificar los huéspedes de las reservas"; break;
case "della prenotazione":  			$messaggio = "de la reserva"; break;
case "Gli ospiti delle prenotazioni":  		$messaggio = "Los huéspedes de las reservas"; break;
case "ln.":  					$messaggio = "id."; break;
case "email":  					$messaggio = "email"; break;
case "2ª email":  				$messaggio = "2º email"; break;
case "PEC/codice":  				$messaggio = "email certificado"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>