<?php

$lista_parentele = array();
$cod_parentele = array();
$cod2_parentele = array();
$cod3_parentele = array();

#$lista_parentele[0] = "Marido/Mujer";
#$cod_parentele[0] = "001";
#$lista_parentele[1] = "Hijo/Hija";
#$cod_parentele[1] = "002";

?>