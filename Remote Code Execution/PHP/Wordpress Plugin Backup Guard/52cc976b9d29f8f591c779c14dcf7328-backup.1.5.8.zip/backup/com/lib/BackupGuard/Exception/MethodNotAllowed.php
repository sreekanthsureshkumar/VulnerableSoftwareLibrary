<?php

namespace BackupGuard;

require_once(dirname(__FILE__).'/Exception.php');

class MethodNotAllowedException extends Exception
{

}
