<h2>
	<b>BackupGuard Error:</b> Migration failed
</h2>
<p>
	<?php echo SGConfig::get('SG_BACKUP_MIGRATION_ERROR'); ?>
</p>
