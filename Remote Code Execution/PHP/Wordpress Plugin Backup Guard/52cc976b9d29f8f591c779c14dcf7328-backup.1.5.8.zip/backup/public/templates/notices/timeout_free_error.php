<div class="sg-error-notice-wrapper">
	<h2 class="sg-red-color sg-notice-error-h2">
		SOMETHING WENT WRONG
	</h2>
	<p class="sg-black-color sg-notice-error-p">
		Oops... Seems there was an issue during the backup process.
		<br>
		Please try again. If the issue persists, please contact our support team.
	</p>
	<div class="sg-wrapper-less sg-notice-contact-wrapper">
		<a href="<?php echo BACKUP_GUARD_WORDPRESS_SUPPORT_URL; ?>" class="" target="_blank">Contact us</a>
	</div>
</div>
