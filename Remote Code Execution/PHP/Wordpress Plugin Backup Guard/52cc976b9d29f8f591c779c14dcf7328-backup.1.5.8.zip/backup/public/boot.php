<?php
require_once(dirname(__FILE__) . '/../com/boot.php');
require_once(dirname(__FILE__) . '/config/config.wordpress.php');
require_once(SG_PUBLIC_INCLUDE_PATH.'functions.php');
