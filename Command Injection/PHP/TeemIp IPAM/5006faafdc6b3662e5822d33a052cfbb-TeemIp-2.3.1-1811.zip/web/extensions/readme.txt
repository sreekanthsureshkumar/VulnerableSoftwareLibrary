Place extensions modules in this directory. They will be taken into account by the setup program and safely copied in case of upgrade.
