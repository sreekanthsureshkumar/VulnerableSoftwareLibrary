#include <fly/fly.h>

int main (int argc, char *argv[], char **envp)
{
   return fly_main (argc, argv, envp);
}
