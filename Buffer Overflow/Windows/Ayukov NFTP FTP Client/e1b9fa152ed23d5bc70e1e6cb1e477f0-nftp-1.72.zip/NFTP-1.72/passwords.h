
void psw_read (void);
char *psw_match (char *h, char *u);
void psw_edit (void);
int psw_set_password (char *psw);
int psw_add (char *h, char *u, char *p);
void psw_chkey (void);
