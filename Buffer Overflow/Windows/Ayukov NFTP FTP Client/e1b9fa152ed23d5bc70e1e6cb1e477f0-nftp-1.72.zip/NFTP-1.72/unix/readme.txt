
Please read install.txt for instructions on how to install NFTP.

Build platforms:

CPU     Unix version    Distribution            Comment
------------------------------------------------------------------------
x86     Linux libc5     Slackware 4.0           libc 5.4.46
x86     Linux libc6     RedHat 7.1              glibc 2.2
x86     FreeBSD 2.x     FreeBSD 2.2.8           a.out
x86     FreeBSD 3.x     FreeBSD 3.5.1-RELEASE   ELF
x86     FreeBSD 4.x     FreeBSD 4.4-RELEASE
SPARC   Solaris2.5      Solaris 2.5.1 
RS/6000 AIX             AIX 4.3
