
/* returns 0 if OK, 1 if no files to transfer */
int mirror (int d, int noisy);

