
int Connect2 (unsigned long ip, int port);
int Accept  (int sock);
int BindListen (int *port);
int SetBlockingMode (int sock, int mode);

