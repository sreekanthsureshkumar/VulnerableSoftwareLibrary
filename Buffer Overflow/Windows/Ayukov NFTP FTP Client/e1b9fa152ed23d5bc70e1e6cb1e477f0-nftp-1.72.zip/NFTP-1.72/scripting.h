
extern FILE *script_log;

