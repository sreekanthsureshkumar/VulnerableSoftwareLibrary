This directory is used as temp to generate graphs with Graphviz.

DO NOT DELETE. This directoy MUST have permissions to http daemon
to write into (root:www-data and 770 is a good idea).

