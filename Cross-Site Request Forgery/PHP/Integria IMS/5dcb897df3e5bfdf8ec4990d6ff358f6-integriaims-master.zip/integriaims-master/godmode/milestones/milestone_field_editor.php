<?php
// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2008 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// Load global vars
global $config;

if (check_login() != 0) {
	audit_db("Noauth", $config["REMOTE_ADDR"], "No authenticated access", "Trying to access event viewer");
	require ("general/noaccess.php");
	exit;
}

if (! give_acl ($config["id_user"], 0, "UM")) {
	audit_db($config["id_user"], $config["REMOTE_ADDR"], "ACL Violation","Trying to access milestone field edition");
	require ("general/noaccess.php");
	exit;
}

$id_field = get_parameter ('id_field');
$id_project = get_parameter ('id_project');

if ($id_field) {
	$field_data = get_db_row_filter('tmilestone_field', array('id' => $id_field));

	$label = $field_data['label'];
	$type = $field_data['type'];
	$combo_value = $field_data['combo_value'];

}

echo '<h2>'.__('Milestone fields editor').'</h2>';

if ($id_field){
	echo '<h4>'.__('Update');
}
else{
	echo '<h4>'.__('Create');
}
	echo "<div id='button-bar-title'><ul>";
		echo "<a href='index.php?sec=projects&sec2=godmode/milestones/milestone_field_list&id_project=".$id_project."'><li>".print_image ("images/flecha_volver.png", true, array("title" => __("Back to milestone list")))."</li></a>";
	echo "</ul></div>";
echo '</h4>';

$table = new StdClass();
$table->width = "100%";
$table->class = "search-table search-table_new";
$table->size = array ();
$table->size[0] = '50%';
$table->size[1] = '50%';

$table->data = array ();
if(!isset($label)){
	$label = '';
}
$table->data[0][0] = print_input_text ('label', $label, '', 45, 100, true, __('Field name'));
$table->data[0][1] = " ";

$types = array('text' =>__('Text'), 'textarea' => __('Textarea'), 'combo' => __('Combo'), 'checkbox' => __('Checkbox'));
$table->data[1][0] = print_label (__("Type"), "label-id", 'text', true);
if(!isset($type)){
	$type = '';
}
$table->data[1][0] .= print_select ($types, 'type', $type, '', __('Select type'), '0', true);
$table->data[1][1] = " ";

if(!isset($combo_value)){
	$combo_value = '';
}
$table->data['id_combo_value'][0] = print_input_text ('combo_value', $combo_value, '', 45, 100, true, __('Combo value').print_help_tip (__("Set values separated by comma"), true));
$table->data['id_combo_value'][1] = " ";
$button = "<div class='button-form'>";
if (!$id_field) {
	$button .= print_input_hidden('add_field', 1, true);
	$button .= print_submit_button (__('Create'), 'create_btn', false, 'class="sub next"', true);
} else {
	$button .= print_input_hidden('update_field', 1, true);
	$button .= print_input_hidden('add_field', 0, true);
	$button .= print_input_hidden('id_field', $id_field, true);
	$button .= print_submit_button (__('Update'), 'update_btn', false, 'class="sub upd"', true);
}
$button .= "</div>";
$table->data['button'][0] = $button;
$table->colspan['button'][0] = 2;
echo '<form method="post" action="index.php?sec=projects&sec2=godmode/milestones/milestone_field_list&id_project='.$id_project.'">';
	print_table ($table);
echo '</form>';

?>

<script type="text/javascript" src="include/js/jquery.validate.js"></script>
<script type="text/javascript" src="include/js/jquery.validation.functions.js"></script>

<script  type="text/javascript">
$(document).ready (function () {
	if ($("#type").val() == "combo") {
		$("#table1-id_combo_value-0").css ('display', '');
	} else {
		$("#table1-id_combo_value-0").css ('display', 'none');
	}

});

$("#type").change (function () {
	if ($("#type").val() == "combo") {
		$("#table1-id_combo_value-0").css ('display', '');
	} else {
		$("#table1-id_combo_value-0").css ('display', 'none');
	}
});


// Form validation
trim_element_on_submit('#text-label');
trim_element_on_submit('#text-combo_value');

</script>
