<?php 

// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2008 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

define('EHORUS_DEFAULT_HOSTNAME', 'portal.ehorus.com');
define('EHORUS_DEFAULT_PORT', 443);
define('EHORUS_DEFAULT_TIMEOUT', 30);

// Load global vars
global $config;

include_once($config['homedir'] . '/include/functions_setup.php');

check_login();

if (!dame_admin($config['id_user']) && !give_acl($config['id_user'], 0, 'FM')) {
	audit_db('ACL Violation', $config['REMOTE_ADDR'], 'No administrator access', 'Trying to access setup');
	require('general/noaccess.php');
	return;
}

$is_enterprise = file_exists('enterprise/load_enterprise.php');

/* Tabs list */
print_setup_tabs('ehorus', $is_enterprise);

$update_config = (bool) get_parameter('update_config');
$changed_status = false;
$config_updated = false;

$old_status = (int) $config['ehorus_enabled'];

if (isset($_POST['ehorus_enabled'])) {
	$config['ehorus_enabled'] = (int) get_parameter('ehorus_enabled');
	update_config_token('ehorus_enabled', $config['ehorus_enabled']);
	$changed_status = true;
}

$was_enabled = $changed_status && !$old_status && $config['ehorus_enabled'];

if ($update_config || $was_enabled) {
	// Directory address
	$config['ehorus_hostname'] = (string) get_parameter('ehorus_hostname', EHORUS_DEFAULT_HOSTNAME);
	update_config_token('ehorus_hostname', $config['ehorus_hostname']);
	// Directory port
	$config['ehorus_port'] = (int) get_parameter('ehorus_port', EHORUS_DEFAULT_PORT);
	update_config_token('ehorus_port', $config['ehorus_port']);
	// Timeout
	$config['ehorus_req_timeout'] = (int) get_parameter('ehorus_req_timeout', EHORUS_DEFAULT_TIMEOUT);
	update_config_token('ehorus_req_timeout', $config['ehorus_req_timeout']);
	
	// User
	if (isset($_POST['ehorus_user'])) {
		$config['ehorus_user'] = (string) get_parameter('ehorus_user');
		update_config_token('ehorus_user', $config['ehorus_user']);
	}
	// Password
	if (isset($_POST['ehorus_pass'])) {
		$config['ehorus_pass'] = (string) get_parameter('ehorus_pass');
		update_config_token('ehorus_pass', $config['ehorus_pass']);
	}
	
	$config_updated = true;
}

/* Enable table */

$table_enable = new StdClass();
$table_enable->data = array();
$table_enable->width = '100%';
$table_enable->id = 'ehorus-enable-setup';
$table_enable->class = 'search-table';
$table_enable->size['name'] = '30%';
$table_enable->style['name'] = 'font-weight: bold';

// Enable eHorus
$row = array();
$row['name'] = __('Enable eHorus');
$row['control'] = __('Yes').'&nbsp;&nbsp;' . print_radio_button('ehorus_enabled', 1, '', $config['ehorus_enabled'], true);
$row['control'] .= '&nbsp;&nbsp;&nbsp;';
$row['control'] .= __('No').'&nbsp;&nbsp;' . print_radio_button('ehorus_enabled', 0, '', $config['ehorus_enabled'], true);
$row['button'] = print_submit_button(__('Update'), 'update_button', false, 'class="sub upd"', true);
$table_enable->data['ehorus_enabled'] = $row;

/* Remote config table */

$table_remote = new StdClass();
$table_remote->data = array();
$table_remote->width = '100%';
$table_remote->styleTable = 'margin-bottom: 10px;';
$table_remote->id = 'ehorus-remote-setup';
$table_remote->class = 'search-table';
$table_remote->size['name'] = '30%';
$table_remote->style['name'] = 'font-weight: bold';

// User
$row = array();
$row['name'] = __('User');
$row['control'] = print_input_text('ehorus_user', $config['ehorus_user'], '', 30, 100, true);
$table_remote->data['ehorus_user'] = $row;

// Pass
$row = array();
$row['name'] = __('Password');
$row['control'] = print_input_password('ehorus_pass', $config['ehorus_pass'], '', 30, 100, true);
$table_remote->data['ehorus_pass'] = $row;

// Directory hostname
$row = array();
$row['name'] = __('API Hostname');
$row['control'] = print_input_text('ehorus_hostname', $config['ehorus_hostname'], '', 30, 100, true);
$row['control'] .= print_help_tip(__('Hostname of the eHorus API') . '. ' . __('Without protocol and port') . '. ' . sprintf(__('e.g., %s'), EHORUS_DEFAULT_HOSTNAME), true);
$table_remote->data['ehorus_hostname'] = $row;

// Directory port
$row = array();
$row['name'] = __('API Port');
$row['control'] = print_input_text('ehorus_port', $config['ehorus_port'], '', 6, 100, true);
$row['control'] .= print_help_tip(sprintf(__('e.g., %s'), EHORUS_DEFAULT_PORT), true);
$table_remote->data['ehorus_port'] = $row;

// Request timeout
$row = array();
$row['name'] = __('Request timeout');
$row['control'] = print_input_text('ehorus_req_timeout', $config['ehorus_req_timeout'], '', 3, 10, true);
$row['control'] .= print_help_tip(__('Time in seconds to set the maximum time of the requests to the eHorus API') . '. ' . __('0 to disable'), true);
$table_remote->data['ehorus_req_timeout'] = $row;

// Test
$row = array();
$row['name'] = __('Test');
$row['control'] = print_button(__('Start'), 'test-ehorus', false, '', 'class="sub next"', true);
$row['control'] .= '<span id="test-ehorus-spinner" style="display:none;">&nbsp;' . print_image('images/spinner.gif', true) . '</span>';
$row['control'] .= '<span id="test-ehorus-success" style="display:none;">&nbsp;' . print_image('images/success.png', true) . '</span>';
$row['control'] .= '<span id="test-ehorus-failure" style="display:none;">&nbsp;' . print_image('images/fail.png', true) . '</span>';
$row['control'] .= '&nbsp;<span id="test-ehorus-message" style="display:none;"></span>';
$table_remote->data['ehorus_test'] = $row;

/* Print */

echo '<div style="text-align: center; padding-bottom: 20px;">';
echo '<a target="_blank" rel="noopener noreferrer" href="https://ehorus.com">';
echo print_image('include/ehorus/images/ehorus-logo.png', true, array('style' => 'background-color: #3f3f3f; border-radius: 10px; padding: 5px;'));
echo '</a>';
echo '<br />';
echo '<div style="font-family: lato, "Helvetica Neue", Helvetica, Arial, sans-serif; color: #515151;">';
echo __('Remote Management System');
echo '</div>';
echo '<a target="_blank" rel="noopener noreferrer" href="https://ehorus.com">';
echo 'https://ehorus.com';
echo '</a>';
echo '</div>';

if ($changed_status || $config_updated) {
	echo ui_print_success_message(__('Successfully updated'), '', true, 'h3', true);
}

if ($config['ehorus_enabled']) {
	$computer_type_field_created = false;
	$pandora_type_field_created = false;
	if ($was_enabled) {
		$ehorus_field_label = 'eHorus&#x20;Id';
		$computer_type_object_id = 1;
		$pandora_type_object_id = 2;
		
		// Create field in Computer
		$sql = sprintf(
			"SELECT id
			FROM tobject_type_field
			WHERE id_object_type = %d
				AND label LIKE '%s'",
			$computer_type_object_id, $ehorus_field_label
		);
		$ehorus_type_field_exist = (bool) get_db_value_sql($sql);
		
		if (!$ehorus_type_field_exist) {
			$values = array(
				'id_object_type' => $computer_type_object_id, // Computer
				'label' => $ehorus_field_label,
				'type' => 'text',
				'show_list' => 0
			);
			$computer_type_field_created = (bool) process_sql_insert('tobject_type_field', $values);
		}
		
		// Create field in Pandora agents
		$sql = sprintf(
			"SELECT id
			FROM tobject_type_field
			WHERE id_object_type = %d
				AND label LIKE '%s'",
			$pandora_type_object_id, $ehorus_field_label
		);
		$ehorus_type_field_exist = (bool) get_db_value_sql($sql);
		
		if (!$ehorus_type_field_exist) {
			$values = array(
				'id_object_type' => $pandora_type_object_id, // Pandora agents
				'label' => $ehorus_field_label,
				'type' => 'text',
				'show_list' => 0
			);
			$pandora_type_field_created = (bool) process_sql_insert('tobject_type_field', $values);
		}
	}
	
	$message = __('The eHorus client is only available to the inventory objects which have a type with a field called \'eHorus Id\'');
	$message .= '. ';
	$message .= __('This field should store the Id of the eHorus agent related to the inventory object');
	$message .= '. ';
	echo ui_print_message ($message, 'info_message', '', true, 'h4', false);
	
	if ($computer_type_field_created) {
		echo ui_print_success_message(__('A field has been added to the \'Computer\' inventory object type'), '', true, 'h3', true);
	}
	if ($pandora_type_field_created) {
		echo ui_print_success_message(__('A field has been added to the \'Pandora agents\' inventory object type'), '', true, 'h3', true);
	}
}

// Form enable
echo '<form id="form_enable" method="post">';
print_table($table_enable);
echo '</form>';

// Form remote
if ($config['ehorus_enabled']) {
	echo '<span>' . __('eHorus API') . '</span>';
	echo '<form id="form_remote" method="post">';
	print_input_hidden('update_config', 1);
	print_table($table_remote);
	echo '<div class="button-form">';
	print_submit_button(__('Update'), 'update_button', false, 'class="sub upd"');
	echo '</div>';
	echo '</form>';
}

?>

<script type="text/javascript">
	var showFields = function () {
		$('form#form_remote').show();
	}
	var hideFields = function () {
		$('form#form_remote').hide();
	}
	var handleEnable = function (event) {
		if (event.target.value == '1') showFields();
		else hideFields();
	}
	$('input:radio[name="ehorus_enabled"]').change(handleEnable);
	
	var handleTest = function (event) {
		var user = $('input#text-ehorus_user').val();
		var pass = $('input#password-ehorus_pass').val();
		var host = $('input#text-ehorus_hostname').val();
		var port = $('input#text-ehorus_port').val();
		var timeout = Number.parseInt($('input#text-ehorus_req_timeout').val(), 10);
		
		var timeoutMessage = '<?php echo __('Connection timeout'); ?>';
		var badRequestMessage = '<?php echo __('Empty user or password'); ?>';
		var notFoundMessage = '<?php echo __('User not found'); ?>';
		var invalidPassMessage = '<?php echo __('Invalid password'); ?>';
		
		var hideLoadingImage = function () {
			$('span#test-ehorus-spinner').hide();
		}
		var showLoadingImage = function () {
			$('span#test-ehorus-spinner').show();
		}
		var hideSuccessImage = function () {
			$('span#test-ehorus-success').hide();
		}
		var showSuccessImage = function () {
			$('span#test-ehorus-success').show();
		}
		var hideFailureImage = function () {
			$('span#test-ehorus-failure').hide();
		}
		var showFailureImage = function () {
			$('span#test-ehorus-failure').show();
		}
		var hideMessage = function () {
			$('span#test-ehorus-message').hide();
		}
		var showMessage = function () {
			$('span#test-ehorus-message').show();
		}
		var changeTestMessage = function (message) {
			$('span#test-ehorus-message').text(message);
		}
		
		hideSuccessImage();
		hideFailureImage();
		hideMessage();
		showLoadingImage();

		$.ajax({
			url: 'https://' + host + ':' + port + '/login',
			type: 'POST',
			dataType: 'json',
			timeout: timeout ? timeout * 1000 : 0,
			data: {
				user: user,
				pass: pass
			}
		})
		.done(function (data, textStatus, xhr) {
			showSuccessImage();
		})
		.fail(function (xhr, textStatus, errorThrown) {
			showFailureImage();
			
			if (xhr.status === 400) {
				changeTestMessage(badRequestMessage);
			}
			else if (xhr.status === 401 || xhr.status === 403) {
				changeTestMessage(invalidPassMessage);
			}
			else if (xhr.status === 404) {
				changeTestMessage(notFoundMessage);
			}
			else if (errorThrown === 'timeout') {
				changeTestMessage(timeoutMessage);
			}
			else {
				changeTestMessage(errorThrown);
			}
			showMessage();
		})
		.always(function (xhr, textStatus) {
			hideLoadingImage();
		});
	}
	$('input#button-test-ehorus').click(handleTest);
</script>
