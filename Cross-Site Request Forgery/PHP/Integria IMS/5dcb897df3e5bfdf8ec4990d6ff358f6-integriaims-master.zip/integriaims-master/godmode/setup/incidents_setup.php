<?php 

// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2008 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// Load global vars
global $config;
include_once('include/functions_setup.php');

enterprise_include("include/functions_setup.php");

check_login ();

if (! dame_admin ($config["id_user"]) && !give_acl($config["id_user"], 0, "FM")) {
	audit_db ("ACL Violation", $config["REMOTE_ADDR"], "No administrator access", "Trying to access setup");
	require ("general/noaccess.php");
	exit;
}

$is_enterprise = false;
if (file_exists ("enterprise/load_enterprise.php")) {
	$is_enterprise = true;
}

/* Tabs list */
print_setup_tabs('incidents', $is_enterprise);

$update = (bool) get_parameter ("update");
$add_day = (bool) get_parameter ("add_day");
$del_day = (bool) get_parameter ("del_day");

if ($add_day) {
	$new_day = get_parameter("new_day");
	//If new day added then add to list
	if ($new_day) {
		$sql = sprintf("INSERT INTO tholidays (`day`) VALUES ('%s')", $new_day);
		process_sql($sql);
	}
}

if ($del_day) {
	$day = get_parameter("day");
	$sql = sprintf("DELETE FROM tholidays WHERE `id` = '".$day."'");
	process_sql ($sql);
}

if ($update) {
	$status = (array) get_parameter ('status');
	$resolutions = (array) get_parameter ('resolutions');
	$config["working_weekends"] = (int) get_parameter("working_weekends", 0);
	$config["mask_emails"] = (int) get_parameter("mask_emails", 0);
	$config["iwu_defaultime"] = get_parameter ("iwu_defaultime", 0.25);
	$config["limit_size"] = (int) get_parameter ("limit_size");
	$config["show_owner_incident"] = (int) get_parameter ("show_owner_incident", 0);
	$config["show_creator_incident"] = (int) get_parameter ("show_creator_incident", 0);
	$config["auto_incident_close"] = get_parameter ("auto_incident_close", "72");
	$config["iw_creator_enabled"] = get_parameter ("iw_creator_enabled", 0);
	$config["incident_creation_wu"] = get_parameter ("incident_creation_wu", 0);
	$config["incident_type_change"] = (int) get_parameter ("incident_type_change", 0);
	$config["change_incident_datetime"] = (int) get_parameter ("change_incident_datetime", 0);
	$config["enabled_ticket_editor"] = get_parameter ("enabled_ticket_editor", 0);
	$config["ticket_owner_is_creator"] = (int) get_parameter ("ticket_owner_is_creator", 0);
	$config["show_user_name"] = (int) get_parameter ("show_user_name", 0);
	$config["required_ticket_type"] = (int) get_parameter ("required_ticket_type", 0);
	$config["show_creator_blank"] = (int) get_parameter ("show_creator_blank", 0);
	$config["change_creator_owner"] = (int) get_parameter ("change_creator_owner", 0);
	$config["check_closed_incidents"] = (int) get_parameter ("check_closed_incidents", 0);
	$config["days_check_closed_incidents"] = (int) get_parameter ("days_check_closed_incidents", 15);
	$config["external_modify_tickets"] = (int) get_parameter ("external_modify_tickets", 0);
	$config["ignore_group_template"] = (int) get_parameter ("ignore_group_template", 0);
	$config["human_time_incident"] = (int) get_parameter ("human_time_incident", 0);
	$config["realization_date_wu"] = (int) get_parameter ("realization_date_wu", 0);
	$config["sort_date_wu"] = (int) get_parameter ("sort_date_wu", 0);
	$config["creator_all_groups"] = (int) get_parameter ("creator_all_groups", 0);
	$config["send_all_attachment"] = (int) get_parameter ("send_all_attachment", 0);
	$config["disable_ticket_score"] = (int) get_parameter ("disable_ticket_score", 0);
	$config["autoassign_ticket"] = (int) get_parameter ("autoassign_ticket", 0);
	$config["editor_first_editing_user"] = (int) get_parameter ("editor_first_editing_user", 0);

	$config["mail_creation_ticket"] = (int) get_parameter ("mail_creation_ticket", 0);
	$config["mail_close_ticket"] = (int) get_parameter ("mail_close_ticket", 0);
	$config["mail_update_status_ticket"] = (int) get_parameter ("mail_update_status_ticket", 0);
	$config["mail_update_owner_ticket"] = (int) get_parameter ("mail_update_owner_ticket", 0);
	$config["mail_update_priority_ticket"] = (int) get_parameter ("mail_update_priority_ticket", 0);
	$config["mail_update_group_ticket"] = (int) get_parameter ("mail_update_group_ticket", 0);
	$config["mail_update_other_ticket"] = (int) get_parameter ("mail_update_other_ticket", 0);
	$config["mail_create_WU"] = (int) get_parameter ("mail_create_WU", 0);
	$config["mail_create_attach"] = (int) get_parameter ("mail_create_attach", 0);
	$config["mail_validate_work_order"] = (int) get_parameter ("mail_validate_work_order", 0);

	update_config_token ("working_weekends", $config["working_weekends"]);
	update_config_token ("mask_emails", $config["mask_emails"]);
	update_config_token ("iwu_defaultime", $config["iwu_defaultime"]);
	update_config_token ("limit_size", $config["limit_size"]);
	update_config_token ("show_owner_incident", $config["show_owner_incident"]);
	update_config_token ("show_creator_incident", $config["show_creator_incident"]);
	update_config_token ("auto_incident_close", $config["auto_incident_close"]);
	update_config_token ("iw_creator_enabled", $config["iw_creator_enabled"]);
	update_config_token ("incident_creation_wu", $config["incident_creation_wu"]);
	update_config_token ("incident_type_change", $config["incident_type_change"]);
	update_config_token ("change_incident_datetime", $config["change_incident_datetime"]);
	update_config_token ("enabled_ticket_editor", $config["enabled_ticket_editor"]);
	update_config_token ("ticket_owner_is_creator", $config["ticket_owner_is_creator"]);
	update_config_token ("show_user_name", $config["show_user_name"]);
	update_config_token ("required_ticket_type", $config["required_ticket_type"]);
	update_config_token ("show_creator_blank", $config["show_creator_blank"]);
	update_config_token ("check_closed_incidents", $config["check_closed_incidents"]);
	update_config_token ("days_check_closed_incidents", $config["days_check_closed_incidents"]);
	update_config_token ("external_modify_tickets", $config["external_modify_tickets"]);
	update_config_token ("ignore_group_template", $config["ignore_group_template"]);
	update_config_token ("human_time_incident", $config["human_time_incident"]);
	update_config_token ("realization_date_wu", $config["realization_date_wu"]);
	update_config_token ("sort_date_wu", $config["sort_date_wu"]);
	update_config_token ("creator_all_groups", $config["creator_all_groups"]);
	update_config_token ("send_all_attachment", $config["send_all_attachment"]);
	update_config_token ("disable_ticket_score", $config["disable_ticket_score"]);
	update_config_token ("autoassign_ticket", $config["autoassign_ticket"]);
	update_config_token ("editor_first_editing_user", $config["editor_first_editing_user"]);

	update_config_token ("mail_creation_ticket", $config["mail_creation_ticket"]);
	update_config_token ("mail_close_ticket", $config["mail_close_ticket"]);
	update_config_token ("mail_update_status_ticket", $config["mail_update_status_ticket"]);
	update_config_token ("mail_update_owner_ticket", $config["mail_update_owner_ticket"]);
	update_config_token ("mail_update_priority_ticket", $config["mail_update_priority_ticket"]);
	update_config_token ("mail_update_group_ticket", $config["mail_update_group_ticket"]);
	update_config_token ("mail_update_other_ticket", $config["mail_update_other_ticket"]);
	update_config_token ("mail_create_WU", $config["mail_create_WU"]);
	update_config_token ("mail_create_attach", $config["mail_create_attach"]);
	update_config_token ("mail_validate_work_order", $config["mail_validate_work_order"]);

	foreach ($status as $id => $name) {
		$sql = sprintf ('UPDATE tincident_status SET name = "%s"
			WHERE id = %d',
			$name, $id);
		process_sql ($sql);
	}

	foreach ($resolutions as $id => $name) {
		$sql = sprintf ('UPDATE tincident_resolution SET name = "%s"
			WHERE id = %d',
			$name, $id);
		process_sql ($sql);
	}

	echo ui_print_success_message (__('Updated successfuly'), '', true, 'h3', true);
}

echo '<form method="post" class="form_setup">';
echo '<div>';
	echo '<h3>' . __('Visual options') . '</h3>';
echo '</div>';
echo '<div class="list_items_setup">';
	echo '<div>';
		print_checkbox ("show_owner_incident", 1, $config["show_owner_incident"], false, __('Show ticket owner'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("show_creator_incident", 1, $config["show_creator_incident"], false, __('Show ticket creator'));
	echo '</div>';

	echo '<div>';
		print_input_text ("limit_size", $config["limit_size"], '',5, 5, false, __('Max. tickets by search') .
			print_help_tip (__("This is the maximum limit for the data in Integria IMS. This is used for data such as attached files."), true));
	echo '</div>';

	echo '<div>';
		print_checkbox ("enabled_ticket_editor", 1, $config["enabled_ticket_editor"], false, __('Enable quick edit mode'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("show_user_name", 1, $config["show_user_name"], false, __('Show user name instead of id in the ticket search'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("human_time_incident", 1, $config["human_time_incident"], false, __('Format date') .
			print_help_tip (__("two format options: long format yyyy/mm/dd h m s (default option) and approximate format example: 1 day, 2 hours"), true));
	echo'</div>';

	echo '<div>';
		print_checkbox ("realization_date_wu", 1, $config["realization_date_wu"], false, __('Realization date WU') .
			print_help_tip (__("Checking this option will show the field 'Realization Date' in the tickets workunits."), true));
	echo '</div>';

	echo '<div>';
		print_checkbox ( "sort_date_wu", 1, $config["sort_date_wu"], false, __('Sort workunits by realization date') );
	echo '</div>';
echo '</div>';

echo '<div>';
	echo '<h3>' . __('Ticket behavior') . '</h3>';
echo '</div>';
echo '<div class="list_items_setup">';
	echo '<div>';
		print_checkbox ( "disable_ticket_score", 1, $config["disable_ticket_score"], false, __('Disable ticket score') );
	echo '</div>';

	echo '<div>';
		print_checkbox ("iw_creator_enabled", 1, $config["iw_creator_enabled"], false, __('Enable IW to change creator'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("incident_creation_wu", 1, $config["incident_creation_wu"], false, __('Editor adds a WU on ticket creation'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("incident_type_change", 1, $config["incident_type_change"], false, __('Allow to change the ticket type'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("change_incident_datetime", 1, $config["change_incident_datetime"], false, __('Allow to set the date/time in creation '));
	echo '</div>';

	echo '<div>';
		print_checkbox ("ticket_owner_is_creator", 1, $config["ticket_owner_is_creator"], false, __('Ignore user defined by the group for owner'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("required_ticket_type", 1, $config["required_ticket_type"], false, __('Required ticket type'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("show_creator_blank", 1, $config["show_creator_blank"], false, __('Ignore user creator by default'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("change_creator_owner", 1, $config["change_creator_owner"], false, __('Allow to change user creator and user owner'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("external_modify_tickets", 1, $config["external_modify_tickets"], false, __('Allow to external users to modify their tickets'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("ignore_group_template", 1, $config["ignore_group_template"], false, __('Ignore group template to the incident creator'));
	echo '</div>';

	echo '<div>';
		print_checkbox ( "creator_all_groups", 1, $config["creator_all_groups"], false, __('Creator user can see every user') );
	echo '</div>';

	echo '<div>';
		print_checkbox ("autoassign_ticket", 1, $config["autoassign_ticket"], false, __('Autoassign ticket'));
	echo '</div>';

	echo '<div>';
		print_checkbox ("editor_first_editing_user", 1, $config["editor_first_editing_user"], false, __('Incident editor is the first editing user') );
	echo '</div>';
echo '</div>';


echo '<div>';
	echo '<h3>' . __('Work units options (WU)') . '</h3>';
echo '</div>';
echo '<div class="list_items_setup">';
	echo '<div>';
		print_input_text ("auto_incident_close", $config["auto_incident_close"], '', 10, 10, false, __('Auto ticket close').
		integria_help ("auto_incident_close", true));
	echo '</div>';
	echo '<div>';
		print_input_text ("iwu_defaultime", $config["iwu_defaultime"], '', 5, 5, false, __('Ticket WU Default time'));
	echo '</div>';
echo '</div>';

if ($is_enterprise) {
	echo '<div>';
		echo '<h3>' . __('Workflows') . '</h3>';
	echo '</div>';
	echo '<div class="list_items_setup">';
		echo '<div>';
			print_checkbox ("check_closed_incidents", 1, $config["check_closed_incidents"], false, __('Check closed tickets when running workflow rules'));
		echo '</div>';
		echo '<div>';
			print_input_text ("days_check_closed_incidents", $config["days_check_closed_incidents"], '', 5, 255, false, __('Days to check closed tickets'));
		echo '</div>';
	echo '</div>';

	enterprise_hook("groups_email_sending_options", array('setup', false, false));
}
echo '<div>';
	echo '<h3>' . __('Customization') . '</h3>';
echo '</div>';
echo '<div class="list_items_setup">';
	echo '<div class="special_case_ul">';
		echo '<label>' . __('Status') . '</label>';
		echo '<ul>';
			$status = get_db_all_rows_in_table ('tincident_status');
			foreach ($status as $stat) {
				echo "<li>" . print_input_text ('status['.$stat['id'].']', $stat['name'],'', 35, 255, true) . "<li>";
			}
		echo '</ul>';
	echo '</div>';

	echo '<div class="special_case_ul">';
		echo '<label>' . __('Resolution') . '</label>';
		echo '<ul>';
			$resolutions = get_db_all_rows_in_table ('tincident_resolution');
			foreach ($resolutions as $resolution) {
				echo "<li>" . print_input_text ('resolutions['.$resolution['id'].']', $resolution['name'], '', 35, 255, true) . "<li>";
			}
		echo '</ul>';
	echo '</div>';

	echo '<div class="special_case_ul">';
		echo '<label>' . __('Special day') . '</label>';
		echo '<div>';
			print_checkbox ("working_weekends", 1, $config["working_weekends"], false, __("Weekends are working days"));
		echo '</div>';
		echo '<div class = "special_case_div">';
			echo '<div>';
				echo "<input id='new_day' type='text' name='new_day' width='15' size='15'>";
			echo '</div>';
			echo '<div>';
				echo "<input type='submit' class='sub create' name='add_day' value='".__("Add")."'>";
			echo '</div>';
		echo '</div>';
		echo '<div class = "special_case_div">';
			$holidays_array = calendar_get_holidays();
			if ($holidays_array == false) {
				echo '<div>';
					echo __("No holidays defined");
				echo '</div>';
			}
			else{
				foreach ($holidays_array as $ha) {
					echo '<ul>';
						echo "<li>" . $ha["day"] . "<li>";
						echo "<li>" . "<a href='index.php?sec=godmode&sec2=godmode/setup/incidents_setup&del_day=1&day=".$ha["id"]."'><img src='images/cross.png'></a>" . "<li>";
					echo '</ul>';
				}
			}
		echo '</div>';
	echo '</div>';
echo '</div>';

echo "<div class='button-form'>";
	print_input_hidden ('update', 1);
	print_submit_button (__('Update'), 'upd_button', false, 'class="sub upd"');
echo "</div>";

echo '</form>';
?>

<script type="text/javascript" src="include/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="include/languages/date_<?php echo $config['language_code']; ?>.js"></script>
<script type="text/javascript" src="include/js/integria_date.js"></script>

<script>
add_datepicker ("#new_day", null);
</script>
