<?php

// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2012 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// Load global vars

global $config;

check_login ();

enterprise_include ('godmode/usuarios/configurar_usuarios.php');

if (! give_acl ($config["id_user"], 0, "UM")) {
	audit_db($config["id_user"], $config["REMOTE_ADDR"], "ACL Violation","Trying to access user field list");
	require ("general/noaccess.php");
	exit;
}

$delete = get_parameter("delete");

if ($delete) {
	$id = get_parameter("id");

	$sql = sprintf("DELETE FROM tuser_field WHERE id = %d", $id);

	$res = process_sql($sql);

	if ($res) {
		echo ui_print_success_message (__('Field deleted'), '', true, 'h3', true);
	} else {
		echo ui_print_error_message (__('There was a problem deleting field'), '', true, 'h3', true);
	}
}

$id_field = get_parameter ('id_field');
$add_field = (int) get_parameter('add_field', 0);
$update_field = (int) get_parameter('update_field', 0);

$label = '';
$type = '';
$combo_value = '';

$up = (bool) get_parameter('up', 0);
$down = (bool) get_parameter('down', 0);

if ($up) {
	$id_to_up = $id_field;

	$elem_old_order = get_db_value_filter ('field_order', 'tuser_field', array('id' => $id_to_up));
	$less_than_elem_to_up = get_db_all_rows_sql("SELECT id, field_order FROM tuser_field WHERE field_order < " . $elem_old_order);

	$max_from_less_elements = 0;
	$id_from_less_elements = 0;
	foreach ($less_than_elem_to_up as $less) {
		if ($less['field_order'] > $max_from_less_elements) {
			$max_from_less_elements = $less['field_order'];
			$id_from_less_elements = $less['id'];
		}
	}

	db_process_sql_update('tuser_field', array('field_order' => $max_from_less_elements), array('id' => $id_to_up));
	db_process_sql_update('tuser_field', array('field_order' => $elem_old_order), array('id' => $id_from_less_elements));
}
if ($down) {
	$id_to_down = $id_field;

	$elem_old_order = get_db_value_filter ('field_order', 'tuser_field', array('id' => $id_to_down));
	$higher_than_elem_to_up = get_db_all_rows_sql("SELECT id, field_order FROM tuser_field WHERE field_order > " . $elem_old_order);

	$min_from_higher_elements = $higher_than_elem_to_up[0]['field_order'];
	$id_from_higher_elements = $higher_than_elem_to_up[0]['id'];
	foreach ($higher_than_elem_to_up as $higher) {
		if ($higher['field_order'] < $min_from_higher_elements) {
			$min_from_higher_elements = $higher['field_order'];
			$id_from_higher_elements = $higher['id'];
		}
	}

	db_process_sql_update('tuser_field', array('field_order' => $min_from_higher_elements), array('id' => $id_to_down));
	db_process_sql_update('tuser_field', array('field_order' => $elem_old_order), array('id' => $id_from_higher_elements));
}

if ($add_field) {
	$value = array();
	$value["label"] = get_parameter("label");
	$value["type"] = get_parameter("type");
	$value["combo_value"] = get_parameter("combo_value");
	$value["field_order"] = get_db_value ('MAX(field_order)', 'tuser_field') + 1;
	$value["linked_value"] = get_parameter("linked_value");
	$value["parent"] = get_parameter ("parent");

	$error_linked = false;

	if ($value['type'] == 'combo') {
		if ($value['combo_value'] == '')
			$error_combo = true;
	}

	if ($value['type'] == 'linked') {
		if ($value['linked_value'] == '')
			$error_linked = true;
	}
	
	if ($value['label'] == '') {
		echo ui_print_error_message (__('Empty field name'), '', true, 'h3', true);
	} else if ($error_combo) {
		echo ui_print_error_message (__('Empty combo value'), '', true, 'h3', true);
	}
    else if ($error_linked) {
		echo ui_print_error_message (__('Empty linked value'), '', true, 'h3', true);
	}
	else {

		$result_field = process_sql_insert('tuser_field', $value);
		
		if ($result_field === false) {
			echo ui_print_error_message (__('Field could not be created'), '', true, 'h3', true);
		} else {
			echo ui_print_success_message (__('Field created successfully'), '', true, 'h3', true);
			$id_field = $result_field;
		}
	}

}

if ($update_field) { //update field to incident type
	$id_field = get_parameter ('id_field');
	
	$value_update['label'] = get_parameter('label');
	$value_update['type'] = get_parameter ('type');
	$value_update['combo_value'] = get_parameter ('combo_value', '');
	$value_update["linked_value"] = get_parameter("linked_value");
	$error_update = false;
	$error_linked = false;

	if ($value_update['type'] == "combo") {
		if ($value_update['combo_value'] == '') 
			$error_update = true;
	} 

	if ($value_update['type'] == 'linked') {
		if ($value_update['linked_value'] == '')
			$error_update = true;
	}

	if ($error_update) {
		echo ui_print_error_message (__('Field could not be updated. Empty combo value'), '', true, 'h3', true);
	} else {
		$result_update = process_sql_update('tuser_field', $value_update, array('id' => $id_field));
		
		if ($result_update === false) {
			echo ui_print_error_message (__('Field could not be updated'), '', true, 'h3', true);
		} else {
			echo ui_print_success_message (__('Field updated successfully'), '', true, 'h3', true);
		}
	}
}

echo "<h2>".__("User fields")."</h2>";
echo "<h4>".__("List fields")."</h4>";
		
$user_fields = get_db_all_rows_sql ("SELECT * FROM tuser_field ORDER BY field_order");

if ($user_fields === false) {
	$user_fields = array ();
}

$table = new StdClass();
$table->width = '100%';
$table->class = 'listing';
$table->data = array ();
$table->head = array();
$table->style = array();
$table->size = array ();
$table->size[0] = '30%';
$table->size[1] = '20%';
$table->size[2] = '30%';

$table->head[0] = __("Name field");
$table->head[1] = __("Type");
$table->head[2] = __("Value");
$table->head[4] = __("Action");

$data = array();
$index = 0;
if (!empty($user_fields)) {
	foreach ($user_fields as $field) {
		$url_update = "index.php?sec=users&sec2=godmode/usuarios/user_field_editor&id_field=".$field['id'];
		$url_up = "index.php?sec=users&sec2=godmode/usuarios/user_field_list&id_field=".$field['id'] . "&up=1";
		$url_down = "index.php?sec=users&sec2=godmode/usuarios/user_field_list&id_field=".$field['id'] . "&down=1";
		
		if ($field['label'] == '') {
			$data[0] = '';
		} else {
			$data[0] = $field["label"];
		}
		
		if ($field_type = '') {
			$data[1] = '';
		} else {
			$data[1] = $field["type"];
		}
		
		if ($field["type"] == "combo") {
			$data[2] = $field["combo_value"];
		} else {
			$data[2] = "";
		}
				
		$data[4] = "<a
		href='" . $url_update . "'>
		<img src='images/wrench.png' border=0 /></a>";
		
		$data[4] .= "<a href='#' onClick='javascript: show_validation_delete_general(\"delete_user_fields\",".$field['id'].",0,0,0);'><img src='images/cross.png' title='".__('Delete')."'></a>";
		
		if ($index != 0) {
			$data[4] .= "<a href='" . $url_up . "'><img src='images/flecha-arriba.png' border=0 title='".__('Up')."'></a>";
		}
		if ($index < (count($user_fields) - 1)) {
			$data[4] .= "<a href='" . $url_down . "'><img src='images/flecha-abajo.png' border=0 title='".__('Down')."'></a>";
		}

		array_push ($table->data, $data);

		$index++;
	}
	print_table($table);
} else {
	echo "<h2 class='error'>".__("No fields")."</h4>";
}
echo "<form id='form-add_field' name=dataedit method=post action='index.php?sec=users&sec2=godmode/usuarios/user_field_editor'>";
	echo "<div class='button-form'>";
		print_submit_button (__('Create'), 'create_btn', false, 'class="sub create"', false);
	echo "</div>";
echo "</form>";
echo "<div class= 'dialog ui-dialog-content' title='".__("Delete")."' id='item_delete_window'></div>";
?>