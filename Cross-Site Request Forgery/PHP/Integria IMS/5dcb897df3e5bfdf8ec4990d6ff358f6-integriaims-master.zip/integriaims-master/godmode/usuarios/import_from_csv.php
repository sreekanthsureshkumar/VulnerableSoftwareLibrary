<?php
// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2008-2012 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

check_login ();

require_once('include/functions_user.php');

echo "<h2>" . __('IMPORT USERS'). "</h2>";
echo "<h4>" . __('FROM CSV') . integria_help ("import_from_csv", true) . "</h4>";

$upload_file = (int) get_parameter('upload_file');
$group = (int)get_parameter('group');
$profile = (int)get_parameter('perfil', 1);
$nivel = (int)get_parameter('nivel');
$pass_policy = (int)get_parameter('pass_policy');
$avatar_param = get_parameter('avatar');
//only avatar name (without extension)
$avatar_param = explode('.', $avatar_param);
$avatar = $avatar_param[0];

if ($upload_file) {
	if ($_FILES["file"]["error"] == 0) {

		if (($_FILES["file"]["type"] != 'text/csv') && ($_FILES["file"]["type"] != 'application/vnd.ms-excel')) {
			echo ui_print_error_message (__('Unsupported file type'), '', true, 'h3', true);
		}
		else {
			load_file ($_FILES["file"]["tmp_name"], $group, $profile, $nivel, $pass_policy, $avatar);
		}
	}
}

$table = new StdClass();
$table->width = '100%';
$table->class = 'search-table search-table_new';
$table->size = array ();
$table->size[0] = '25%';
$table->size[1] = '25%';
$table->size[2] = '25%';
$table->size[3] = '25%';
$table->colspan = array ();
$table->data = array ();

if(!isset($id_group)){
	$id_group = '';
}
$table->data[0][0] = combo_groups_visible_for_me ($config['id_user'], 'group', 0, 'UM', $id_group, true);

$table->data[0][1] = "<label>".__('Profiles')."</label>";
$table->data[0][1] .= "<select name='perfil' class='w155' style='width: 218px;' >";

	$sql='SELECT * FROM tprofile ORDER BY name';
	$result=get_db_all_rows_sql($sql);
	if( isset($result) && is_array($result) ){
		foreach ($result as $key => $value) {
			$table->data[0][1] .= "<option value='".$value["id"]."'>".$value["name"];
		}
	}

$table->data[0][1] .= '</select>';

$table->data[0][2] = "<label>".__('Global profile')."</label>";
$table->data[0][2] .= __('Standard user').'&nbsp;<input type="radio" class="chk" name="nivel" value="0" checked>';
$table->data[0][2] .= "&nbsp;&nbsp;&nbsp;&nbsp;";
$table->data[0][2] .= __('External user').'&nbsp;<input type="radio" class="chk" name="nivel" value="-1">';

$table->data[0][3] = "<label>".__('Enable policy password')."</label>";
$table->data[0][3] .= __('Yes').'&nbsp;<input type="radio" class="chk" name="pass_policy" value="1">';
$table->data[0][3] .= "&nbsp;&nbsp;&nbsp;&nbsp;";
$table->data[0][3] .= __('No').'&nbsp;<input type="radio" class="chk" name="pass_policy" value="0" checked>';

$ficheros = list_files('images/avatars/', "png", 1, 0, "small");
$avatar_forlist = $avatar . ".png";
$table->data[1][0] = print_select ($ficheros, "avatar", $avatar_forlist, '', '', 0, true, 0, false, __('Avatar'));

$table->data[1][1] = "<label>".__('Load file')."</label>";
$table->data[1][1] .= '<input class="sub" name="file" type="file" />';
$table->colspan[1][2] = 2;
$table->data[1][2] = "<div class='button-form'>";
$table->data[1][2] .= '<input type="submit" class="sub next" value="' . __('Upload File') . '" />';
$table->data[1][2] .= '</div>';
echo '<form enctype="multipart/form-data" action="index.php?sec=users&sec2=godmode/usuarios/import_from_csv" method="POST">';
	print_input_hidden ('upload_file', 1);
	print_table ($table);
echo '</form>';

?>
