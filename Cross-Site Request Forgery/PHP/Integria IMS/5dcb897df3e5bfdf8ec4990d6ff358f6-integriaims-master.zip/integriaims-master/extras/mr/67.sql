ALTER TABLE `tattachment` MODIFY COLUMN `id_contract` mediumint(8) unsigned NOT NULL default 0;

alter table tusuario ADD user_incidents_filter int(10) not null default 0;

alter table tcontract_type_field ADD field_order int(10) not null default 0;

UPDATE tcontract_type_field c, (SELECT @n := 0) m SET c.field_order = @n := @n + 1;

alter table tuser_field ADD field_order int(10) not null default 0;

UPDATE tuser_field c, (SELECT @n := 0) m SET c.field_order = @n := @n + 1;

alter table tincident_type_field ADD field_order int(10) not null default 0;

UPDATE tincident_type_field c, (SELECT @n := 0) m SET c.field_order = c.order;

alter table tcompany_field ADD field_order int(10) not null default 0;

UPDATE tcompany_field c, (SELECT @n := 0) m SET c.field_order = @n := @n + 1;

alter table tcompany_field_section ADD expand int(1) not null default 0;