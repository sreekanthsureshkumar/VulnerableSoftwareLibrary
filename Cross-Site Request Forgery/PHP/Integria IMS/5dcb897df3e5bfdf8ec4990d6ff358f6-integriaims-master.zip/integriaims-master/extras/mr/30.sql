-- INTEGRIA - the ITIL Management System
-- http://integria.sourceforge.net
-- ==================================================
-- Copyright (c) 2007-2012 Ártica Soluciones Tecnológicas
-- http://www.artica.es  <info@artica.es>

-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; version 2
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

INSERT INTO `tobject_type_field` (`id_object_type`, `label`, `type`, `combo_value`, `external_table_name`, `external_reference_field`, `parent_table_name`, `parent_reference_field`, `unique`, `inherit`, `show_list`, `not_allow_updates`) VALUES (2,'SimID','text',NULL,NULL,NULL,0,1,0,0,0,0);
