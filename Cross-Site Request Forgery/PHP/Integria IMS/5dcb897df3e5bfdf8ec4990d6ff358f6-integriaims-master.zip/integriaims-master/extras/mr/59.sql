ALTER TABLE tcompany_field_data DROP FOREIGN KEY tcompany_field_data_ibfk_1;

ALTER TABLE tcompany_field_data ADD CONSTRAINT tcompany_field_data_ibfk_1 FOREIGN KEY (id_company_field) REFERENCES tcompany_field (id) ON DELETE CASCADE;

alter table tcompany_field add show_in_search int(1) not null default 0;

alter table tcompany_field add show_in_list int(1) not null default 0;