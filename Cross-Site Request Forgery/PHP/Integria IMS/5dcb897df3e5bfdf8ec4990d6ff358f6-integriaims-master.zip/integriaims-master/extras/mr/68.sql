-- INTEGRIA - the ITIL Management System
-- http://integria.sourceforge.net
-- ==================================================
-- Copyright (c) 2007-2012 Ártica Soluciones Tecnológicas
-- http://www.artica.es  <info@artica.es>

-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; version 2
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

--
-- tworkunit
--
ALTER TABLE `tworkunit` ADD COLUMN `realization_date` datetime NOT NULL default '0000-00-00 00:00:00';
UPDATE `tworkunit` SET `realization_date` = `timestamp`;

--
-- tcompany_field
--
ALTER TABLE tcompany_field ADD COLUMN show_in_invoice int(1) not null default 0;

ALTER TABLE tkb_data ADD COLUMN rating_total int(25) not null default 0;
ALTER TABLE tkb_data ADD COLUMN rating_votes int(25) not null default 0;