CREATE TABLE `tbackup` ( 
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `real_name` varchar(200) NOT NULL,
  `mode` tinyint(1) unsigned NOT NULL,
  `backup_date` datetime NOT NULL,
  `id_programming` bigint(20) unsigned NOT NULL default 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tbackup_programming` ( 
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, 
  `name` varchar(200) NOT NULL,
  `mode` tinyint(1) unsigned NOT NULL,
  `periodicity` bigint(20) unsigned NOT NULL,
  `last_executed` datetime NOT NULL,
  `mail` varchar(200) NOT NULL default "",
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO tbackup_programming (id, name, mode, periodicity, last_executed) VALUES 
(0, 'Weekly backup by default', 2, 604800, "0000-00-00 00:00:00");

INSERT INTO `tconfig` (`token`, `value`) VALUES ('backup_max_days', 30);