CREATE TABLE `tmilestone_field` ( 
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT, 
  `label` varchar(100) NOT NULL DEFAULT '', 
  `type` enum('textarea','text','combo', 'checkbox') DEFAULT 'text', 
  `combo_value` text,
  `field_order` mediumint(8) unsigned default 0,
  PRIMARY KEY (`id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tmilestone_field_data` ( 
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, 
  `id_milestone` varchar(60) NOT NULL DEFAULT '',
  `id_milestone_field` mediumint(8) unsigned NOT NULL, 
  `data` text, PRIMARY KEY (`id`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8;