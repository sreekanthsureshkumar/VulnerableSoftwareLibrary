ALTER TABLE `tcompany_field` MODIFY `type` enum ('text', 'textarea', 'combo', 'linked', 'numeric', 'date', 'checkbox') DEFAULT 'text';
ALTER TABLE `tcontract_type_field` MODIFY `type` enum ('text', 'textarea', 'combo', 'linked', 'numeric', 'date', 'checkbox') DEFAULT 'text';
ALTER TABLE `tuser_field` MODIFY `type` enum('textarea','text','combo', 'checkbox') DEFAULT 'text';
ALTER TABLE `tincident_type_field` MODIFY `type` enum('text', 'textarea', 'combo', 'linked', 'numeric', 'date', 'checkbox') DEFAULT 'text';
ALTER TABLE `tobject_type_field` MODIFY `type` enum ('numeric', 'text', 'combo', 'external', 'date', 'checkbox') default 'text';
ALTER TABLE `tworkflow_condition` ADD COLUMN `field_order` mediumint(8) unsigned default 0;
UPDATE `tworkflow_condition` c, (SELECT @n := 0) m SET c.field_order = @n := @n + 1;
ALTER TABLE `tworkflow_condition` ADD COLUMN `operation` mediumint(8) unsigned default 1;
