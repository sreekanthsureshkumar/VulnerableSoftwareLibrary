ALTER TABLE `tprofile` ADD column `hr` tinyint(1) NOT NULL default '0';
INSERT INTO `tprofile` (`name`,`ir`,`iw`,`im`,`um`,`dm`,`fm`,`ar`,`aw`,`am`,`pr`,`pm`,`kr`,`kw`,`km`,`vr`,`vw`,`vm`,`wr`,`ww`,`wm`,`cr`,`cw`,`cm`,`cim`,`clm`,`cn`,`frr`,`frw`,`frm`,`si`,`qa`,`rr`,`hr`) VALUES ('Human&#x20;Resources',0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1);
INSERT INTO `ttask` (`id`, `id_project`, `id_parent_task`, `name`, `description`, `completion`, `priority`, `dep_type`, `start`) VALUES (-5,-1,0,'Visit to the doctor','',0,0,0,'0000-00-00');
ALTER TABLE `tattachment` ADD COLUMN `id_wu` bigint(20) NOT NULL default '0';
