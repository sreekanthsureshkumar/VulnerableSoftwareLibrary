alter table tworkflow_condition add creation_in_vac tinyint(1) unsigned NOT NULL DEFAULT 0;

alter table tworkflow_condition add creation_in_weekends tinyint(1) unsigned NOT NULL DEFAULT 0;

alter table tworkflow_condition add creation_from datetime NOT NULL default '0000-00-00 00:00:00';

alter table tworkflow_condition add creation_to datetime NOT NULL default '0000-00-00 00:00:00';