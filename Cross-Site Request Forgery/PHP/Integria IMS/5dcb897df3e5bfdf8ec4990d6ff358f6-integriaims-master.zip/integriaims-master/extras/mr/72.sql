-- INTEGRIA - the ITIL Management System
-- http://integria.sourceforge.net
-- ==================================================
-- Copyright (c) 2007-2012 Ártica Soluciones Tecnológicas
-- http://www.artica.es  <info@artica.es>

-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; version 2
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

--
-- tdownload_type
--
ALTER TABLE `tdownload_type` ADD `id_parent`  mediumint(8) unsigned NOT NULL default 0;

--
-- tprofile
--
ALTER TABLE `tprofile` ADD `cim` tinyint(1) NOT NULL default '0' AFTER `cm`;
ALTER TABLE `tprofile` ADD `clm` tinyint(1) NOT NULL default '0' AFTER `cm`;
--
-- tgrupo
--
ALTER TABLE `tgrupo` ADD `mail_options` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_creation_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_close_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_update_status_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_update_owner_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_update_priority_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_update_group_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_update_other_ticket` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_create_WU` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_create_attach` int(1) NOT NULL default 0;
ALTER TABLE `tgrupo` ADD `mail_validate_work_order` int(1) NOT NULL default 0;

--
-- tincident_contact_reporters
--
DROP TABLE tincident_contact_reporters;

--
-- tcustom_screen_widget
--
DELETE FROM tcustom_screen_widget WHERE name = 'View&#x20;my&#x20;tickets&#x20;&#40;Simple&#41;';
DELETE FROM tcustom_screen_widget WHERE name = 'Create&#x20;ticket&#x20;&#40;Simple&#41;';

--
-- temail_template
--
INSERT INTO temail_template (name, id_group, template_action, predefined_templates) VALUES ('validate_WO', 0, 24, 1), ('validate_WO_subject', 0, 25, 1);

-- ---------------------------------------------------------------------
-- Table tcontract_template
-- ---------------------------------------------------------------------
CREATE TABLE `tcontract_template` (
    `id` int(10) unsigned NOT NULL auto_increment,
    `name` varchar(100) NOT NULL default '',
    `description` text NULL default NULL,
    `content` text NULL default NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tcontract_template` (`name`, `description`, `content`) VALUES ("Default template", "Plantilla predefinida", "&lt;style&#x20;type=&quot;text/css&quot;&gt;&#x0d;&#x0a;&#x09;&#x09;@import&#x20;url&#40;&#039;https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700,800,900&#039;&#41;;&#x0d;&#x0a;&#x0d;&#x0a;&#x09;&#x09;html&#x20;{margin:&#x20;0;}&#x0d;&#x0a;&#x0d;&#x0a;&#x09;&#x09;.tg{border-collapse:collapse;border-spacing:0;}&#x0d;&#x0a;&#x09;&#x09;.tg&#x20;td{font-family:&#039;Open&#x20;Sans&#039;,&#x20;sans-serif,&#x20;Arial;font-size:14px;padding:5px&#x20;10px;overflow:hidden;word-break:normal;}&#x0d;&#x0a;&#x09;&#x09;.tg&#x20;th{font-family:&#039;Open&#x20;Sans&#039;,&#x20;sans-serif,&#x20;Arial;font-size:14px;font-weight:normal;padding:5px&#x20;10px;overflow:hidden;word-break:normal;}&#x0d;&#x0a;&#x09;&#x09;.tg&#x20;.tg-yw4l{vertical-align:middle}&#x0d;&#x0a;&#x0d;&#x0a;&#x09;&#x09;.orange{color:#FF9000;}&#x0d;&#x0a;&#x09;&#x09;.header{&#x0d;&#x0a;&#x09;&#x09;&#x09;background-color:&#x20;#333;&#x0d;&#x0a;&#x09;&#x09;&#x09;color:#FFF;&#x0d;&#x0a;&#x09;&#x09;}&#x0d;&#x0a;&#x09;&#x09;.header&#x20;td{&#x0d;&#x0a;&#x09;&#x09;&#x09;color:#FFF;&#x0d;&#x0a;&#x09;&#x09;&#x09;border-bottom:&#x20;5px&#x20;solid&#x20;#FF9000;&#x0d;&#x0a;&#x09;&#x09;&#x09;padding:&#x20;20px&#x20;30px;&#x0d;&#x0a;&#x09;&#x09;}&#x0d;&#x0a;&#x09;&#x09;.gris{&#x0d;&#x0a;&#x09;&#x09;&#x09;background-color:&#x20;#f3f3f3;&#x0d;&#x0a;&#x09;&#x09;&#x09;border-radius:&#x20;3px;&#x0d;&#x0a;&#x09;&#x09;}&#x0d;&#x0a;&#x0d;&#x0a;&#x09;&#x09;.licencia{&#x0d;&#x0a;&#x09;&#x09;&#x09;border-spacing:&#x20;10px;&#x0d;&#x0a;&#x09;&#x09;}&#x0d;&#x0a;&#x0d;&#x0a;&#x09;&#x09;&#x0d;&#x0a;&lt;/style&gt;&#x0d;&#x0a;&lt;table&#x20;class=&quot;tg&quot;&#x20;style=&quot;width:&#x20;842px;&quot;&gt;&#x0d;&#x0a;&lt;tbody&gt;&#x0d;&#x0a;&lt;tr&#x20;class=&quot;header&quot;&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;font-size:&#x20;22px;&#x20;padding-left:&#x20;20px;&quot;&#x20;colspan=&quot;2&quot;&gt;Integria&#x20;IMS&#x20;&lt;br&gt;&#x20;&lt;strong&gt;Contract&#x20;template&lt;/strong&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;text-align:&#x20;right;&quot;&gt;&lt;img&#x20;src=&quot;https://integriaims.com/downloads/logo-integria.png&quot;&#x20;alt=&quot;&quot;&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;text-align:&#x20;right;&#x20;padding-top:&#x20;30px;&#x20;padding-bottom:&#x20;20px;&#x20;padding-right:&#x20;60px;&quot;&#x20;colspan=&quot;3&quot;&gt;Madrid,&#x20;_format_long_time_&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;padding-top:&#x20;20px;&#x20;padding-bottom:&#x20;20px;&#x20;line-height:&#x20;25px;&#x20;padding-left:&#x20;60px;&quot;&#x20;colspan=&quot;3&quot;&gt;&lt;br&gt;&lt;span&#x20;class=&quot;orange&quot;&gt;&amp;copy;&#x20;_format_annual_date_&#x20;&amp;Aacute;rtica&#x20;Soluciones&#x20;Tecnol&amp;oacute;gicas&lt;/span&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;50px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;50px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;50px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;colspan=&quot;3&quot;&gt;&#x0d;&#x0a;&lt;table&#x20;class=&quot;licencia&quot;&#x20;style=&quot;margin:&#x20;0&#x20;auto;&quot;&gt;&#x0d;&#x0a;&lt;tbody&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;text-align:&#x20;center;&quot;&#x20;rowspan=&quot;4&quot;&gt;&lt;img&#x20;src=&quot;https://integriaims.com/downloads/candado-naranja.png&quot;&#x20;alt=&quot;&quot;&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&gt;&lt;span&#x20;class=&quot;orange&quot;&gt;Name&#x20;contract:&lt;/span&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&#x20;gris&quot;&gt;_name_contract_&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&gt;&lt;span&#x20;class=&quot;orange&quot;&gt;Number&#x20;contract:&lt;/span&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&#x20;gris&quot;&gt;_contract_number_&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-6k2t&quot;&gt;&lt;span&#x20;class=&quot;orange&quot;&gt;Custom&#x20;field:&lt;/span&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-6k2t&#x20;gris&quot;&gt;_custom_1_&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-6k2t&quot;&gt;&lt;span&#x20;class=&quot;orange&quot;&gt;License&#x20;Period:&lt;/span&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-6k2t&#x20;gris&quot;&gt;_date_begin_&#x20;-&#x20;_date_end_&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;/tbody&gt;&#x0d;&#x0a;&lt;/table&gt;&#x0d;&#x0a;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;100px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;100px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;100px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;padding-left:&#x20;60px;&quot;&#x20;colspan=&quot;2&quot;&gt;&lt;span&#x20;class=&quot;orange&quot;&gt;&lt;strong&gt;_company_name_&lt;/strong&gt;&lt;/span&gt;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;padding-left:&#x20;60px;&quot;&#x20;colspan=&quot;2&quot;&gt;_company_address_&#x20;_company_country_.&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;60px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;60px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;60px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;tr&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;20px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;20px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;td&#x20;class=&quot;tg-yw4l&quot;&#x20;style=&quot;height:&#x20;20px;&quot;&gt;&amp;nbsp;&lt;/td&gt;&#x0d;&#x0a;&lt;/tr&gt;&#x0d;&#x0a;&lt;/tbody&gt;&#x0d;&#x0a;&lt;/table&gt;");

--
-- tprofile
--
ALTER TABLE `tattachment` ADD `template` tinyint(1) NOT NULL default '0';

ALTER TABLE `tworkflow_condition` ADD COLUMN `id_company` int(10) NOT NULL default 0;
ALTER TABLE `tworkflow_condition` ADD COLUMN `id_inventory` int(10) NOT NULL default 0;

--
-- ttask
--
ALTER TABLE `ttask` ADD `set_hours` tinyint unsigned NOT NULL DEFAULT 0;