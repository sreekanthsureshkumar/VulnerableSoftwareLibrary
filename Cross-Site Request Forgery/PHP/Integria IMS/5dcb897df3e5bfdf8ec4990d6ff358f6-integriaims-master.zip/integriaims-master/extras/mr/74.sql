ALTER TABLE `tobject_type_field` MODIFY `type` enum ('numeric', 'text', 'combo', 'external', 'date', 'checkbox') default 'text';
ALTER TABLE `tuser_field` ADD `linked_value` varchar(4096) default NULL;
ALTER TABLE `tuser_field` ADD `parent` mediumint(8) unsigned default 0;
ALTER TABLE `tuser_field` MODIFY `type` enum('textarea','text','combo', 'linked', 'checkbox') DEFAULT 'text';
ALTER TABLE tinventory DROP FOREIGN KEY tinventory_ibfk_1;
DROP TABLE tinventory_statuses;