ALTER TABLE `tattachment` ADD `id_project` bigint(20) NOT NULL DEFAULT '0' AFTER `id_company`;
