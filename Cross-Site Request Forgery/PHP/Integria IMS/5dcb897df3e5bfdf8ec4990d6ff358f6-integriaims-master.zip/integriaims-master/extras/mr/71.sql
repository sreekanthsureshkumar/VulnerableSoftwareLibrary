CREATE TABLE `tinventory_statuses` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE tinventory MODIFY status varchar(200);

ALTER TABLE `tinventory` ADD FOREIGN KEY (`status`) REFERENCES tinventory_statuses(`name`) ON UPDATE CASCADE;

INSERT INTO tinventory_statuses (id, name) VALUES 
(0, 'New'),
(1, 'In&#x20;use'),
(2, 'Unused'),
(3, 'Issued');

INSERT INTO `tconfig` (`token`, `value`) VALUES ('disable_ticket_score', 0);

ALTER TABLE `tincidencia` ADD `never_show_score` tinyint unsigned NOT NULL DEFAULT 0;

