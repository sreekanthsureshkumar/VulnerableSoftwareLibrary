ALTER TABLE tcontract_field ADD COLUMN show_in_search int(1) NOT NULL DEFAULT 0;

ALTER TABLE tworkunit ADD COLUMN internal tinyint UNSIGNED NOT NULL DEFAULT 0;