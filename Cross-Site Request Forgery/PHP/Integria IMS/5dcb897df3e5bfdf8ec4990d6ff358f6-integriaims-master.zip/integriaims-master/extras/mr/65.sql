ALTER TABLE `tgrupo` ADD COLUMN `default_status` mediumint(8) unsigned NOT NULL default 1;
