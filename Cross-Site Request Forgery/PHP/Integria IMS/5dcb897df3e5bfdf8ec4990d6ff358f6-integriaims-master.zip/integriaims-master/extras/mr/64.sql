ALTER TABLE `tcontract` ADD `id_contract_type` mediumint(8) unsigned NULL;

CREATE TABLE `tcontract_type` (
	`id` mediumint(8) unsigned NOT NULL auto_increment,
	`name` varchar(100) NOT NULL default '',
	`description` text NULL default NULL,
	PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tcontract_type_field` ( 
	`id` mediumint(8) unsigned NOT NULL auto_increment, 
	`id_contract_type` mediumint(8) unsigned NOT NULL, 
	`label` varchar(100) NOT NULL default '', 
	`type` enum('text', 'textarea', 'combo', 'linked', 'numeric', 'date') DEFAULT 'text',
	`combo_value` LONGTEXT default NULL,
	`show_in_list` tinyint(1) unsigned NOT NULL default 0,
	`parent` mediumint(8) unsigned default 0,
	`linked_value` LONGTEXT default NULL,
	`order` mediumint(8) unsigned default 0,
	PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tcontract_type_field_data` ( 
	`id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, 
	`id_contract` mediumint(8) unsigned NOT NULL,
	`id_contract_type_field` mediumint(8) unsigned NOT NULL, 
	`data` text, 
	PRIMARY KEY (`id`),
	FOREIGN KEY (`id_contract_type_field`) REFERENCES tcontract_type_field(`id`)
          ON DELETE CASCADE,
    FOREIGN KEY (`id_contract`) REFERENCES tcontract(`id`)
          ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;