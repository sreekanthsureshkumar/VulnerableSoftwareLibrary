CREATE TABLE tcompany_field_section (
    id int(10) NOT NULL auto_increment,
    name varchar(100) NOT NULL default '',
    description text NULL default NULL,
    PRIMARY KEY  (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO tcompany_field_section VALUES (1, 'Without section', 'Company custom fields without section');

ALTER TABLE tcompany_field ADD id_section mediumint(8) unsigned not null default 1;