<?php

// INTEGRIA IMS v3.0
// http://www.integriaims.com
// ===========================================================
// Copyright (c) 2007-2011 Artica, info@artica.es

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// (LGPL) as published by the Free Software Foundation; version 2

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

/* -------------------------------------------------------------------------- */
/* ------ Script to purge attachment dir (files without entry in db) -------- */
/* -------------------------------------------------------------------------- */

$argc = $_SERVER['argc'];
$argv = $_SERVER['argv'];

if ($argc != 5) {
    echo 'Usage: ' . $argv[0] . ' dbhost dbuser dbpass dbname'."\n";
    return 1;
}

// Get integria dir and attachment dir
$dir = realpath (dirname (__FILE__).'/..');
$attachment_dir = $dir . "/attachment";

$dbhost = $argv[1];
$dbuser = $argv[2];
$dbpass = $argv[3];
$dbname = $argv[4];

// Init mysqli
$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

// Mysqli connection error handler
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL caused by: \n";
    echo "Errno: " . $mysqli->connect_errno . "\n";
    echo "Error: " . $mysqli->connect_error . "\n";
    return 1;
}

$sql = "SELECT id_attachment, filename FROM tattachment";

// Mysqli query error handler
if (!$attachments = $mysqli->query($sql)) {
    echo "Failed to launch the query caused by: \n";
    echo "Query: " . $sql . "\n";
    echo "Errno: " . $mysqli->errno . "\n";
    echo "Error: " . $mysqli->error . "\n";
    return 1;
}

// If tattachment is empty
if ($attachments->num_rows === 0) {
    echo "There are no entries in the attachment table\n";
    return 1;
}

// Get a data structure of attachments with it's id and name
$attachments_filename = array();
$index = 0;
while ($attachment = $attachments->fetch_assoc()) {
    $filename = $attachment['filename'];
    $id = $attachment['id_attachment'];
    $attachments_filename[$index]['name'] = $filename;
    $attachments_filename[$index]['id'] = $id;
    $index++;
}

// Files process
$files_dir = opendir($attachment_dir);
if (file_exists($attachment_dir) && is_dir($attachment_dir)) {
    if (is_readable($attachment_dir)) {
        while ($file = readdir($files_dir)) {
            // If file is not a directory and is not from git or another dir like . or ..
            if ($file != "." && $file != ".." && $file != ".git_ignore" && !is_dir($attachment_dir . "/" . $file)) {
                $purge = true;
                // Searching in db attachments
                foreach ($attachments_filename as $attachment_filename) {
                    // Attachments store in attachment directory like "id"_"filename" and in db like "filename"
                    if ($attachment_filename['id'] . "_" . $attachment_filename['name'] == $file) {
                        $purge = false;
                    }
                }
                // If file do not exists in db
                if ($purge) {
                    if (unlink($attachment_dir . "/" . $file)) {
                        echo "File deleted: " . $file . "\n";
                    }
                    else {
                        echo "File: " . $file . " cannot be deleted" . "\n";
                    }
                }
            }
        }
    }
    else {
        echo "You don't have read permissions on this directory: " . $attachment_dir . "\n";
        return 1;
    }
}
else {
    echo "File doesn't exist or is not a directory: " . $attachment_dir . "\n";
    return 1;
}

return 0;

?>