<?php
// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2007-2010 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

global $config;

if (!isset($config["id_user"]))
	$config["id_user"] = $_SESSION['id_usuario'];

$sql_last_kbs			= "SELECT * FROM tkb_data ORDER BY timestamp DESC LIMIT 0, 5";
$result_last_kbs		= process_sql($sql_last_kbs);
$result_last_kbs		= db_process_sql($sql_last_kbs);

$sql_pop_categories		= "SELECT tkb_category.name, tkb_data.id_category, count(*) FROM tkb_data INNER JOIN tkb_category ON tkb_data.id_category = tkb_category.id GROUP BY tkb_data.id_category";
$result_pop_categories	= process_sql($sql_pop_categories);
$result_pop_categories	= db_process_sql($sql_pop_categories);
usort($result_pop_categories, function($category_1, $category_2){
	return $category_2['count(*)'] - $category_1['count(*)'];
});

$welcome_dirty			= (boolean)get_parameter('welcome_dirty');
$search_string			= trim(get_parameter('search_string'));
$selected_categories	= get_parameter('categories');
$are_there_categories	= (boolean)$selected_categories;

if ($search_string == '' and !$are_there_categories) {
	$searchbar_style	= 'width:550px; margin-right:0px';
	$magnifier_style	= 'margin-left: -46px;';
	$form_style			= 'margin-top:15%;';
	$search_value		= '';
	$wrapper_height		= max(
		(100 + (empty($result_last_kbs) ? 0 : 50) + count($result_last_kbs)*25),
		(175 + count($result_pop_categories)*21)
	);
	$wrapper_style		= 'height:'.$wrapper_height.'px;';
} else {
	$searchbar_style	= 'width:515px; margin-right:50px';
	$magnifier_style	= 'margin-left: -96px;';
	$form_style			= 'margin-top:5%;';
	$search_value		= "value='".$search_string."'";
	$wrapper_style		= 'height:85px;';
}

$form_action			= give_acl($config["id_user"], 0, "KR") ? 'index.php' : 'index.php?sec2=operation/search';

echo "<div id='welcome_page' style=''>";
echo 	"<div>";
echo 		"<form style='".$form_style."' action='".$form_action."' method='post'>";
echo 			print_input_hidden('welcome_dirty', true, true);
echo 			"<div id='wrapper' style='".$wrapper_style."''>";
echo 				"<div id='search_bar' style=''>";
echo 					"<input style='".$searchbar_style."' name='search_string' placeholder='".__('What can I help you with?')."' ".$search_value."/>";
echo 					"<img style='".$magnifier_style."' class='search-icon' src='images/lupa-grande.png'>";
echo 				"</div>";

if (give_acl($config["id_user"], 0, "KR")) {
	$options =			"<div id='search_options' style=''>";
	$options .=				"<div class='column_wrapper column_1' style='display:".(empty($result_pop_categories) ? 'none' : 'block').";'>";
	$options .=					"<h2>".__('Categories').":</h2>";
	
	foreach ($result_pop_categories as $key => $category) {
		$checked =					(!$welcome_dirty || in_array($category['id_category'], $_POST['categories'])) ? 'checked' : '';
		$options .=					"<label>";
		$options .=						"<input type='checkbox' ".$checked." name='categories[]' value='".$category['id_category']."'>&nbsp;".$category['name'];
		$options .=					"</label>";
	}
	
	$options .=				"</div>";
	$options .=				"<div class='column_wrapper column_2' style='display:".(empty($result_last_kbs) ? 'none' : 'block').";'>";
	$options .=					"<h2>".__('Recent publications').":</h2>";
	
	foreach ($result_last_kbs as $key => $row) {
		$options .=				"<p>";
		$options .=					"<a href='index.php?sec=kb&sec2=operation/kb/browse_data&view=".$row["id"]."'>";
		$options .=						safe_input(short_string($row["title"],45));
		$options .=					"</a>";
		$options .=				"</p>";
	}
	
	$options .=				"</div>";
	$options .=			"</div>";

	if ($search_string == '' and !$are_there_categories) {
		echo 				$options;
	} else {
		print_container_div('search_options', '', $options, 'closed', false);
	}
	
	echo 			"</div>";
} else {
	echo 			"<br>";
}

$sql_permissions			= "SELECT mode FROM tmenu_visibility WHERE menu_section='customers' OR menu_section='leads'";
$result_permissions			= process_sql($sql_permissions);
$result_permissions			= db_process_sql($sql_permissions);

$leads_access_authorized	= (get_db_value ('nivel', 'tusuario', 'id_usuario', $config["id_user"]) == 1) +
	(give_acl($config["id_user"], 0, "CR") * (		
		empty($result_permissions) ?
		1 :
		array_reduce($result_permissions, function($carry, $row) {
			$carry *= $row['mode'];
			return $carry;
		}, 1)
	)
);

$number_of_buttons			= $leads_access_authorized + give_acl($config["id_user"], 0, "IW") + give_acl($config["id_user"], 0, "IR");
$buttons_wrapper_style		= "padding-left:".(20 + (3-$number_of_buttons)*145)."px;";

if ($number_of_buttons != 0) {
	echo 			"<div id='welcome-buttons-wrapper' style='".$buttons_wrapper_style."'>";

	if (give_acl($config["id_user"], 0, "IW")) {
		echo 			"<div class='button-form' id='create_ticket_button'>";
		echo 				"<input name='uptbutton' type='button' class='sub welcome' value='".__('Create a ticket')."'>";
		echo 			"</div>";
	}
	if (give_acl($config["id_user"], 0, "IR")) {		
		echo 			"<div class='button-form' id='list_tickets_button'>";
		echo 				"<input name='uptbutton' type='button' class='sub welcome' value='".__('List all tickets')."'>";
		echo 			"</div>";
	}
	if ($leads_access_authorized) {		
		echo 			"<div class='button-form' id='go_to_leads_button'>";
		echo 				"<input name='uptbutton' type='button' class='sub welcome' value='".__('Go to leads')."'>";
		echo 			"</div>";
	}

	echo 			"</div>";
}

echo 			"</div>";
echo 		"</form>";
echo 	"</div>";

$wrapper_topmargin	= max(
	(0 + (empty($result_last_kbs) ? 0 : 50) + count($result_last_kbs)*25),
	(65 + count($result_pop_categories)*21)
);

echo "<script>";
echo	"$(document).ready(function() {";
echo 		"$('div.container.search_options_container h2#search_options').on('click', function() {";
echo 			"var is_open = $(this).children().first().attr('class').indexOf('down') != -1;";
echo 			"if(is_open) {";
echo 				"$('div#welcome-buttons-wrapper').css('margin-top', '".$wrapper_topmargin."px');";
echo 			"} else {";
echo 				"$('div#welcome-buttons-wrapper').css('margin-top', '0px');";
echo 			"}";
echo 		"});";
echo 		"$('#create_ticket_button').off('click').on('click', function() {";
echo 			"window.location.href=('/integria/index.php?sec=incidents&sec2=operation/incidents/incident_detail');";
echo 		"});";
echo 		"$('#list_tickets_button').off('click').on('click', function() {";
echo 			"window.location.href=('/integria/index.php?sec=incidents&sec2=operation/incidents/incident_search');";
echo 		"});";
echo 		"$('#go_to_leads_button').off('click').on('click', function() {";
echo 			"window.location.href=('/integria/index.php?sec=customers&sec2=operation/leads/lead');";
echo 		"});";
echo	"});";
echo "</script>";

// Filtering zone
$result				= false;
$auxiliary_filter	= "";
$search_offset		= get_parameter ("offset", 0);
$condition			= get_filter_by_kb_product_accessibility();

if($are_there_categories) {
	$auxiliary_filter .= " AND (".array_reduce($selected_categories, function($carry, $id_category) {
		$carry .= ' OR id_category = '.$id_category;
		return $carry;
	}, '1=0').")";
}


if ($search_string != '') {
	$processed = safe_input(implode("|", explode(" ", safe_output($search_string))));

	$sql_title_filter	= $auxiliary_filter." AND (title REGEXP '$processed' OR title LIKE '%$search_string%')";
	$sql_body_filter	= $auxiliary_filter." AND (data REGEXP '$processed' OR data LIKE '%$search_string%') AND NOT (title REGEXP '$processed' OR title LIKE '%$search_string%')";
	$sql_total_filter	= $auxiliary_filter." AND (title REGEXP '$processed' OR data REGEXP '$processed' OR title LIKE '%$search_string%' OR data LIKE '%$search_string%')";


	$title_rowcount = get_db_sql("SELECT COUNT(id) FROM tkb_data $condition $sql_title_filter");
	$total_rowcount = get_db_sql("SELECT COUNT(id) FROM tkb_data $condition $sql_total_filter");

	if ($search_offset < $title_rowcount) {
		$sql1		= "SELECT * FROM tkb_data $condition $sql_title_filter ORDER BY timestamp DESC LIMIT $search_offset, ". $config["block_size"];
		$result1	= process_sql($sql1);
		$result1	= db_process_sql($sql1);
	}

	$body_offset	= ($search_offset > $title_rowcount) ? ($search_offset - $title_rowcount) : 0;
	$size_of_pack	= ($search_offset < $title_rowcount) ? ($search_offset + $config["block_size"] - $title_rowcount) : $config["block_size"];
	$result2 		= $size_of_pack > 0;

	if ($result2) {
		$sql2		= "SELECT * FROM tkb_data $condition $sql_body_filter ORDER BY timestamp DESC LIMIT $body_offset, ". $size_of_pack;
		$result2	= process_sql($sql2);
		$result2	= db_process_sql($sql2);		
	}

	if(!$result1) {
		$result = $result2;
	} else if (!$result2) {
		$result = $result1;
	} else {
		$ids = array_map(function($element){return $element['id'];}, $result1);
		$result2_filtered = array_filter($result2, function($element) use ($ids) {
			return !in_array($element[id], $ids);
		});
		$result = array_merge($result1, $result2_filtered);	
	}
} else if ($are_there_categories){
	$total_rowcount = get_db_sql("SELECT COUNT(id) FROM tkb_data $condition $auxiliary_filter");
	$sql			= "SELECT * FROM tkb_data $condition $auxiliary_filter ORDER BY timestamp DESC LIMIT $search_offset, ". $config["block_size"];
	$result			= process_sql($sql);
	$result			= db_process_sql($sql);
}			

if ($result){
	$content = '';
	$content .= "<div>";
	$content .=		'<table width="100%" class="listing">';
	$content .=			'</tbody>';
	foreach ($result as $key=>$row) {
		$author						= get_db_value ('nombre_real', 'tusuario', 'id_usuario', $row["id_user"]);
		$category_name				= get_db_sql ("SELECT name FROM tkb_category  WHERE id = ".$row["id_category"]);
		$category_img				= get_db_sql ("SELECT icon FROM tkb_category WHERE id = ".$row["id_category"]);
		$product_name				= get_db_sql ("SELECT name FROM tkb_product WHERE id = ".$row["id_product"]);
		$product_img				= get_db_sql ("SELECT icon FROM tkb_product WHERE id = ".$row["id_product"]);

		$subtitle_last_part			= $category_name ? " under ".ucfirst($category_name)." category." : ".";
		$subtitle_last_but_one_part	= $product_name ? " for ".ucfirst($product_name). " product" : "";

		$content .=			"<tr>";

		$content .=				"<td valign='top'>";
		$content .=					"<h2 style='margin-top:0; padding-bottom:0;'>";
		$content .=						"<a href='index.php?sec=kb&sec2=operation/kb/browse_data&view=".$row["id"]."'>";
		$content .=							safe_input(short_string($row["title"],220));
		$content .=						"</a>";
		if (give_acl($config["id_user"], 0, "KW") && !get_standalone_user($config["id_user"])) {
			$content .=					"&nbsp;&nbsp;";
			$content .=					"<a href='index.php?sec=kb&sec2=operation/kb/manage_data&update=".$row['id']."'>";
			$content .=						"<img style='height:13px;' border=0 title='".__('Edit')."' src='images/application_edit.png'>";
			$content .=					"</a>";
			$content .=					"&nbsp;";
			$content .=					'<a href="index.php?sec=kb&sec2=operation/kb/browse&delete_data='.$row["id"].'" onClick="if (!confirm(\''.__('Are you sure?').'\')) return false;">';
			$content .=						"<img style='height:13px;' src='images/cross.png'>";
			$content .=					'</a>';
		}
		$content .=					"</h2>";
		$content .=					"<h3 style='margin-top:0;'>";
		$content .=						"Written by ".$author." ".human_time_comparation($row["timestamp"])." ago".$subtitle_last_but_one_part.$subtitle_last_part;
		$content .=					"</h3>";
		$content .=					"<p>".safe_input(short_string(strip_tags(safe_output($row["data"])),275))."</p>";
		$content .=				"</td>";
	}
	$content .=				"</tr>";
	$content .=			"</tbody>";
	$content .=		"</table>";
	$content .= "</div>";

	$content .= "<div id='search_pagination'>";
	$content .= 	ui_pagination ($total_rowcount, "index.php?sec=kb&sec2=operation/kb/browse&id_language=$id_language&free_text=$free_text&product=$product&category=$category", $search_offset, 0, true, true, '&nbsp;&nbsp;&nbsp;&nbsp;', false, true);
	$content .= "</div>";
} else {
	$content = "<h2 style='padding-top:20px; padding-left:20px;'>".__('I couldn\'t find anything for your search... Sorry!')."</h2>";
}

if ($search_string != '' or $are_there_categories) {
	echo 	"<div id='search_results' style='".($number_of_buttons == 0 ? 'margin-top: -30px;' : 'margin-top: 50px;')."'>";
	echo 		$content;
	echo 	"</div>";
}

echo "</div>";

$check_browser = check_browser();

if ($check_browser) {	
	$browser_message = '<h4>'.__('Recommended browsers are Firefox and Chrome. You are using another browser.').'</h4>';
	echo "<div class= 'dialog ui-dialog-content' title='".__("Info")."' id='browser_dialog'>$browser_message</div>";
	echo "<script type='text/javascript'>";
	echo "	$(document).ready (function () {";
	echo "		$('#browser_dialog').dialog ({
					resizable: true,
					draggable: true,
					modal: true,
					overlay: {
						opacity: 0.5,
						background: 'black'
					},
					width: 400,
					height: 150
				});";
	echo "		$('#browser_dialog').dialog('open');";
	echo "	});";
	echo "</script>";
}
?>

<script>
	//Animate content
	$(document).ready(function (){
		$(".landing_content").hide();
		$(".landing_content").slideDown('slow');
	});
</script>
