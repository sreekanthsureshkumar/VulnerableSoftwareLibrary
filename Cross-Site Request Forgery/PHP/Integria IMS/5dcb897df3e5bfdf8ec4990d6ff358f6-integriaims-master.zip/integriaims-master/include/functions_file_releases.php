<?php 

// Integria IMS - http://integriaims.com
// ==================================================
// Copyright (c) 2007-2011 Artica Soluciones Tecnologicas
// Copyright (c) 2008 Esteban Sanchez, estebans@artica.es

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// (LGPL) as published by the Free Software Foundation; version 2

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

function get_download_files () {
	$base_dir = 'attachment/downloads';
	$files = list_files ($base_dir, "", 0, false);
	
	$retval = array ();
	foreach ($files as $file) {
		$retval[$file] = $file;
	}
	
	return $retval;
}

function delete_type_file ($id_download = false, $id_type = false) {
	
	if ($id_download && $id_type) {
		$result = process_sql_delete("tdownload_type_file", array('id_download' => $id_download, 'id_type' => $id_type));
	} elseif ($id_download) {
		$result = process_sql_delete("tdownload_type_file", array('id_download' => $id_download));
	} elseif ($id_type) {
		$result = process_sql_delete("tdownload_type_file", array('id_type' => $id_type));
	} else {
		$result = false;
	}

	return $result;
}

function insert_type_file ($id_download, $id_type) {
	
	delete_type_file ($id_download);

	$sql_insert = "INSERT INTO tdownload_type_file (id_download, id_type) VALUES ($id_download, $id_type)";
	$result = process_sql($sql_insert);

	return $result;
}

function get_file_types ($only_name = false, $all = false) {

	$types = process_sql("SELECT * FROM tdownload_type ORDER BY name DESC");

	if (!$all) {
		$condition = get_filter_by_fr_category_accessibility();

		$types_aux = array();

		foreach ($types as $type) {
			$result = process_sql("SELECT COUNT(tdownload.id) AS num_files
									FROM tdownload, tdownload_type_file
									WHERE tdownload.id = tdownload_type_file.id_download
										AND tdownload_type_file.id_type = ".$type['id']."
										$condition");
			
			if ($result) {
				$num_files = $result[0]['num_files'];
			} else {
				$num_files = 0;
			}

			if ($num_files > 0) {
				$types_aux[] = $type;
			}
		}
		$types = $types_aux;
		$types_aux = null;
	}

	if ($only_name) {
		$types_name = array();

		$types_name[-1] = __('Without type');
		foreach ($types as $type) {
			$types_name[$type["id"]] = $type["name"];
		}

		$types = $types_name;
		$types_name = null;
	}

	return $types;
}

function get_download_type_icon ($id_type) {
	$type = get_db_row("tdownload_type", "id", $id_type);

	if ($type) {
		$image = print_image("images/download_type/".$type["icon"], true, array('title' => safe_output($type["name"]), 'alt' => ''));
	} else {
		$image = print_image("images/download_type/default.png", true, array('title' => __('Without type'), 'alt' => ''));
	}
	
	return $image;
}

function get_file_releases ($id_category = 0, $id_type = 0, $limit = 0, $only_name = false) {
	
	$filter = "";
	if ($id_category > 0) {
		$filter .= " AND id_category = $id_category ";
	}
	if ($id_type > 0) {
		$filter .= " AND id IN (SELECT id_download FROM tdownload_type_file WHERE id_type = $id_type) ";
	} if ($id_type == -1) {
		$filter .= " AND id NOT IN (SELECT id_download FROM tdownload_type_file) ";
	}

	if ($limit < 1) {
		$limit = "";
	} else {
		$limit = "LIMIT $limit";
	}

	$file_releases = process_sql("SELECT * FROM tdownload WHERE 1=1 $filter ORDER BY date DESC $limit");

	if ($only_name) {
		$file_releases_name = array();

		foreach ($file_releases as $file_release) {
			$file_releases_name[$file_release["id"]] = $file_release["name"];
		}

		$file_releases = $file_releases_name;
		$file_releases_name = null;
	}

	return $file_releases;
}

function print_file_types_table ($return = false) {

	$types = parent_files_release();

	if (!$types) {
		$types = array();
	}

	$without_type = process_sql(
		"SELECT	COUNT(id) AS num_files,
				MAX(date) AS last_update
		FROM tdownload
		WHERE id NOT IN (
				SELECT id_download FROM tdownload_type_file
			)
			$condition
		ORDER BY last_update DESC"
	);

	$return = "<div class = 'general_content'>";

	foreach ($types as $key => $value) {
		$return .= print_div_tree_types($value);
	}

	if ($without_type) {
		$return .= "<div class = 'element_content'>";
			$return .= "<a href='index.php?sec=download&sec2=operation/download/browse&id_type=-1'>";
				$return .= "<div class= 'element_content_img'>";
					$return .= print_image("images/download_type/default.png", true);
				$return .= "</div>";
				$return .= "<div class= 'element_content_p'>";
					$return .= "<p>" . __('Without type') . " (" . $without_type[0]["num_files"] . ") </p>";
					$return .= "<p>" . $without_type[0]["last_update"] . "</p>";
				$return .= "</div>";
			$return .= "</a>";
		$return .= "</div>";
	}

	$return .= "</div>";

	echo $return;
}

function print_div_tree_types($value){
	if(is_array($value)){
		$return .= "<div class = 'element_content'>";
			$return .= "<a href='index.php?sec=download&sec2=operation/download/browse&id_type=".$value["id"]."'>";
				$return .= "<div class= 'element_content_img'>";
					$return .= print_image("images/download_type/".$value["icon"], true);
				$return .= "</div>";
				$return .= "<div class= 'element_content_p'>";
					$return .= "<p>" . $value["name"] . " (" . $value["num_files"] . ") </p>";
					$return .= "<p>" . $value["description"] . "</p>";
					$return .= "<p>" . $value["last_update"] . "</p>";
				$return .= "</div>";
			$return .= "</a>";
		$return .= "</div>";
	}
	return $return;
}

function parent_file_release($id_distinct = false){
	$sql_query = "SELECT `id`, `name` FROM tdownload_type";
	$result_query = get_db_all_rows_sql($sql_query);
	if($result_query && is_array($result_query)){
		foreach ($result_query as $key => $value) {
			if($id_distinct){
				if($value['id'] != $id_distinct){
					$result[$value['id']] = $value['name'];
				}
			}
			else{
				$result[$value['id']] = $value['name'];
			}
		}
	}
	else{
		$result = false;
	}
	return $result;
}

function get_download_type_name($id){
	if($id){
		$sql_query = "SELECT `name` FROM tdownload_type WHERE id = " . $id;
		$result= get_db_row_sql($sql_query);
	}
	else{
		return false;
	}
	return $result['name'];
}

function parent_files_release($id=false){
	$condition = get_filter_by_fr_category_accessibility();

	if($id){
		$id = " AND tdownload_type.id_parent = " . $id;
	}
	else{
		$id = " AND tdownload_type.id_parent = 0 ";
	}

	$sql = "SELECT tdownload_type.id AS id,
				tdownload_type.name AS name,
				tdownload_type.description AS description,
				tdownload_type.icon AS icon,
				tdownload_type.id_parent AS id_parent,
				COUNT(tdownload.id) AS num_files,
				MAX(tdownload.date) AS last_update
			FROM tdownload_type_file
				INNER JOIN tdownload
					ON tdownload.id = tdownload_type_file.id_download
				RIGHT JOIN tdownload_type
					ON tdownload_type.id = tdownload_type_file.id_type
			WHERE 1=1
			$id
			$condition
			GROUP BY name
			ORDER BY last_update DESC";

	$all_types = get_db_all_rows_sql($sql);

	return $all_types;
}

?>
