<?php
// Integria IMS - http://integriaims.com
// ==================================================
// Copyright (c) 2008-2011 Artica Soluciones Tecnologicas

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

require_once ("config.php");

global $config;

$config["id_user"] = $_SESSION["id_usuario"];

require_once('functions.php');
require_once('functions_crm.php');
require_once('functions_reports.php');
include_once ("functions_tasks.php");
include_once ("functions_graph.php");

//connect to database
$conexion  = $config["mysql_connect"];
$select_db = $config["mysql_select_db"];

$export_csv_leads = get_parameter('export_csv_leads', 0);
$export_csv_companies = get_parameter('export_csv_companies', 0);
$export_csv_contacts = get_parameter('export_csv_contacts', 0);
$export_csv_contracts = get_parameter('export_csv_contracts', 0);
$export_csv_invoices = get_parameter('export_csv_invoices', 0);
$export_csv_inventory = get_parameter('export_csv_inventory', 0);
$export_csv_audit = get_parameter('export_csv_audit', 0);
$export_csv_tickets = get_parameter('export_csv_tickets', 0);
$export_csv_project_report = get_parameter('export_csv_project_report', 0);
$id_project = get_parameter('id_project', 0);
$export_csv_support_report = get_parameter('export_csv_support_report', 0);
$id_search = get_parameter('id_search', 0);
$export_csv_people_report = get_parameter('export_csv_people_report', 0);
$only_projects = get_parameter('only_projects', 0);
$user_search = get_parameter('user_search', 0);
$start_date = get_parameter('start_date', 0);
$end_date = get_parameter('end_date', 0);
$export_csv_report_resolution = get_parameter('export_csv_report_resolution', 0);
$export_csv_report_general = get_parameter('export_csv_report_general', 0);

if ($export_csv_invoices) {
	
	$read = check_crm_acl ('company', 'cr');
	if (!$read) {
		exit;
	}

	$where_clause = get_parameter('where_clause');
	
	$rows = crm_get_all_invoices (clean_output($where_clause));
	if ($rows === false)
		return;
	
	$rows_aux = array();	
	foreach ($rows as $key=>$invoice) {
		$company_name = get_db_value('name', 'tcompany', 'id', $invoice['id_company']);
		$rows_aux[$key]['id'] = $invoice['id'];
		$rows_aux[$key]['id_user'] = $invoice['id_user'];
		$rows_aux[$key]['id_task'] = $invoice['id_task'];
		$rows_aux[$key]['id_company'] = $invoice['id_company'];
		$rows_aux[$key]['company'] = $company_name;
		$rows_aux[$key]['bill_id'] = $invoice['bill_id'];
		$rows_aux[$key]['concept1'] = $invoice['concept1'];
		$rows_aux[$key]['concept2'] = $invoice['concept2'];
		$rows_aux[$key]['concept3'] = $invoice['concept3'];
		$rows_aux[$key]['concept4'] = $invoice['concept4'];
		$rows_aux[$key]['concept5'] = $invoice['concept5'];
		$rows_aux[$key]['amount1'] = $invoice['amount1'];
		$rows_aux[$key]['amount2'] = $invoice['amount2'];
		$rows_aux[$key]['amount3'] = $invoice['amount3'];
		$rows_aux[$key]['amount4'] = $invoice['amount4'];
		$rows_aux[$key]['amount5'] = $invoice['amount5'];
		$rows_aux[$key]['total_amount'] = $invoice['amount1']+$invoice['amount2']+$invoice['amount3']+$invoice['amount4']+$invoice['amount5'];
		if (substr($invoice["tax"], -$long_tax, 1) == '{'){
			$rows_aux2 = json_decode($invoice['tax']);
			foreach ($rows_aux2 as $key2=>$invoice2) {
				$rows_aux[$key][$key2] = $invoice2;	
			}
		} else {
			$rows_aux[$key]['tax'] = $invoice["tax"];
		}
		if (substr($invoice["tax_name"], -$long_tax, 1) == '{'){
			$rows_aux3 = json_decode($invoice['tax_name']);
			foreach ($rows_aux3 as $key3=>$invoice3) {
				$rows_aux[$key][$key3] = $invoice3;	
			}
		} else {
			$rows_aux[$key]['tax_name'] = $invoice["tax_name"];
		}
		$rows_aux[$key]['retention'] = $invoice['irpf'];
		$rows_aux[$key]['concept_retention'] = $invoice['concept_irpf'];
		$rows_aux[$key]['currency'] = $invoice['currency'];
		$rows_aux[$key]['description'] = $invoice['description'];
		$rows_aux[$key]['id_attachment'] = $invoice['id_attachment'];
		$rows_aux[$key]['locked'] = $invoice['locked'];
		$rows_aux[$key]['locked_id_user'] = $invoice['locked_id_user'];
		$rows_aux[$key]['invoice_create_date'] = $invoice['invoice_create_date'];
		$rows_aux[$key]['invoice_payment_date'] = $invoice['invoice_payment_date'];
		$rows_aux[$key]['invoice_expiration_date'] = $invoice['invoice_expiration_date'];
		$rows_aux[$key]['status'] = $invoice['status'];
		$rows_aux[$key]['invoice_type'] = $invoice['invoice_type'];
		$rows_aux[$key]['reference'] = $invoice['reference'];
		$rows_aux[$key]['id_language'] = $invoice['id_language'];
		$rows_aux[$key]['internal_note'] = $invoice['internal_note'];
	}
	$rows = $rows_aux;
	
	$filename = clean_output ('invoices_export').'-'.date ("YmdHi");
}

if ($export_csv_contracts) {
	
	$read = check_crm_acl ('company', 'cr');
	if (!$read) {
		exit;
	}

	$where_clause = get_parameter('where_clause');
	$where_clause = safe_output($where_clause);

	$pattern = "/LIKE '%.*%'/";

	preg_match($pattern, $where_clause, $matches);

	$search_aux1 = explode("LIKE '%", $matches[0]);
	$search_aux2 = explode("%'", $search_aux1[1]);
	$search = $search_aux2[0];

	$where_clause = str_replace($search, safe_input($search), $where_clause);

	$rows = crm_get_all_contracts_with_custom_fields ($where_clause, true);
	if ($read && $enterprise) {
		$rows = crm_get_user_contracts($config['id_user'], $rows);
	}
	
	$filename = clean_output ('contracts_export').'-'.date ("YmdHi");
	
	if ($rows === false)
		return;
}

if ($export_csv_contacts) {
	$read = check_crm_acl ('company', 'cr');
	if (!$read) {
		exit;
	}
	
	$where_clause = get_parameter('where_clause');
	$where_clause = safe_output($where_clause);

	$pattern = "/LIKE '%.*%'/";

	preg_match($pattern, $where_clause, $matches);

	$search_aux1 = explode("LIKE '%", $matches[0]);
	$search_aux2 = explode("%'", $search_aux1[1]);
	$search = $search_aux2[0];

	$where_clause = str_replace($search, safe_input($search), $where_clause);

	$rows = crm_get_all_contacts (clean_output($where_clause));
	
	$filename = clean_output ('contacts_export').'-'.date ("YmdHi");
	
	if ($rows === false)
		return;
}

if ($export_csv_companies) {
	$read = check_crm_acl ('company', 'cr');
	if (!$read) {
		exit;
	}
	
	$where_clause = get_parameter('where_clause');
	$where_clause = safe_output($where_clause);

	$pattern = "/LIKE '%.*%'/";

	preg_match($pattern, $where_clause, $matches);

	$search_aux1 = explode("LIKE '%", $matches[0]);
	$search_aux2 = explode("%'", $search_aux1[1]);
	$search = $search_aux2[0];

	$where_clause = str_replace($search, safe_input($search), $where_clause);

	$date = get_parameter('date');	
	
	$filename = clean_output ('company_export').'-'.date ("YmdHi");

	$rows = crm_get_companies_list(clean_output($where_clause), $date);
	
	if ($rows === false)
		return;
}

if ($export_csv_leads) {
	$read = check_crm_acl ('company', 'cr');
	if (!$read) {
		exit;
	}

	$where_clause = get_parameter('where_clause');
	$where_clause = safe_output($where_clause);

	$pattern = "/LIKE '%.*%'/";

	preg_match($pattern, $where_clause, $matches);

	$search_aux1 = explode("LIKE '%", $matches[0]);
	$search_aux2 = explode("%'", $search_aux1[1]);
	$search = $search_aux2[0];

	$where_clause = str_replace($search, safe_input($search), $where_clause);

	$filename = clean_output ('lead_export').'-'.date ("YmdHi");

	$rows = crm_get_all_leads (clean_output($where_clause));
	
	if ($rows === false)
		return;
}

if ($export_csv_inventory) {
	$filter = unserialize_in_temp($config["id_user"]);
	$inventories_aux = get_db_all_rows_sql($filter["query"]);
	
	//associated companies
	if(isset($filter["query_company"])){
		$inventories_companies = get_db_all_rows_sql(safe_output($filter["query_company"]));
		if(is_array($inventories_companies) || is_object($inventories_companies)){
			foreach ($inventories_companies as $key_comp => $value_comp) {
				if(!$config['csv_compatibility_import']) {
					$companies_inventory[$value_comp['id_inventory']][] = $value_comp['name'];
				}
				else{
					$companies_inventory[$value_comp['id_inventory']][] = $value_comp['id_company'];
				}
			}
		}
	}

	//associated user
	if(isset($filter["query_associated_user"])){
		$inventories_associated_user = get_db_all_rows_sql(safe_output($filter["query_associated_user"]));
		if(is_array($inventories_associated_user) || is_object($inventories_associated_user)){
			foreach ($inventories_associated_user as $key_user => $value_user) {
				if(!$config['csv_compatibility_import']) {			
					$associated_user_inventory[$value_user['id_inventory']][] = $value_user['nombre_real'];
				}
				else{
					$associated_user_inventory[$value_user['id_inventory']][] = $value_user['id_user'];
				}
			}
		}
	}

	if(!$config['csv_compatibility_import']){
		if(isset($filter["headers"])){
			$headers = json_decode($filter["headers"]);	
		}

		$i=0;
		foreach ($inventories_aux as $k => $v) {
			if(isset($inventories_aux[$i])){
				
				if(isset($v['name'])){
					$inventories_aux[$i][__('Name')] = $v['name'];
					unset($inventories_aux[$i]['name']);
				}

				if(isset($v['owner'])){
					if($v['owner'] != ''){
						$inventories_aux[$i][__('Owner')] = 
							get_db_value('nombre_real', 'tusuario', 'id_usuario', $v['owner']); 
					}
					else{
						$inventories_aux[$i][__('Owner')] = "--";
					}
					unset($inventories_aux[$i]['owner']);
				}

				if(isset($v['id_parent'])){
					if($v['id_parent'] != 0){
						$inventories_aux[$i][__('Parent object')] = 
							get_db_value('name', 'tinventory', 'id', $v['id_parent']);
					}
					else{
						$inventories_aux[$i][__('Parent object')] = "--";
					}
					unset($inventories_aux[$i]['id_parent']);
				}

				if(isset($v['id_object_type'])){
					if($v['id_object_type'] != 0){
						$inventories_aux[$i][__('Object type')] = 
							get_db_value('name', 'tobject_type', 'id', $v['id_object_type']);
					}
					else{
						$inventories_aux[$i][__('Object type')] = "--";
					}
					unset($inventories_aux[$i]['id_object_type']);
				}

				if(isset($v['id_manufacturer'])){
					if($v['id_manufacturer'] != 0){
						$inventories_aux[$i][__('Manufacturer')] =
							get_db_value('name', 'tmanufacturer', 'id', $v['id_manufacturer']);
					}
					else{
						$inventories_aux[$i][__('Manufacturer')] = "--";
					}
					unset($inventories_aux[$i]['id_manufacturer']);
				}

				if(isset($v['id_contract'])){
					if($v['id_contract'] != 0){
						$inventories_aux[$i][__('Contract')] = 
							get_db_value('name', 'tcontract', 'id', $v['id_contract']);
					}
					else{
						$inventories_aux[$i][__('Contract')] = "--";
					}
					unset($inventories_aux[$i]['id_contract']);
				}

				if(isset($v['status'])){
					if($v['status'] != "") {
						$inventories_aux[$i][__('Status')] = __($v['status']);
					}
					unset($inventories_aux[$i]['status']);
				}

				if(isset($v['receipt_date'])){
					$inventories_aux[$i][__('Receipt date')] = $v['receipt_date'];
					unset($inventories_aux[$i]['receipt_date']);
				}

				if(isset($v['issue_date'])){
					$inventories_aux[$i][__('Issue date')] = $v['issue_date'];
					unset($inventories_aux[$i]['issue_date']);
				}

				if(isset($v['description'])){
					$inventories_aux[$i][__('Description')] = $v['description'];
					unset($inventories_aux[$i]['description']);
				}

				if(is_array($companies_inventory) || is_object($companies_inventory)){
					if($companies_inventory[$v['id_not']]){
						$inventories_aux[$i][__('Companies')] = json_encode($companies_inventory[$v['id_not']]);
						unset($companies_inventory[$v['id_not']]);
					}
					else{
						$inventories_aux[$i][__('Companies')] = '';
					}
				}

				if(is_array($associated_user_inventory) || is_object($associated_user_inventory)){
					if($associated_user_inventory[$v['id_not']]){
						$inventories_aux[$i][__('Associated user')] = json_encode($associated_user_inventory[$v['id_not']]);
						unset($associated_user_inventory[$v['id_not']]);
					}
					else{
						$inventories_aux[$i][__('Associated user')] = '';
					}
				}
			}

			$j = 0;
			
			while ($v['id_not'] == $inventories_aux[$i + $j]['id_not']){
				$inventories_aux[$i][safe_output($inventories_aux[$i + $j]['label'])] = safe_output($inventories_aux[$i + $j]['data']);
				unset($inventories_aux[$i]['label'], $inventories_aux[$i]['data']);
				if($j != 0){
					unset($inventories_aux[$i + $j]);
				}
				$j++;
			}

			if(isset($v['id_not'])){
				unset($inventories_aux[$i]['id_not']);
			}

			$i++;
		}
	}
	else{
		$i=0;
		foreach ($inventories_aux as $k => $v) {
			if(is_array($companies_inventory) || is_object($companies_inventory)){
				if($companies_inventory[$v['id_not']]){
					$inventories_aux[$i]['id_company'] = json_encode($companies_inventory[$v['id_not']]);
					unset($companies_inventory[$v['id_not']]);
				}
				else{
					if($inventories_aux[$i]){
						$inventories_aux[$i]['id_company'] = '';
					}
				}
			}
			else{
				if($inventories_aux[$i]){
					$inventories_aux[$i]['id_company'] = '';
				}
			}

			if(is_array($associated_user_inventory) || is_object($associated_user_inventory)){
				if($associated_user_inventory[$v['id_not']]){
					$inventories_aux[$i]['associated_user'] = json_encode($associated_user_inventory[$v['id_not']]);
					unset($associated_user_inventory[$v['id_not']]);
				}
				else{
					if($inventories_aux[$i]){
						$inventories_aux[$i]['associated_user'] = '';
					}
				}
			}
			else{
				if($inventories_aux[$i]){
					$inventories_aux[$i]['associated_user'] = '';
				}
			}
		
			$j = 0;
			while ($v['id_not'] == $inventories_aux[$i + $j]['id_not']){
				$inventories_aux[$i][safe_output($inventories_aux[$i + $j]['label'])] = safe_output($inventories_aux[$i + $j]['data']);
				unset($inventories_aux[$i]['label'], $inventories_aux[$i]['data']);
				if($j != 0){
					unset($inventories_aux[$i + $j]);
				}
				$j++;
			}

			if(isset($v['id_not'])){
				unset($inventories_aux[$i]['id_not']);
			}

			$i++;
		}
	}

	$filename = clean_output ('inventory_export').'-'.date ("YmdHi");
	$rows = $inventories_aux;
	if ($rows === false)
		return;	
}

if ($export_csv_audit) {
	
	$permission = give_acl ($config["id_user"], 0, "IM");
	if (!$permission) {
		exit;
	}
	
	$where_clause = clean_output (get_parameter('where_clause'));
	$date = get_parameter('date');	
	
	$filename = clean_output ('audit_export').'-'.date ("YmdHi");

	$sql = sprintf ('SELECT * FROM tsesion %s ORDER by utimestamp DESC', $where_clause);

	$rows = get_db_all_rows_sql ($sql);
	
	if ($rows === false)
		return;
}

if ($export_csv_tickets) {
	$filter = unserialize_in_temp($config["id_user"]);
	
	$rows = incidents_search_result ($filter, false, true, false, false, true, false, true);

	if ($rows === false)
		return;	
	
	$filename = clean_output ('tickets_export').'-'.date ("YmdHi");
}

if ($export_csv_project_report) {

	$rows = reports_projects_detail($id_project, false, true);

	if ($rows === false)
		return;

	$filename = clean_output ('project_report_export').'-'.date ("YmdHi");
}

if ($export_csv_support_report) {
	$incident_fields = get_parameter ('incident_fields');
	$show_rating = (bool) get_parameter ('show_rating');
	$custom_search = get_custom_search ($id_search, 'incidents');

	if ($custom_search) {		
		if ($custom_search["form_values"]) {
			
			$filter = unserialize($custom_search["form_values"]);
		}
	}

	$statuses = get_indicent_status ();
	$resolutions = get_incident_resolutions ();

	$incident = filter_incidents ($filter);
	if (!$incident_fields) {
	for ($row=0;$row<count($incident);$row++) {
		$rows[$row]['id'] = $incident[$row]['id_incidencia'];
		$rows[$row]['% SLA'] = format_numeric (get_sla_compliance_single_id ($incident[$row]['id_incidencia']));
		$rows[$row]['ticket'] = $incident[$row]['titulo'];
		$rows[$row]['group'] = get_db_value ("nombre", "tgrupo", "id_grupo", $incident[$row]['id_grupo']);

		if ($config["show_creator_incident"] == 1){	
			$id_creator_company = get_db_value ("id_company", "tusuario", "id_usuario", $incident[$row]["id_creator"]);
			if($id_creator_company != 0) {

				$company_name = (string) get_db_value ('name', 'tcompany', 'id', $id_creator_company);	
				$rows[$row]['company']= "$id_creator_company";
			} else {
				$rows[$row]['company']= "";
			}
		} else {
			$rows[$row]['company']= "";
		}

		$resolution = isset ($resolutions[$incident[$row]['resolution']]) ? $resolutions[$incident[$row]['resolution']] : __('None');
		$rows[$row]['status']=$statuses[$incident[$row]['estado']];
		$rows[$row]['resolution']=$resolution;
		$rows[$row]['priority']=$incident[$row]['prioridad'];
		$rows[$row]['updated']=human_time_comparation ($incident[$row]["actualizacion"]);
		$rows[$row]['started']=human_time_comparation ($incident[$row]["inicio"]);
		$rows[$row]['owner']=$incident[$row]['id_usuario'];

	}
	}
	else {
		unset ($incident_fields['SLA']);
		for ($row=0;$row<count($incident);$row++) {
			foreach ($incident_fields as $inc){
				switch($inc) {
					case 'ID':
						$rows[$row]['ID'] = $incident[$row]['id_incidencia'];
						break;
					case 'sla_average':
						if (give_acl($config["id_user"], $id_grupo, "QA")){
						$rows[$row]['% SLA'] = format_numeric (get_sla_compliance_single_id ($incident['id_incidencia']));
						}
						break;
					case 'Ticket':
						$rows[$row]['Ticket'] = $incident[$row]['titulo'];
						break;
					case 'group_company':
						$rows[$row]['Group'] = get_db_value ("nombre", "tgrupo", "id_grupo", $incident[$row]['id_grupo']);
						if ($config["show_creator_incident"] == 1){	
							$id_creator_company = get_db_value ("id_company", "tusuario", "id_usuario", $incident[$row]["id_creator"]);
							if($id_creator_company != 0) {
					
								$company_name = (string) get_db_value ('name', 'tcompany', 'id', $id_creator_company);	
								$rows[$row]['company']= "$id_creator_company";
							} else {
								$rows[$row]['company']= "";
							}
						} else {
							$rows[$row]['company']= "";
						}
						break;
					case 'status_resolution':
						$resolution = isset ($resolutions[$incident[$row]['resolution']]) ? $resolutions[$incident[$row]['resolution']] : __('None');
						$rows[$row]['status']=$statuses[$incident[$row]['estado']];
						$rows[$row]['resolution']=$resolution;
						break;
					case 'Priority':
						$rows[$row]['priority']=$incident[$row]['prioridad'];
						break;
					case 'updated_started':
						$rows[$row]['updated']=human_time_comparation ($incident[$row]["actualizacion"]);
						$rows[$row]['started']=human_time_comparation ($incident[$row]["inicio"]);
						break;
					case 'Owner':
						$rows[$row]['owner']=$incident[$row]['id_usuario'];
						break;
					case 'Creator':
						$rows[$row]['creator'] = $incident[$row]['id_creator'];
						break;
					case 'Description':
						$rows[$row]['description'] = $incident[$row]['descripcion'];
						break;
					//custom fields
					default:
						$inc_input = safe_input($inc);
						$sql = sprintf('SELECT data FROM tincident_field_data WHERE id_incident = %d 
						AND id_incident_field = (SELECT id FROM tincident_type_field WHERE id_incident_type = %d 
						AND label = "%s")', $incident[$row]['id_incidencia'], $incident[$row]['id_incident_type'], $inc_input);
						$rows_field = get_db_value_sql($sql);
					
						if($rows_field){
							$rows[$row][$inc] = $rows_field;
						} else{
							$rows[$row][$inc] = '--';
						}
						break;
				}
			}
			if (give_acl($config["id_user"], $id_grupo, "QA")){
				if ($show_rating)  {
					$rows[$row]['score'] = '--';
					if ($incident[$row]['score'] != 0){
						$rows[$row]['score'] = $incident[$row]['score'];
					}
				}
			}
		}
	}

	if ($rows === false)
		return;	
	
	$filename = clean_output ('support_report_export').'-'.date ("YmdHi");

}




if ($export_csv_people_report) {

	$incident_selector = "";

	if ($only_projects == 0) {
		$sql = "SELECT ti.id_incidencia, ti.id_task FROM tincidencia ti, ttask tt WHERE ti.id_task = tt.id ";
		if ($id_project != 0)
			$sql .= " AND tt.id_project = '$id_project' ";
		
		if ($id_task != 0)
			$sql .= " AND tt.id = '$id_task' ";

		if ($user_id != "")
			$sql .= " AND ti.id_usuario = '$user_id' ";

		if ($resolution > 0)
			$sql = $sql . " AND ti.resolution = $resolution ";

		if ($author != "")
			$sql .= " AND ti.id_creator = '$author' ";

		if ($editor != "")
			$sql .= " AND ti.editor = '$editor' ";

		if ($status > 0)
			$sql .= " AND ti.estado = $status ";

		if ($id_group > 1)
			$sql .= " AND ti.id_grupo = $id_group ";

		if ($id_group_creator > 1)
			$sql .= " AND ti.id_group_creator = $id_group_creator ";
		
		$search_incidents = get_db_all_rows_sql($sql);

		if ($search_incidents) {
			$lista_incidencias = " 0";
			$lista_tareas = " 0";

			// Get the lists separated
			foreach ($search_incidents as $i){
				
				$lista_incidencias .= ", ". $i['id_incidencia'];
				
				if ($i['id_task']) {
					$lista_tareas .= ", ".$i['id_task'];
				}
			}
		} else {
			// There is no match.
			$lista_incidencias = "-1";
			$lista_tareas = "-1";
		}

		if ($lista_incidencias != " 0") {
			$incident_selector = " AND tincidencia.id_incidencia IN ($lista_incidencias) ";
		}
	}

		//$user_id en URL
		if ($user_id != ""){
			$user_search = " AND tworkunit.id_user = '$user_id' ";
		} else {
			$user_search = "";
		}

		$sql = sprintf ('SELECT tincidencia.id_incidencia as id_incidencia, tincidencia.score as score, tincidencia.resolution, tincidencia.id_incidencia as iid, tincidencia.estado as istatus, substring(tincidencia.titulo, 1, 40) as title, tincidencia.id_grupo as id_group, tincidencia.id_group_creator as id_group_creator, tincidencia.id_creator as creator, tincidencia.id_usuario as owner, tincidencia.inicio as date_start, tincidencia.cierre as date_end, tincidencia.id_task as taskid,  SUM(tworkunit.duration) as `suma`  
			FROM tincidencia, tworkunit_incident, tworkunit
			WHERE tworkunit_incident.id_workunit = tworkunit.id '. $user_search .'
			AND tworkunit_incident.id_incident = tincidencia.id_incidencia  
			AND tworkunit.timestamp >= "%s" 
			AND tworkunit.timestamp <= "%s 23:59:59"'. $incident_selector .'
			GROUP BY title', $start_date, $end_date);

		$incidencias = get_db_all_rows_sql ($sql);

		$incident_totals = 0;
		$incident_user = 0;
		$incident_count = 0;
		$incident_graph = array();


		foreach ($incidencias as $key => $row) {
			$rows[$key]['id']=$row['id_incidencia'];
			$rows[$key]['title']=$row['title'];
			$rows[$key]['id_group'] = dame_grupo($row["id_group"]);
			$rows[$key]['id_group_creator'] = dame_grupo($row["id_group_creator"]);
			$rows[$key]['owner']=$row['owner'];
			$rows[$key]['creator']=$row['creator'];

			$status = get_indicent_status();

			$rows[$key]['status'] = $status[$row["istatus"]];
			$rows[$key]['resolution'] = render_resolution ($row["resolution"]);
			$rows[$key]['date_start'] = substr($row["date_start"],0,11);
			$rows[$key]['date_end'] = substr($row["date_end"],0,11);
			$rows[$key]['user_hours'] = $row["suma"];

			$incident_user  += $incident["suma"];
			$this_incident = get_incident_workunit_hours($incident["id"]);
			$rows[$key]['total_hours'] = $this_incident;

			if (give_acl ($config["id_user"], 0, "IM"))
				if ($row["score"] != 0)
					$rows[$key]['score'] = $row["score"];
				else
					$rows[$key]['score'] = "-";
			else
				$rows[$key]['score'] = "N/A";

			$rows[$key]['sla_compliance'] = format_numeric (get_sla_compliance_single_id ($row["id"])) . " %";

		}
		

	if ($rows === false)
		return;	
	
	$filename = clean_output ('people_report_export').'-'.date ("YmdHi");

}

if ($export_csv_report_resolution) {
	$filter = unserialize_in_temp($config["id_user"]);
	
	$incidents = filter_incidents ($filter);

	if ($incidents === false)
		return;
		
	$i=0;
	$incidents_aux = array ();
	foreach ($incidents as $incident) {
			
		$stats = incidents_get_incident_stats($incident['id_incidencia']);
		
		//ID
		$incidents_aux[$i]['id'] = $incident['id_incidencia'];
		
		//Type
		$incidents_aux[$i]['type'] = $incident['id_incident_type'];
		
		//Company
		$id_company = get_db_value ("id_company", "tusuario", "id_usuario", $incident["id_creator"]);
		$company_name = (string) get_db_value ('name', 'tcompany', 'id', $id_company);
		if ($company_name !== false) {
			$incidents_aux[$i]['company'] = $company_name;
		} else {
			$incidents_aux[$i]['company'] = "--";
		}
		
		//Creator
		$incidents_aux[$i]['creator'] = $incident['id_creator'];
		
		//Editor
		$incidents_aux[$i]['editor'] = $incident['editor'];
		
		//Closed by
		$incidents_aux[$i]['closed_by'] = $incident['closed_by'];
		
		//People involved
		$people_involved = people_involved_incident ($incident['id_incidencia']);
		$count = 0;
		if (!empty($people_involved)) {
			$count = count($people_involved);
		}

		$incidents_aux[$i]['people'] = $count;
		
		// Priority
		$incidents_aux[$i]['priority'] = $incident['prioridad'];
		
		
		//Tiempo hasta cierre
		if ($incident['estado'] != STATUS_CLOSED) {
			//~ $data[7] = human_time_comparation ($incident['inicio']);
			$incidents_aux[$i]['time_to_closed'] = "--";
		} else {
			$start_timestamp = strtotime($incident['inicio']);
			$end_timestamp = strtotime($incident['cierre']);
			$duration = $end_timestamp - $start_timestamp;

			$incidents_aux[$i]['time_to_closed'] = give_human_time ($duration);
		}
		
		//Tiempo en nuevo
		if ((!isset($stats['status_time'][1]) || ($stats['status_time'][1]) == 0)) {
			$incidents_aux[$i]['time_new'] = '--';
		} else {
			$incidents_aux[$i]['time_new'] = give_human_time ($stats['status_time'][1]);
		}
		
		//Tiempo distinto de Asignado/Cerrado
		if (!isset($stats) || (empty($stats))) {
			$incidents_aux[$i]['time_no_assig_closed'] = '--';
		} else {
			$result = $stats['total_time'] - ($stats['status_time'][3] + $stats['status_time'][7]);
			$incidents_aux[$i]['time_no_assig_closed'] = give_human_time ($result);
		}
		
		//Sumatorio tiempo empleado en Comentarios
		$sql_sum = "SELECT SUM(duration) FROM tworkunit_incident t1, tworkunit t2
			WHERE t1.id_incident = t2.id AND t1.id_incident = ".$incident['id_incidencia'];
		$sum = get_db_value_sql ($sql_sum);
		if ($sum === false) {
			$sum = "--";
		}
		$incidents_aux[$i]['sum'] = $sum;
		
		$i++;
	}

	$filename = clean_output ('resolution_export').'-'.date ("YmdHi");
	$rows = $incidents_aux;
	if ($rows === false)
		return;	
}


if ($export_csv_report_general) {
	$filter = unserialize_in_temp($config["id_user"]);
	
	$user_id = $filter['id_user'];
	$created_from = $filter['created_from'];
	$created_to = $filter['created_to'];
	
	$sql_wus = "SELECT * FROM tworkunit WHERE 1=1";
	if ($user_id != "") {
		$sql_wus .= " AND tworkunit.id_user = '".$user_id."'";
	}
	if ($created_from != "") {
		$sql_wus .=  " AND timestamp >= '".$created_from."'";
	}
	if ($created_to != "") {
		$sql_wus .=  " AND timestamp <= '".$created_to."'";
	}
	$sql_wus .= " ORDER BY timestamp DESC";
	
	$sql_wus = safe_output ($sql_wus);
	$wus = get_db_all_rows_sql ($sql_wus);
	if ($wus === false)
		return;
		
	$i=0;
	$wus_aux = array ();
	
	foreach ($wus as $wu) {

		$wus_aux[$i]['id_user'] = $wu['id_user'];
			
		//Fecha
		$wus_aux[$i]['timestamp'] = $wu['timestamp'];
		
		//Duración
		$wus_aux[$i]['duration'] = $wu['duration'];
		
		//Tipo
		$ticket_id = get_db_value_filter('id_incident', 'tworkunit_incident', array('id_workunit'=>$wu['id']));
		$ticket = false;
		$task = false;
		
		if ($ticket_id !== false) {
			$wus_aux[$i]['type'] = __('Ticket');
			$ticket = true;
		} else {
			$wus_aux[$i]['type'] = __('Task');
			$task = true;
		}
		
		//Proyecto
		$wus_aux[$i]['project_name'] = '';
		$wus_aux[$i]['group_name'] = '';
		$wus_aux[$i]['title'] = '';
		
		if ($ticket) {
			$task_id = get_db_value ("id_task", "tincidencia", "id_incidencia", $ticket_id);
			$group_id = get_db_value ("id_grupo", "tincidencia", "id_incidencia", $ticket_id);
			$title = get_db_value ("titulo", "tincidencia", "id_incidencia", $ticket_id);
			$priority = get_db_value ("prioridad", "tincidencia", "id_incidencia", $ticket_id);
			if ($title == "") {
				$title = "--";
			}
			if ($task_id !== false) {
				$project_id = get_db_value ("id_project", "ttask", "id", $task_id);
				if ($project_id !== false) {
					$project_name = get_db_value ("name", "tproject", "id", $project_id);
					$wus_aux[$i]['project_name'] = $project_name; //Proyecto
					$wus_aux[$i]['group_name']= groups_get_group_name ($group_id); //Grupo incidencia
					$wus_aux[$i]['title'] = $title; //Título incidencia
				}
			}
		} else {
			if ($task) {
				$task_id = get_db_value_filter('id_task', 'tworkunit_task', array('id_workunit'=>$wu['id']));
				if ($task_id !== false) {
					$project_id = get_db_value ("id_project", "ttask", "id", $task_id);
					if ($project_id !== false) {
						$project_name = get_db_value ("name", "tproject", "id", $project_id);
						$wus_aux[$i]['project_name'] = $project_name; //Proyecto
						$wus_aux[$i]['group_name'] = ''; //Grupo incidencia
						$wus_aux[$i]['title'] = ''; //Título incidencia
					}
				}
			}
		}
		
		// Descripción
		if ($wu['description'] != "") {
			$desc = $wu['description'];
		} else {
			$desc = '--';
		}
		$wus_aux[$i]['desc'] = $desc;
		
		//Creador
		$wus_aux[$i]['creator'] = $wu['id_user'];
		
		//Prioridad
		$wus_aux[$i]['priority'] = '';
		if ($ticket) {
			$priority = get_db_value ("prioridad", "tincidencia", "id_incidencia", $ticket_id);
			$wus_aux[$i]['priority'] = $priority;
		}
		
		//Company
		$id_company = get_db_value ("id_company", "tusuario", "id_usuario", $wu["id_user"]);
		$company_name = (string) get_db_value ('name', 'tcompany', 'id', $id_company);
		if ($company_name !== false) {
			$wus_aux[$i]['company_name'] = $company_name;
		} else {
			$wus_aux[$i]['company_name'] = "--";
		}
		
		$i++;
	}
	
	$filename = clean_output ('general_export').'-'.date ("YmdHi");
	$rows = $wus_aux;
	if ($rows === false)
		return;
}

if (empty($rows))
	die(__('Empty data'));

$csv_lines = array();

$search = array();
// Delete \r !!!
//$search[] = "&#x0d;";
$search[] = "\r";
// Delete \n !!!
//$search[] = "&#x0a;";
$search[] = "\n";
// Delete " !!!
$search[] = '"';
// Delete ' !!!
//$search[] = "'";
// Delete , !!!
//$search[] = ",";
// Delete , !!!
$search[] = ";";

// Item / data
// select array more long
$count_rows = count($rows);
$max_rows = 0;
for ($i=0; $i < $count_rows; $i++){
	if (count($rows[$i]) > $max_rows){
		$max_rows = $rows[$i];	
	}	
}

//selects all fields of different arrays
foreach ($rows as $row) {
	$diff = array_diff_key($row, $max_rows);
	if($diff){
		foreach ($diff as $key => $values){
			$max_rows[$key] = " ";
		}
	}
}
$max_rows_prepare = $max_rows;
foreach ($rows as $row) {
	//head
	$csv_head = implode($config["csv_separator"], array_keys($max_rows_prepare));
	//inicialice $line
	$line = array();
	//loop that compares whether a field
	foreach ($max_rows_prepare as $k=>$v){
		if(array_key_exists($k, $row)){
			$cell = str_replace ($search, " ", safe_output($row[$k]));
		} else {
			$cell = "";
		}
		// Change ; !!
		$cell = str_replace (",", ".", $cell);
		$line[] = $cell;
	}
	$line = implode($config["csv_separator"],  $line);
	$csv_lines[] = $line;
}

ob_end_clean();

// CSV Output
header ('Content-Encoding: UTF-8');
header ('Content-Type: text/csv; charset=UTF-8');
header ('Content-Disposition: attachment; filename="'.$filename.'.csv"');
$os_csv = substr(PHP_OS, 0 , 1);
echo "\xEF\xBB\xBF";

// Header
echo $csv_head . "\n";
$standard_encoding = (bool) $config['csv_standard_encoding'];

// Item / data
foreach ($csv_lines as $line) {
	if (!$standard_encoding){
		if($os_csv != "W"){
			echo $line . "\n";//echo mb_convert_encoding($line, 'UTF-16LE', 'UTF-8'). "\n";
		} else {
			echo $line . "\n";
		}
	}else{
		//~ echo mb_convert_encoding($line, '', "UTF-8") . "\n";
		echo $line . "\n";
	}
}
exit;	
?>
