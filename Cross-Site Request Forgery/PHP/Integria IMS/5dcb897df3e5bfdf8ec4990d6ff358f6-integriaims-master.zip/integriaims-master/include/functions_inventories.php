<?php 

// INTEGRIA IMS v2.0
// http://www.integriaims.com
// ===========================================================
// Copyright (c) 2007-2008 Sancho Lerena, slerena@gmail.com
// Copyright (c) 2008 Esteban Sanchez, estebans@artica.es
// Copyright (c) 2007-2008 Artica, info@artica.es

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// (LGPL) as published by the Free Software Foundation; version 2

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

$enteprise_load = enterprise_include("include/functions_inventory.php");

function get_inventories ($only_names = true, $exclude_id = false) {
	if ($exclude_id) {
		$sql = sprintf ('SELECT * FROM tinventory WHERE id != %d', $exclude_id);
		$inventories = get_db_all_rows_sql ($sql);
	} else {
		$inventories = get_db_all_rows_in_table ('tinventory');
	}
	if ($inventories == false)
		return array ();
	
	if ($only_names) {
		$retval = array ();
		foreach ($inventories as $inventory) {
			$retval[$inventory['id']] = $inventory['name'];
		}
		return $retval;
	}
	
	return $inventories;
}

function get_inventory ($id_inventory) {
	return get_db_row ('tinventory', 'id', $id_inventory);
}

function get_inventory_name ($id) {
	return (string) get_db_value ('name', 'tinventory', 'id', $id);
}

function get_inventories_in_incident ($id_incident, $only_names = true) {
	$sql = sprintf ('SELECT tinventory.* FROM tincidencia, tincident_inventory, tinventory
			WHERE tincidencia.id_incidencia = tincident_inventory.id_incident
			AND tinventory.id = tincident_inventory.id_inventory
			AND tincidencia.id_incidencia = %d', $id_incident);
	$all_inventories = get_db_all_rows_sql ($sql);
	if ($all_inventories == false)
		return array ();
	
	global $config;
	$inventories = array ();
	foreach ($all_inventories as $inventory) {
		if (! give_acl ($config['id_user'], get_inventory_group ($inventory['id']), 'VR')) {
			$inventory['name'] = $inventory['name'];
		}
		array_push ($inventories, $inventory);
	}
	
	if ($only_names) {
		$result = array ();
		foreach ($inventories as $inventory) {
			$result[$inventory['id']] = $inventory['name'];
		}
		return $result;
	}
	return $inventories;
}

function get_inventories_in_company ($id_company, $only_names = true) {
	$sql = sprintf ('SELECT tinventory.* FROM tcontract, tinventory
			WHERE tinventory.id_contract = tcontract.id
			AND tcontract.id_company = %d', $id_company);
	
	$all_inventories = get_db_all_rows_sql ($sql);
	if ($all_inventories == false)
		return array ();
	
	global $config;
	$inventories = array ();
	foreach ($all_inventories as $inventory) {
		if (! give_acl ($config['id_user'], get_inventory_group ($inventory['id']), 'VR')) {
			$inventory['name'] = $inventory['name'];
		}
		array_push ($inventories, $inventory);
	}
	
	if ($only_names) {
		$result = array ();
		foreach ($inventories as $inventory) {
			$result[$inventory['id']] = $inventory['name'];
		}
		return $result;
	}
	return $inventories;
}

function get_inventory_contracts ($id_inventory, $only_names = true) {
	$sql = sprintf ('SELECT tcontract.* FROM tinventory, tcontract
			WHERE tinventory.id_contract = tcontract.id
			AND tinventory.id = %d', $id_inventory);
	$contracts = get_db_all_rows_sql ($sql);
	if ($contracts == false)
		return array ();
	
	if ($only_names) {
		$result = array ();
		foreach ($contracts as $contract) {
			$result[$contract['id']] = $contract['name'];
		}
		return $result;
	}
	return $contracts;
}

function get_inventory_group ($id_inventory, $only_id = true) {
	$sql = sprintf ('SELECT tgrupo.%s FROM tinventory, tcontract, tgrupo
			WHERE tinventory.id_contract = tcontract.id
			AND tcontract.id_group = tgrupo.id_grupo
			AND tinventory.id = %d',
			($only_id ? "id_grupo" : "*"),
			$id_inventory);
	if ($only_id)
		return (int) get_db_sql ($sql);
	return get_db_row_sql ($sql);
}

function get_inventory_affected_companies ($id_inventory, $only_names = true) {
	$sql = sprintf ('SELECT tcompany.* FROM tinventory, tcontract, tcompany
			WHERE tinventory.id_contract = tcontract.id
			AND tcontract.id_company = tcompany.id
			AND tinventory.id = %d', $id_inventory);
	$companies = get_db_all_rows_sql ($sql);
	if ($companies == false)
		return array ();
	
	if ($only_names) {
		$result = array ();
		foreach ($companies as $company) {
			$result[$company['id']] = $company['name'];
		}
		return $result;
	}
	return $companies;
}

function get_incident ($id_incident) {
	return get_db_row ('tincidencia', 'id_incidencia', $id_incident);
}

function get_company ($id_company) {
	return get_db_row ('tcompany', 'id', $id_company);
}

function get_companies ($only_names = true, $filter = false) {
	global $config;
	
	$companies = get_db_all_rows_filter ('tcompany', $filter);
	
	if ($companies === false)
		return array ();
	
	$names = array ();
	foreach ($companies as $k => $company) {
		$id_group = 0;
		if (isset($company['id_grupo']))
			$id_group = $company['id_grupo'];
		if (!give_acl ($config["id_user"], $id_group, "VR") && !get_admin_user ($config["id_user"])) {
			continue;
		}
		$names[$company['id']] = $company['name'];
	}
	
	asort ($names);
	
	if($only_names) {
		return $names;
	}
	
	$retval = array();
	$company_keys = array_keys($names);
	foreach($companies as $company) {
		if(in_array($company['id'],$company_keys)) {
			$retval[] = $company;
		}
	}
	
	return $retval;
}

function get_company_roles ($only_names = true) {
	$companies = get_db_all_rows_in_table ('tcompany_role');
	if ($companies === false)
		return array ();
	
	if ($only_names) {
		$retval = array ();
		foreach ($companies as $company) {
			$retval[$company['id']] = $company['name'];
		}
		return $retval;
	}
	
	return $companies;
}


function get_contract ($id_contract) {
	return get_db_row ('tcontract', 'id', $id_contract);
}

function get_contracts ($only_names = true, $filter = false) {
	global $config;

	$contracts = get_db_all_rows_filter ('tcontract', $filter);
	if ($contracts === false)
		return array ();

	$names = array ();
	foreach ($contracts as $k => $contract) {
		if (!give_acl ($config["id_user"], $contract['id_group'], "VR") && !get_admin_user ($config["id_user"])) {
			continue;
		}
		$names[$contract['id']] = $contract['name'];
	}

	asort ($names);
	
	if($only_names) {
		return $names;
	}

	$retval = array();
	$contract_keys = array_keys($names);
	foreach($contracts as $contract) {
		if(in_array($contract['id'],$contract_keys)) {
			$retval[] = $contract;
		}
	}

	return $retval;
}

function get_products ($only_names = true) {
	$products = get_db_all_rows_in_table ('tkb_product');
	if ($products === false)
		return array ();
	
	if ($only_names) {
		$retval = array ();
		foreach ($products as $product) {
			$retval[$product['id']] = $product['name'];
		}
		return $retval;
	}
	
	return $products;
}

function get_company_contacts ($id_company, $only_names = true) {
	$sql = sprintf ('SELECT * FROM tcompany_contact
			WHERE id_company = %d', $id_company);
	$contacts = get_db_all_rows_sql ($sql);
	if ($contacts == false)
		return array ();
	
	if ($only_names) {
		$result = array ();
		foreach ($contacts as $contact) {
			$result[$contact['id']] = $contact['name'];
		}
		return $result;
	}
	return $contacts;
}

/**
 * Get all the contacts relative to an inventory object.
 *
 * There are two ways to get the list. By default, all the contacts in the
 * company that has the inventory contract will be returned. Anyway, if the
 * contacts list was changed manually when updating or creating the
 * inventory object, then these are the contacts of the object.
 *
 * @param int Inventory id.
 * @param bool Whether to return only contact names (default) or all the fields.
 *
 * @return array List of contacts relative to an inventory object.
 */
function get_inventory_contacts ($id_inventory, $only_names = false) {
	global $config;

	include_once("include/functions_crm.php");
	
	/* First try to get only defined contacts */
	$owner = get_db_value('owner', 'tinventory', 'id', $id_inventory);
	
	$owner_info = get_db_row ("tusuario", "id_usuario", $owner);

	$all_contacts = array();

	$contact = array("id" => $owner,
			"type" => "user",
			"id_company" => $owner_info["id_company"],
			"fullname" => $owner_info["nombre_real"],
			"email" => $owner_info["direccion"],
			"phone" => $owner_info["telefono"],
			"mobile" => __("N/A"),
			"position" => __("N/A"),
			"description" => $owner_info["comentarios"],
			"disabled" => $owner_info["disabled"]);

	$all_contacts[$contact["id"]] = $contact;  

	//Get all users associated to the inventory object

	$inv_users = inventory_get_users($id_inventory, false);	

	if ($inv_users === ENTERPRISE_NOT_HOOK) {
		$inv_users = array();
	}

	foreach ($inv_users as $user) {
       		$contact = array("id" => $user["id_usuario"],
                        "type" => "user",
                        "id_company" => $user["id_company"],
                        "fullname" => $user["nombre_real"],
                        "email" => $user["direccion"],
                        "phone" => $user["telefono"],
                        "mobile" => __("N/A"),
                        "position" => __("N/A"),
                        "description" => $user["comentarios"],
                        "disabled" => $user["disabled"]);

        	$all_contacts[$contact["id"]] = $contact;
	}

	$inv_companies = inventory_get_companies ($id_inventory, false);
	
	if ($inv_companies === ENTERPRISE_NOT_HOOK) {
		$inv_companies = array();
	}
	
	foreach ($inv_companies as $comp) {
		$where_clause = sprintf("WHERE id_company = %d", $comp["id"]);
		$contacts = crm_get_all_contacts ($where_clause);	
		
		if (!$contacts) {
			$contacts = array();
		}

		foreach ($contacts as $contact) {
                        $all_contacts[$contact['id']] = $contact;
                }				
	}

	$contracts = get_inventory_contracts ($id_inventory, false);
	if ($contracts === false)
		return array ();
		
	foreach ($contracts as $contract) {
		$company = get_company ($contract['id_company']);
		if ($company === false)
			continue;
		if (! give_acl ($config['id_user'], $contract['id_group'], "IR"))
			continue;
		
		$contacts = get_company_contacts ($company['id'], false);
		foreach ($contacts as $contact) {
			if (isset ($all_contacts[$contact['id']]))
				continue;
			
			$all_contacts[$contact['id']] = $contact;
		}
	}
	
	if (! $only_names)
		return $all_contacts;
	
	$retval = array ();
	foreach ($all_contacts as $contact) {
		$retval[$contact['id']] = $contact['fullname'];
	}
	
	return $retval;
}

/**
 * Update contacts in an inventory object.
 *
 * @param int Inventory id to update.
 * @param array List of company contacts ids.
 */
function update_inventory_contacts ($id_inventory, $contacts) {
	error_reporting (0);
	$where_clause = '';
	
	if (empty ($contacts)) {
		$contacts = array (0);
	}
	$where_clause = sprintf ('AND id_company_contact NOT IN (%s)',
		implode (',', $contacts));
	$sql = sprintf ('DELETE FROM tinventory_contact
		WHERE id_inventory = %d %s',
		$id_inventory, $where_clause);
	process_sql ($sql);
	foreach ($contacts as $id_contact) {
		$sql = sprintf ('INSERT INTO tinventory_contact
				VALUES (%d, %d)',
				$id_inventory, $id_contact);
		process_sql ($sql);
	}
}


/**
 * Retrieve the inventory object field value.
 *
 * @param int Inventory id.
 * @param string Field name.
 * 
 * @return mixed The string value or false.
 */
function get_inventory_type_field_value ($id_inventory, $field_name) {
	$sql = sprintf(
		"SELECT tofd.data
		FROM tobject_field_data tofd
			INNER JOIN tobject_type_field totf
				ON tofd.id_object_type_field = totf.id
					AND totf.label LIKE '%s'
		WHERE tofd.id_inventory = %d",
		$field_name, $id_inventory
	);
	return get_db_value_sql($sql);
}

function get_ehorus_id_from_inventory_object ($id_inventory) {
	return get_inventory_type_field_value($id_inventory, 'eHorus&#x20;Id');
}

/**
 * Filter all the inventories and return a list of matching elements.
 *
 * This function only return the inventories that can be accessed for the
 * current user with VR permission.
 *
 * @param array Key-value array of parameters to filter. It can handle this fields:
 *
 * string String to find in inventory title
 * serial_number Inventory serial number.
 * part_number Inventory part number.
 * ip_address Inventory IP address.
 * id_group Inventory group id.
 * id_contract Inventory contract id.
 * id_product Inventory product id.
 * id_building Inventory building id.
 * id_company Inventory company id (relative to the contract).
 *
 * @return array A list of matching inventories. False if no matches.
 */
function filter_inventories ($filters) {
	global $config;
	
	/* Set default values if none is set */
	$filters['string'] = isset ($filters['string']) ? $filters['string'] : '';
	$filters['serial_number'] = isset ($filters['serial_number']) ? $filters['serial_number'] : '';
	$filters['part_number'] = isset ($filters['part_number']) ? $filters['part_number'] : '';
	$filters['ip_address'] = isset ($filters['ip_address']) ? $filters['ip_address'] : '';
	$filters['id_group'] = isset ($filters['id_group']) ? $filters['id_group'] : 0;
	$filters['id_contract'] = isset ($filters['id_contract']) ? $filters['id_contract'] : 0;
	$filters['id_product'] = isset ($filters['id_product']) ? $filters['id_product'] : 0;
	$filters['id_building'] = isset ($filters['id_building']) ? $filters['id_building'] : 0;
	$filters['id_company'] = isset ($filters['id_company']) ? $filters['id_company'] : '';
	
	$sql_clause = '';
	if ($filters['id_contract'])
		$sql_clause .= sprintf (' AND id_contract = %d', $filters['id_contract']);
	if ($filters['id_product'])
		$sql_clause .= sprintf (' AND id_product = %d', $filters['id_product']);
	if ($filters['id_building'])
		$sql_clause .= sprintf (' AND id_building = %d', $filters['id_building']);
	if ($filters['ip_address'] != '')
		$sql_clause .= sprintf (' AND ip_address LIKE "%%%s%%"', $filters['ip_address']);
	if ($filters['serial_number'] != '')
		$sql_clause .= sprintf (' AND serial_number LIKE "%%%s%%"', $filters['serial_number']);
	if ($filters['part_number'] != '')
		$sql_clause .= sprintf (' AND part_number LIKE "%%%s%%"', $filters['part_number']);
	
	$sql = sprintf ('SELECT id, name, description, comments, id_building, id_contract, id_parent
			FROM tinventory
			WHERE (name LIKE "%%%s%%" OR description LIKE "%%%s%%")
			%s LIMIT %d',
			$filters['string'], $filters['string'],
			$sql_clause, $config['block_size']);
	$all_inventories = get_db_all_rows_sql ($sql);
	if ($all_inventories === false)
		return false;
	
	$short_table = (bool) get_parameter ('short_table');
	$total_inventories = 0;
	$inventories = array ();
	foreach ($all_inventories as $inventory) {
		if ($inventory['id_contract']) {
			/* Only check ACLs if the inventory has a contract */
			if (! give_acl ($config['id_user'], get_inventory_group ($inventory['id']), "VR"))
				continue;
		}
		
		if ($filters['id_company']) {
			$companies = get_inventory_affected_companies ($inventory['id'], false);
			$found = false;
			foreach ($companies as $company) {
				if ($company['id'] == $filters['id_company'])
					$found = true;
			}
			if (! $found)
				continue;
		}
		$inventories[$inventory['id']] = $inventory;
	}
	
	if (sizeof ($inventories) == 0)
		return false;
	return $inventories;
}

/**
 * Prints the details of an inventory object and, optionally, its children. 
 *
 * @param int ID of the object.
 * @param array Array containing inventory objects.
 * @param array Inventory object tree.
 * @param bool Show child nodes.
 * @param bool Show incident statistics.
 * @param int Call depth, used for indentation.
 * @param bool Whether to return an output string or echo now (optional, echo by default).
 */
function print_inventory_object ($id, $inventory, $tree, $show_children = false, $show_incidents = false, $depth = 0, $return = false) {
	global $config;
	
	$output = '';
	
	if (! isset ($inventory[$id])) {
		return '';
	}
	
	$object = $inventory[$id];
	
	if ($object['id_contract']) {
		/* Only check ACLs if the inventory has a contract */
		if (! give_acl ($config['id_user'], get_inventory_group ($object['id']), "VR"))
			return '';
	}
	
	$output .= '<tr id="result-'.$object['id'].'">';
	$output .= '<td><strong>#'.$object['id'].'</strong></td>';
	$output .= '<td>';
	if ($depth > 0) {
		$output .= '<span class="indent">';
		for ($i = 0; $i < $depth; $i++) {
			$output .= '&nbsp;&nbsp;&nbsp;&nbsp;';
		}
		$output .= '</span>';
		$output .= '<img src="images/copy.png" />';
	}
	$output .= $object['name'] . '</td>';
	
	if ($show_incidents) {
		$incidents = get_incidents_on_inventory ($object['id'], false);
		$total_incidents = sizeof ($incidents);
		$output .= '<td>';
		if ($total_incidents) {
			$actived = 0;
			foreach ($incidents as $incident) {
				if ($incident['estado'] != 7 && $incident['estado'] != 6)
					$actived++;
			}
			$output .= '<img src="images/info.png" /> <strong>'.$actived.'</strong> / '.$total_incidents;
		}
		$output .= '</td>';
	}
	$companies = get_inventory_affected_companies ($object['id'], false);
	$output .= '<td>';
	if (isset ($companies[0]['name']))
		$output .= $companies[0]['name'];
	$output .= '</td>';
	
	$building = get_building ($object['id_building']);
	$output .= '<td>';
	if ($building)
		$output .= $building['name'];
	$output .= '</td>';
	
	$output .= '<td>'.$object['description'].'</td>';
	$output .= '</tr>';
	
	// Print child objects
	if (! $show_children || ! isset ($tree[$object['id']])) {
		if ($return)
			return $output;
		echo $output;
		return;
	}

	foreach ($tree[$object['id']] as $child) {
		$output .= print_inventory_object ($child, $inventory, $tree,
			$show_children, $show_incidents, $depth + 1, true);
	}
	
	if ($return)
		return $output;
	echo $output;
}

/**
 * Get the children of the given inventory object.
 *
 * @param int ID of the object.
 *
 * @return array A list of inventory objects.
 */
function get_inventory_children ($id) {
	global $config;
	$result = array ();

	$sql = sprintf ('SELECT * FROM tinventory WHERE id_parent = %d', $id);
	$children = get_db_all_rows_sql ($sql);
	if ($children === false) {
		return false;
	}

	foreach ($children as $child) {
		$result[$child['id']] = $child;
	}
	
	return $result;
}

/**
 * Print a table with statistics of a list of inventories.
 *
 * @param array List of inventories to get stats.
 * @param bool Whether to return an output string or echo now (optional, echo by default).
 *
 * @return Inventories stats if return parameter is true. Nothing otherwise
 */
function print_inventory_stats ($inventories, $return = false) {
	$output = '';
	
	$total = sizeof ($inventories);
	$inventory_incidents = 0;
	$inventory_opened = 0; 
	foreach ($inventories as $inventory) {
		$incidents = get_incidents_on_inventory ($inventory['id'], false);
		if (sizeof ($incidents) == 0)
			continue;
		$inventory_incidents++;
		foreach ($incidents as $incident) {
			if ($incident['estado'] != 7 && $incident['estado'] != 6) {
				$inventory_opened++;
				break;
			}
		}
	}
	
	$incidents_pct = 0;
	if ($total != 0) {
		$incidents_pct = format_numeric ($inventory_incidents / $total * 100);
		$incidents_opened_pct = format_numeric ($inventory_opened / $total * 100);
	}
	$table = new stdClass();
	$table->width = '50%';
	$table->class = 'float_left blank';
	$table->style = array ();
	$table->style[1] = 'vertical-align: top';
	$table->rowspan = array ();
	$table->rowspan[0][1] = 3;
	$table->data = array ();
	
	$table->data[0][0] = print_label (__('Total objects'), '', '', true, $total);
	$data = array(__('With tickets') => $inventory_incidents, __('Without tickets')=> $total - $inventory_incidents);
	$table->data[0][1] = pie3d_chart ($config['flash_charts'], $data, 200, 150);
	$table->data[1][0] = print_label (__('Total objects with tickets'), '', '', true,
		$inventory_incidents.' ('.$incidents_pct.'%)');
	$table->data[2][0] = print_label (__('Total objects with opened tickets'),
		'', '', true, $inventory_opened.' ('.$incidents_opened_pct.'%)');
	
	$output .= print_table ($table, true);
	
	if ($return)
		return $output;
	echo $output;
}

function get_inventory_generic_labels () {
	global $config;
	
	$labels = array ();
	
	$labels['generic_1'] = isset ($config['inventory_label_1']) ? $config['inventory_label_1'] : lang_string ('Field #').'1';
	$labels['generic_2'] = isset ($config['inventory_label_2']) ? $config['inventory_label_2'] : lang_string ('Field #').'2';
	$labels['generic_3'] = isset ($config['inventory_label_3']) ? $config['inventory_label_3'] : lang_string ('Field #').'3';
	$labels['generic_4'] = isset ($config['inventory_label_4']) ? $config['inventory_label_4'] : lang_string ('Field #').'4';
	$labels['generic_5'] = isset ($config['inventory_label_5']) ? $config['inventory_label_5'] : lang_string ('Field #').'5';
	$labels['generic_6'] = isset ($config['inventory_label_6']) ? $config['inventory_label_6'] : lang_string ('Field #').'6';
	$labels['generic_7'] = isset ($config['inventory_label_7']) ? $config['inventory_label_7'] : lang_string ('Field #').'7';
	$labels['generic_8'] = isset ($config['inventory_label_8']) ? $config['inventory_label_8'] : lang_string ('Field #').'8';
	
	return $labels;
}

function fill_inventories_table($inventories, &$table) {
	global $config;
	$table->width = "99%";	
	foreach ($inventories as $inventory) {
		$data = array ();
		
		$id_group = get_inventory_group ($inventory['id']);
		$has_permission = true;
		if (! give_acl ($config['id_user'], $id_group, 'VR'))
			$has_permission = false;
		$contract = get_contract ($inventory['id_contract']);
		$company = get_company ($contract['id_company']);
		
		$data[0] = $inventory['name'];
		if ($has_permission) {
			$table->head[1] = __('Company');
			$table->head[2] = __('Contract');
			if ($inventory['description'])
				$data[0] .= ' '.print_help_tip ($inventory['description'], true, 'tip_info');
			$data[1] = $company['name'];
			$data[2] = $contract['name'];
		}
		
		if (give_acl ($config['id_user'], $id_group, "VW")) {
			$table->head[4] = __('Edit');
			$table->align[4] = 'center';
			$data[4] = '<a href="index.php?sec=inventory&sec2=operation/inventories/inventory_detail&check_inventory=1&id='.$inventory['id'].'">'.
					'<img src="images/wrench.png" /></a>';
		}
		
		$table->head[5] = __('More info');
		$data[5] = '<a href="javascript: openInventoryMoreInfo(' . $inventory['id'] . ');" id="show_info-'.$inventory["id"].'">';
		$data[5] .= print_image ("images/information.png", true,
				array ("title" => __('Show object type fields')));
		$data[5] .= '</a>&nbsp;';
	
		array_push ($table->data, $data);

	}
}

/*
 * Returns all inventory type fields.
 */ 
function inventories_get_all_type_field ($id_object_type, $id_inventory=false, $only_selected = false) {
	
	global $config;
	
	$fields = get_db_all_rows_filter('tobject_type_field', array('id_object_type' => $id_object_type));
	
	if ($fields === false) {
		$fields = array();
	}
	
	$all_fields = array();
	foreach ($fields as $id=>$field) {
		if ($only_selected) {
			if($field['show_list']) {
				foreach ($field as $key=>$f) {
					if ($key == 'label') {
						$all_fields[$id]['label_enco'] = base64_encode($f);
					}
					if ($key == 'parent_table_name') {
						if ($f != '') {
							$label_parent = get_db_value_sql("SELECT label FROM tobject_type_field WHERE external_table_name='".$f."'");
							$all_fields[$id]['label_parent_enco'] = base64_encode($label_parent);
							$id_parent_table = get_db_value_sql("SELECT external_reference_field FROM tobject_type_field WHERE external_table_name='".$f."'");
							$all_fields[$id]['id_parent_table'] = $id_parent_table;
						}
					}
					$all_fields[$id][$key] = safe_output($f);
					$all_fields[$key]['data'] = "";
				}
			}	
		} else {
		
			foreach ($field as $key=>$f) {

				if ($key == 'label') {
					$all_fields[$id]['label_enco'] = base64_encode($f);
				}
				if ($key == 'parent_table_name') {
					if ($f != '') {
						$label_parent = get_db_value_sql("SELECT label FROM tobject_type_field WHERE external_table_name='".$f."'");
						$id_parent_table = get_db_value_sql("SELECT external_reference_field FROM tobject_type_field WHERE external_table_name='".$f."'");
						$all_fields[$id]['label_parent_enco'] = base64_encode($label_parent);
						$all_fields[$id]['id_parent_table'] = $id_parent_table;
					} else {
						$all_fields[$id]['label_parent_enco'] = base64_encode("");
						$all_fields[$id]['id_parent_table'] = 0;
					}
				}
				$all_fields[$id][$key] = safe_output($f);
				$all_fields[$id]['data'] = "";
			}
		}
	}

	if (!$id_inventory) {
		return $all_fields;
	}
	
	foreach ($all_fields as $key => $field) {

		$id_incident_field = $field['id'];
		
		$data = get_db_value_filter('data', 'tobject_field_data', array('id_inventory'=>$id_inventory, 'id_object_type_field' => $id_incident_field), 'AND');
	
		if ($data === false) {
			$all_fields[$key]['data'] = '';
		} else {
			$all_fields[$key]['data'] = safe_output($data);
		}
	}
	
	return $all_fields;
}

/*
 * Returns all external table type fields.
 */ 
function inventories_get_all_external_field ($external_table_name, $external_reference_field, $data_id_external_table) {
	
	global $config;

	if (empty($external_table_name)) {
		return false;
	}
	
	$sql_check = "SHOW TABLES LIKE '$external_table_name'";
	$exists = process_sql($sql_check);
	if (!$exists) {
		return false;
	}
	
	
	$sql_ext = "SHOW COLUMNS FROM ".$external_table_name;
	$external_data = get_db_all_rows_sql($sql_ext);
				
	$sql = "SELECT * FROM $external_table_name WHERE $external_reference_field=$data_id_external_table";

	$fields_ext = get_db_row_sql($sql);

	if ($fields_ext === false) {
		$fields_ext = array();
	}

	$fields = array();
	foreach ($external_data as $key=>$ext) {
		$fields[$ext['Field']] = $ext['Field'];
	}
	
	$all_fields_ext = array();
	$i = 0;
	foreach ($fields_ext as $key => $val) {
		
		if (($key != $external_reference_field) && (array_key_exists($key, $fields))) {
			$all_fields_ext[$i]['label_enco'] =  base64_encode($key);
			$all_fields_ext[$i]['label'] = safe_output($key);
			$all_fields_ext[$i]['data'] = safe_output($val);
			$i++;
		}
	}

	return $all_fields_ext;
}

function inventories_print_tree ($sql_search, $last_update = 0) {
	global $config;
	global $enteprise_load;
	echo '<table class="" style="width:99%">';
	echo '<tr><td style="width:100%" valign="top">';

	echo "<em style='float: right; padding-right: 20px;'>".__("Using tree view");
	echo print_help_tip (__("Filters only apply <br> to the first level"), true);
	echo "</em>";

	$object_types = get_db_all_rows_sql("SELECT DISTINCT(tobject_type.id), tobject_type.* FROM `tinventory`, `tobject_type` WHERE tobject_type.show_in_list = 1 AND tinventory.id_object_type = tobject_type.id order by name");

	$sql_search = base64_encode($sql_search);

	if (empty($object_types)) {
		$object_types = array();
	}

	$elements_type = array();

	foreach ($object_types as $key=>$type) {
		$elements_type[$key]['name'] = $type['name'];
			if($type['icon']){
				$elements_type[$key]['img'] = print_image ("images/objects/".$type['icon'], true, array ("style" => 'vertical-align: middle;'));
			}
		$elements_type[$key]['id'] = $type['id'];
	}

	$elements_type[$key+1]['name'] = __('No object type');
	$elements_type[$key+1]['img'] = print_image ("images/objects/box.png", true, array ("style" => 'vertical-align: middle;'));
	$elements_type[$key+1]['id'] = 0;

	echo "<ul style='margin: 0; margin-top: 20px; padding: 0;'>\n";
	$first = true;

	//Clean element based on ACLs
	
	$aux_elems = array();
	foreach ($elements_type as $elem) {

		$count_inventories = 0;

		// if ($enteprise_load !== ENTERPRISE_NOT_HOOK) {
		// 	$count_inventories = inventory_get_count_inventories($elem['id'], base64_decode($sql_search), $config['id_user']); //count
		// } else {
		// 	$count_inventories = inventories_get_count_inventories_for_tree($elem['id'], base64_decode($sql_search)); //count
		// }

		// if ($count_inventories) {
		// 	array_push($aux_elems, $elem);
		// }

		array_push($aux_elems, $elem);
	}
	
	$elements_type = $aux_elems;

	$i = 0;
	
	$end = 0;

	$margin_left_ref = 23;
	
	foreach ($elements_type as $element) {

		$lessBranchs = 0;

		if ($element == end($elements_type)) {
			$end = 1;
		}
		
		$img_id = 'tree_image'.$i.'_object_types_'.$element["id"];

		if ($first) {
			
			if ($element != end($elements_type)) {
				
				$img = print_image ("images/tree/first_closed.png", true, array ("style" => 'vertical-align: middle;', "id" => $img_id, "pos_tree" => "0"));
				$first = false;
			}
			else {
				$lessBranchs = 1;
				$img = print_image ("images/tree/one_closed.png", true, array ("style" => 'vertical-align: middle;', "id" => $img_id, "pos_tree" => "1"));
			}
		}
		else {
			if ($element != end($elements_type))
				$img = print_image ("images/tree/closed.png", true, array ("style" => 'vertical-align: middle;', "id" => $img_id, "pos_tree" => "2"));
			else
			{
				$lessBranchs = 1;
				$img = print_image ("images/tree/last_closed.png", true, array ("style" => 'vertical-align: middle;', "id" => $img_id, "pos_tree" => "3"));
			}
		}

		if ($enteprise_load !== ENTERPRISE_NOT_HOOK) {
			$inventories_stock = inventory_get_count_inventories($element['id'], base64_decode($sql_search), $config['id_user'], true, $last_update); //all inventories to calculate stock
		} else {
			$inventories_stock = inventories_get_count_inventories_for_tree($element['id'], base64_decode($sql_search), true, $last_update); //all inventories to calculate stock
		}				
		
		// STOCK
		$total_stock = inventories_get_total_stock($inventories_stock);
		$unused_stock = inventories_get_stock($inventories_stock, 'unused');
		$new_stock = inventories_get_stock($inventories_stock, 'new');
		$min_stock = get_db_value('min_stock', 'tobject_type', 'id', $element['id']);
		
		if ($element['id'] == 0) { //no type
			$min_stock = 0;
		}
		
		$color_div = 'no_error_stock';
		if ($total_stock < $min_stock) {
			$color_div = 'error_stock';
			$min_stock = "<font color='#FF000'>".$min_stock."</font>";
		}
	
		$id_div = "object_types_".$element['id'];
		echo "<li style='margin: 0px 0px 0px 0px;'>
			<a style='vertical-align: middle;' onfocus='JavaScript: this.blur()' href='javascript: loadSubTree(\"object_types\", \"" . $element['id'] . "\", " . $lessBranchs . ", \"\" ,\"" . $sql_search .  "\", \"" . $i .  "\", \"" . $end . "\", \"" . $last_update . "\")'>" .
			$img . "&nbsp;" . $element["img"] ."&nbsp;" . safe_output($element['name'])."</a>"."&nbsp;&nbsp;"."($total_stock:$new_stock:$unused_stock:$min_stock)".print_help_tip(__("Total").':'.__("New").':'.__("Unused").':'.__("Min. stock"), true);

		if ($end) {
			echo "<div hiddenDiv='1' loadDiv='0' class='tree_view' id='tree_div" . $i . "_object_types_" . $element["id"] . "'></div>";
		} else {
			echo "<div hiddenDiv='1' loadDiv='0' class='tree_view tree_view_branch' id='tree_div" . $i . "_object_types_" . $element["id"] . "'></div>";
		}
	
		echo "</li>\n";

		$i++;
	}
	
	echo "</ul>\n";
	echo '</td>';
	echo '</tr>';
	echo '</table>';
	
	return;
}

function inventories_printTable($id_item, $type, $id_father) {
	global $config;

	switch ($type) {
		
		case 'inventory':
		case 'child':
		case 'child2':
			$info_inventory = get_db_row('tinventory', 'id', $id_item);

			$info_fields = get_db_all_rows_filter('tobject_type_field', array('id_object_type'=>$id_father));
			
			if ($info_inventory !== false) {
				echo '<table border="0" class="listing inv_details_table" style="width:300px; align:center;">';
				
				echo '<tr><th colspan="2" style="font-size:15px; line-height:24px;">';
				echo $info_inventory['name'];
				echo '<a href="index.php?sec=inventory&sec2=operation/inventories/inventory_detail&id='.$id_item.'">';
				echo "<img class='inventory_table_edit' src='images/application_edit_white.png'>";
				echo '</a>';
				echo '</th></tr>';
				echo '</tr>';

				if ($info_inventory['owner'] != '') {
					$owner = $info_inventory['owner'];
					$name_owner = get_db_value('nombre_real', 'tusuario', 'id_usuario', $owner);
				} else {
					$name_owner = '--';
				}
				echo '<tr><td class="datos"><b>'.__('Owner').': </b></td>';
				echo '<td class="datos"><b>'.$name_owner.'</b></td>';
				echo '</tr>';

					
				if ($info_inventory['id_parent'] != 0) {
					$parent = $info_inventory['id_parent'];
					$name_parent = get_db_value('name', 'tinventory', 'id', $parent);
				} else {
					$name_parent = '--';
				}
				echo '<tr><td class="datos"><b>'.__('Parent').': </b></td>';
				echo '<td class="datos"><b>'.$name_parent.'</b></td>';
				echo '</tr>';

				if ($info_inventory['id_manufacturer'] != 0) {
					$manufacturer = $info_inventory['id_manufacturer'];
					$name_manufacturer = get_db_value('name', 'tmanufacturer', 'id', $info_inventory['id_manufacturer']);
				} else {
					$name_manufacturer = '--';
				}
				echo '<tr><td class="datos"><b>'.__('Manufacturer').': </b></td>';
				echo '<td class="datos"><b>'.$name_manufacturer.'</b></td>';
				echo '</tr>';
				
				if ($info_inventory['id_contract'] != 0) {
					$contract = $info_inventory['id_contract'];
					$name_contract = get_db_value('name', 'tcontract', 'id', $info_inventory['id_contract']);
				} else {
					$name_contract = '--';
				}
				echo '<tr><td class="datos"><b>'.__('Contract').': </b></td>';
				echo '<td class="datos"><b>'.$name_contract.'</b></td>';
				echo '</tr>';
				
				if ($info_fields !== false) {

					foreach ($info_fields as $key=>$info) {

						echo '<tr><td class="datos"><b>'.$info['label'].': </b></td>';
						
						$sql = "SELECT `data` FROM tobject_field_data WHERE id_inventory=$id_item AND id_object_type_field=".$info['id'];
				
						$value = process_sql($sql);

						echo '<td class="datos"><b>'.$value[0]['data'].'</b></td>';
						echo '</tr>';
						
						if (($info['type'] == 'external') && ($value != false)) {
							
							$all_fields_ext = inventories_get_all_external_field ($info['external_table_name'], $info['external_reference_field'], $info['id']);

							foreach ($all_fields_ext as $key=>$field) {
								echo '<tr><td class="datos"><b>'.$field['label'].': </b></td>';
								echo '<td class="datos"><b>'.$field['data'].'</b></td>';
								echo '</tr>';
							}
						}
					}
				}

				echo '</table>';
				
				echo '</div>';
			}
		break;
	}
	return;
}

function inventories_check_unique_field($data, $type, $id_object_field) {
	
	$sql_unique = "SELECT fd.data 
				   FROM tobject_type_field tf, tobject_field_data fd 
				   WHERE tf.id = fd.id_object_type_field 
				   AND tf.`unique`=1 
				   AND fd.id_object_type_field = " . $id_object_field;
	
	
	$all_data = get_db_all_rows_sql($sql_unique);
	
	if($all_data){
		foreach ($all_data as $key => $dat) {
			if ($dat['data'] == $data && $data != '') {
				return false;
			}
		}
	}
	return true;
}

function inventories_check_unique_update($values, $type, $id_object_field) {
	$sql_unique = "SELECT fd.data, fd.id_object_type_field, fd.id 
				   FROM tobject_type_field tf, tobject_field_data fd 
				   WHERE tf.id = fd.id_object_type_field 
				   AND tf.`unique`=1
				   AND id_object_type_field = " . $id_object_field;
	$all_data = get_db_all_rows_sql($sql_unique);

	foreach ($all_data as $key => $dat) {
		if ($dat['data'] == $values['data'] && $values['data'] != '') {
			$values['no_update'] = 1;
			$values['id_object_type_field'] = $dat['id_object_type_field'];
		}
	}
	return $values;
}

// Checks if $data exists on an unique field
function inventories_check_no_unique_field($data, $type) {
	
	$sql_unique = "SELECT data FROM tobject_field_data 
				WHERE id_object_type_field IN (
					SELECT id FROM tobject_type_field
					WHERE type='$type' AND `unique`=0)";
					
	$all_data = get_db_all_rows_sql($sql_unique);
	
	foreach ($all_data as $key => $dat) {
		if ($dat['data'] == $data && $data != '') {
			return false;
		}
	}
	return true;
}

function inventories_link_get_name($id_inventory) {
	
	$name = get_db_value('name', 'tinventory', 'id', $id_inventory);
	
	return $name;
}

function inventories_get_count_inventories_for_tree($id_item, $sql_search = '', $get_inventories = false, $last_update = false) {

	if ($id_item == 0) { //no type
		$sql_search .= " AND tinventory.id_object_type IS NULL";
	} else {
		$sql_search .= " AND tinventory.id_object_type = $id_item";
	}

	if ($last_update) {
		$sql_search .= " ORDER BY last_update DESC";
	} else {
		$sql_search .= " ORDER BY name ASC";
	}

	$cont = get_db_all_rows_sql($sql_search);
	
	if ($cont === false) {
		return 0;
	}
	
	if ($get_inventories) {
		return $cont;
	}
	
	return count($cont);
}
/*
*function that returns the default values ​​of the inventory
*allows adding associated company and associated users for defect false
*/
function object_fields_default($company = false, $user = false){
	$object_fields_default = array();
		$object_fields_default[0]  = 'id';
		$object_fields_default[1]  = 'name';
		$object_fields_default[2]  = 'owner';
		$object_fields_default[3]  = 'id_parent';
		$object_fields_default[4]  = 'id_object_type';
		$object_fields_default[5]  = 'id_manufacturer';
		$object_fields_default[6]  = 'id_contract';
		$object_fields_default[7]  = 'status';
		$object_fields_default[8]  = 'receipt_date';
		$object_fields_default[9]  = 'issue_date';
		$object_fields_default[10]  = 'description';
		if($company){
			$object_fields_default[11]  = 'name_company';
		}
		if($user){
			$object_fields_default[12]  = 'associated_user';	
		}

	return $object_fields_default;
}

/*
*function that returns the prepared checkboxess
*it is necessary to pass the parameters and the way to return them
*/
function form_inventory ($params, $return = true){
	//field label object types
	$select_label_object = '<div class = "divform" id = "pr">';
		$select_label_object .= '<table class="search-table"><tr><td>';
			$select_label_object .= print_label (__('Object fields').'<span id="object_fields_select_all"><a href="javascript: select_all_object_field()" >'.__('Select all').'</a><span>', '','',true);
			$select_label_object .= '<div id = "object_fields_search_check" class="div_multiselect" >';
			//checkbox id
			if ($params['object_fields'][0]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[0]" checked value="id" id="id"><label for="id">'.__('ID').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[0]" value="id" id="id"><label for="id">'.__('ID').'</label>';
			}

			//checkbox name
			if ($params['object_fields'][1]){	
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[1]" checked value="name" id="name"><label for="name">'.__('Name').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[1]" value="name" id="name"><label for="name">'.__('Name').'</label>';
			}

			//checkbox owner
			if ($params['object_fields'][2]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[2]" checked value="owner" id="owner"><label for="owner">'.__('Owner').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[2]" value="owner" id="owner"><label for="owner">'.__('Owner').'</label>';
			}

			//checkbox id_parent
			if ($params['object_fields'][3]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[3]" checked value="id_parent" id="id_parent"><label for="id_parent">'.__('Parent object').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[3]" value="id_parent" id="id_parent"><label for="id_parent">'.__('Parent object').'</label>';
			}

			//checkbox id_object_type
			if ($params['object_fields'][4]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[4]" checked value="id_object_type" id="id_object_type"><label for="id_object_type">'.__('Object type').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[4]" value="id_object_type" id="id_object_type"><label for="id_object_type">'.__('Object type').'</label>';
			}

			//checkbox manufacturer
			if ($params['object_fields'][5]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[5]" checked value="id_manufacturer" id="id_manufacturer"><label for="id_manufacturer">'.__('Manufacturer').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[5]" value="id_manufacturer" id="id_manufacturer"><label for="id_manufacturer">'.__('Manufacturer').'</label>';
			}

			//checkbox id_contract
			if ($params['object_fields'][6]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[6]" checked value="id_contract" id="id_contract"><label for="id_contract">'.__('Contract').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[6]" value="id_contract" id="id_contract"><label for="id_contract">'.__('Contract').'</label>';
			}

			//checkbox status
			if ($params['object_fields'][7]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[7]" checked value="status" id="status"><label for="status">'.__('Status').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[7]" value="status" id="status"><label for="status">'.__('Status').'</label>';
			}

			//checkbox status
			if ($params['object_fields'][8]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[8]" checked value="receipt_date" id="receipt_date"><label for="receipt_date">'.__('Receipt date').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[8]" value="receipt_date" id="receipt_date"><label for="receipt_date">'.__('Receipt date').'</label>';
			}

			//checkbox status
			if ($params['object_fields'][9]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[9]" checked value="issue_date" id="issue_date"><label for="issue_date">'.__('Issue date').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[9]" value="issue_date" id="issue_date"><label for="issue_date">'.__('Issue date').'</label>';
			}

			//checkbox Description
			if ($params['object_fields'][10]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[10]" checked value="description" id="description"><label for="description">'.__('Description').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[10]" value="description" id="description"><label for="description">'.__('Description').'</label>';
			}

			//checkbox Company
			if ($params['object_fields'][11]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[11]" checked value="name_company" id="name_company"><label for="name_company">'.__('Company').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[11]" value="name_company" id="name_company"><label for="name_company">'.__('Company').'</label>';
			}

			//checkbox Associated user
			if ($params['object_fields'][12]){
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[12]" checked value="associated_user" id="associated_user"><label for="associated_user">'.__('Associated users').'</label>';
			} else {
				$select_label_object .= '<input type="checkbox" class="checkbox_object_field" name="object_fields[12]" value="associated_user" id="associated_user"><label for="associated_user">'.__('Associated users').'</label>';
			}

			

			//checkbox custom fields
			if ($params['object_fields_custom']){
				$i=13;
				foreach ($params['object_fields_custom'] as $object) {
					if($params['object_fields'][$i]){
						$select_label_object .= '<input name="object_fields['.$i.']" checked class="checkbox_object_field" value="'.$object['id'].'" type="checkbox" id="'.$object['id'].'">';
					} else {
						$select_label_object .= '<input name="object_fields['.$i.']" class="checkbox_object_field" value="'.$object['id'].'" type="checkbox" id="'.$object['id'].'">';
					}	
					$select_label_object .= '<label for="'.$object['id'].'">'.$object['label'].'</label>';
					$i++;
				}
			}
			$select_label_object .=		'</div>';
		$select_label_object .= '</td></tr></table>';
	$select_label_object .= '</div>';
	
	if($return){
		echo $select_label_object;
	}
	else{
		return $select_label_object; 
	}
}

/*
*function that returns and sets the parameters of the inventory
*it is necessary to pass the parameters
*/
function inventories_filter_params($params_array){
	global $config;
	//Id_type_object
	if(isset($params_array['id_object_type_search']) && $params_array['id_object_type_search'] != ''){
		$params['id_object_type_search'] = $params_array['id_object_type_search'];
	}
	else {
		$params['id_object_type_search'] = -1;
	}

	//Object fields custom
	if(isset($params_array['object_fields_custom']) && $params_array['object_fields_custom'] != ''){
		$params['object_fields_custom'] = $params_array['object_fields_custom'];
	}
	else{
		if ($params['id_object_type_search'] != -1) {
			//for object fields
			$sql_object_fields_custom = 'select label, id from tobject_type_field where 
										show_list=1 and id_object_type='. $params['id_object_type_search'];
			$object_fields_custom = get_db_all_rows_sql($sql_object_fields_custom);
			//id_type_object
			$params['object_fields_custom'] = $object_fields_custom;
		}
	}

	//Field object_fields
	if(isset($params_array['object_fields']) && $params_array['object_fields'] != ''){
		$params['object_fields'] = $params_array['object_fields'];
	} else {
		$object_fields_default = object_fields_default(false);
		$params['object_fields'] = $object_fields_default;
	}

	//Count object_custom_fields
	if(isset($params_array['count_object_custom_fields']) && $params_array['count_object_custom_fields'] != ''){
		$params['count_object_custom_fields'] = $params_array['count_object_custom_fields'];
	} 
	else {
		$params['count_object_custom_fields'] = 0;
	}

	//search word in the inventory only name, description,id,status and custom fields
	if(isset($params_array['search_free']) && $params_array['search_free'] != ''){
		$params['search_free'] = $params_array['search_free'];
	} 
	else {
		$params['search_free'] = '';
	}

	if(isset($params_array['search_description']) && $params_array['search_description'] != ''){
		$params['search_description'] = $params_array['search_description'];
	} 
	else {
		$params['search_description'] = '';
	}

	//Block size
	if(isset($params_array['block_size']) && $params_array['block_size'] != ''){
		$params['block_size'] = $params_array['block_size'];
	}
	else {
		$params['block_size'] = $config['block_size'];
	}

	//Owner
	if(isset($params_array['owner']) && $params_array['owner'] != ''){
		$params['owner'] = $params_array['owner'];
	} 
	else {
		$params['owner'] = '';
	}

	//Manufacturer
	if(isset($params_array['id_manufacturer']) && $params_array['id_manufacturer'] != ''){
		$params['id_manufacturer'] = $params_array['id_manufacturer'];
	} 
	else {
		$params['id_manufacturer'] = 0;
	}

	//Contract
	if(isset($params_array['id_contract']) && $params_array['id_contract'] != ''){
		$params['id_contract'] = $params_array['id_contract'];
	} 
	else {
		$params['id_contract'] = 0;
	}

	//status
	if(isset($params_array['inventory_status']) && $params_array['inventory_status'] != ''){
		$params['inventory_status'] = $params_array['inventory_status'];
	} 
	else {
		$params['inventory_status'] = '0';
	}

	//Company
	if(isset($params_array['id_company']) && $params_array['id_company'] != ''){
		$params['id_company'] = $params_array['id_company'];
	} 
	else {
		$params['id_company'] = '';
	}

	//Associated_user
	if(isset($params_array['associated_user']) && $params_array['associated_user'] != ''){
		$params['associated_user'] = $params_array['associated_user'];
	} 
	else {
		$params['associated_user'] = "";
	}

	//Parent name
	if(isset($params_array['id_parent']) && $params_array['id_parent'] != ''){
		$params['id_parent'] = $params_array['id_parent'];
	} 
	else {
		$params['id_parent'] = 0;
	}

	//sort table
	if(isset($params_array['sort_mode']) && $params_array['sort_mode'] != ''){
		$params['sort_mode'] = $params_array['sort_mode'];
	} 
	else {
		$params['sort_mode'] = 'asc';
	}

	if(isset($params_array['sort_field']) && $params_array['sort_field'] != ''){
		$params['sort_field_num'] = $params_array['sort_field'];
	} 
	else {
		$params['sort_field_num'] = 1;
	}

	//mode list or tree
	if(isset($params_array['mode']) && $params_array['mode'] != ''){
		$params['mode'] = $params_array['mode'];
	} 
	else {
		$params['mode'] = "list";
	}

	if(isset($params_array['last_update']) && $params_array['last_update'] != ''){
		$params['last_update'] = $params_array['last_update'];
	} 
	else {
		$params['last_update'] = 0;
	}

	return $params;
}

/*
*function that creates the query to search the inventories and calls the painting function of the table or tree
*it is necessary to pass the parameters
*/
function inventories_query_search($params){
	global $config;
	$sql_search = '';
	$sql_search_pagination = '';
	$sql_search_not_value = 0;
	
	if ($params['object_fields']) {
		foreach ($params['object_fields'] as $key => $value) {
			if ($key < 11){
				if (!isset($pr)){
					$pr = 'i.'.$value;
				} else {
					$pr .= ',i.'.$value;
				}
			} 
			elseif($key == 11 || $key == 12){
				//no hace nada
			}
			else {
				if (!isset($tr)){
					$tr = $value;
					$params['count_object_custom_fields']++;
				} else {
					$tr .= ','.$value;
					$params['count_object_custom_fields']++;
				}
			}
		}
		if(isset($tr)){
			if($pr){
				$sql_search = 'SELECT i.id as id_not, '.$pr.', o.label, t.data FROM tinventory i, tobject_field_data t, tobject_type_field o where t.id_object_type_field= o.id and i.id = t.id_inventory and t.id_object_type_field IN ('.$tr.')';
				$sql_search_pagination = 'SELECT i.id as id_not, '.$pr.' FROM tinventory i, tobject_field_data t, tobject_type_field o where t.id_object_type_field= o.id and i.id = t.id_inventory';
			}
			else{
				$sql_search = 'SELECT i.id as id_not, o.label, t.data FROM tinventory i, tobject_field_data t, tobject_type_field o where t.id_object_type_field= o.id and i.id = t.id_inventory and t.id_object_type_field IN ('.$tr.')';
				$sql_search_pagination = 'SELECT i.id as id_not, o.label, t.data FROM tinventory i, tobject_field_data t, tobject_type_field o where t.id_object_type_field= o.id and i.id = t.id_inventory';
			}
			$sql_search_count = 'SELECT i.id, i.name FROM tinventory i, tobject_field_data t, tobject_type_field o where t.id_object_type_field= o.id and i.id = t.id_inventory';
		} else {
			$sql_search = 'SELECT i.id as id_not, '.$pr.' FROM tinventory i WHERE 1=1';
			$sql_search_pagination = 'SELECT i.id as id_not, '.$pr.' FROM tinventory i WHERE 1=1';
			$sql_search_count = 'SELECT i.id, i.name FROM tinventory i WHERE 1=1';
		}
		
		if ($params['id_object_type_search'] != -1) {
			$sql_search .= " AND i.id_object_type = ".$params['id_object_type_search'];
			$sql_search_pagination .= " AND i.id_object_type = ".$params['id_object_type_search'];
			$sql_search_count .= " AND i.id_object_type = ".$params['id_object_type_search'];
		}

		if($params['search_free']){
			$pr_explode = explode(",", $pr);
			foreach($pr_explode as $k => $v){
				if(($v != 'i.owner') && ($v != 'i.id_parent') && ($v != 'i.id_object_type')
					&& ($v != 'i.id_manufacturer') && ($v != 'i.id_contract') 
					&& ($v != 'i.description')){
					$pr_explode_simple[] = $v;
				}
			}
			$sql_search_free = "";
			$count_pr_explode_simple = count($pr_explode_simple);
			foreach($pr_explode_simple as $k => $v){
				switch ($v) {
					case 'i.id':
						$sql_search_free .= "i.id LIKE '%".$params['search_free']."%'";
						break;
					case 'i.name':
						$sql_search_free .= "i.name LIKE '%".$params['search_free']."%'";
						break;
					case 'i.status':
						$sql_search_free .= "i.status LIKE '%".$params['search_free']."%'";
						break;
					case 'i.receipt_date':
						$sql_search_free .= "i.receipt_date LIKE '%".$params['search_free']."%'";
						break;
					case 'i.issue_date':
						$sql_search_free .= "i.issue_date LIKE '%".$params['search_free']."%'";
						break;
				}
				
				if($count_pr_explode_simple > 1){
					$sql_search_free .= " OR ";
					$count_pr_explode_simple--; 
				}	
			}

			if($params['search_description'] != ''){
				$count_pr_explode_simple = count($pr_explode_simple);
				if(!$count_pr_explode_simple){
					$sql_search_free .= " i.description LIKE '%".$params['search_free']."%'";
				}
				else{
					$sql_search_free .= " OR i.description LIKE '%".$params['search_free']."%'";
				}
			}
		}
		//search word in the inventory only name, description,id,status and custom fields
		if ($params['id_object_type_search'] != -1 && !empty($params['object_fields']) && $params['search_free'] != '') {
			$string_fields_object_types == '';
			$string_fields_types == '';
			foreach ($params['object_fields'] as $k=>$f) {
				if (is_numeric($f)){
					if($string_fields_object_types == ''){
						$string_fields_object_types = "$f";
					} else {
						$string_fields_object_types .= ",$f ";
					}
				}
			}		

			if ($string_fields_object_types){
				$r_sql = "SELECT distinct ti.id FROM tinventory ti, tobject_field_data fd
				     WHERE ti.id=fd.id_inventory 
				     AND fd.`id_object_type_field` IN ($string_fields_object_types)
				     AND fd.`data` LIKE '%".$params['search_free']."%'";
				$r = get_db_all_rows_sql($r_sql);
				foreach ($r as $k => $v) {
					$r_array[]=$v['id']; 
				}
				$r_array_implode = implode($r_array, ",");
				if(!$r_array_implode && !$sql_search_free){
					$sql_search_not_value = 1;
				}
				if($r_array_implode){
					$sql_search .= " AND (i.id IN ($r_array_implode) ";	
					$sql_search_pagination .= " AND (i.id IN ($r_array_implode) ";
					$sql_search_count .= " AND (i.id IN ($r_array_implode) ";

					if($sql_search_free){
						$sql_search .= " OR ($sql_search_free))";
						$sql_search_pagination .= " OR ($sql_search_free))";
						$sql_search_count .= " OR ($sql_search_free))";
					}
					else{
						$sql_search .= ")";
						$sql_search_pagination .= ")";
						$sql_search_count .= ")";	
					}
				
				}
				else{
					if($sql_search_free){
						$sql_search .= " AND ($sql_search_free)";
						$sql_search_pagination .= " AND ($sql_search_free)";
						$sql_search_count .= " AND ($sql_search_free)";
					}
				}
			} else {
				if($params['search_free']){
					if($sql_search_free){
						$sql_search .= " AND ($sql_search_free)";
						$sql_search_pagination .= " AND ($sql_search_free)";
						$sql_search_count .= " AND ($sql_search_free)";
					}
				}
			}
		} else { //búsqueda solo en nombre y descripción de inventario
			if($params['search_free']){
				if($sql_search_free){
					$sql_search .= " AND ($sql_search_free)";
					$sql_search_pagination .= " AND ($sql_search_free)";
					$sql_search_count .= " AND ($sql_search_free)";
				}
			}
		}
	}

	//owner
	if ($params['owner'] != '') {
		$sql_search .= " AND i.owner = '".$params['owner']."'";
		$sql_search_pagination .= " AND i.owner = '".$params['owner']."'";
		$sql_search_count .= " AND i.owner = '".$params['owner']."'";
	}

	//manufacturer
	if ($params['id_manufacturer'] != 0) {
		$sql_search .= " AND i.id_manufacturer = ".$params['id_manufacturer'];
		$sql_search_pagination .= " AND i.id_manufacturer = ".$params['id_manufacturer'];
		$sql_search_count .= " AND i.id_manufacturer = ".$params['id_manufacturer'];
	}

	//contract
	if ($params['id_contract'] != 0) {
		$sql_search .= " AND i.id_contract = ".$params['id_contract'];
		$sql_search_pagination .= " AND i.id_contract = ".$params['id_contract'];
		$sql_search_count .= " AND i.id_contract = ".$params['id_contract'];
	}

	//status
	if (($params['inventory_status'] != '0') && ($params['inventory_status'] != 'All')) {
		$sql_search .= " AND i.status = '".safe_output($params['inventory_status'])."'";
		$sql_search_pagination .= " AND i.status = '".safe_output($params['inventory_status'])."'";
		$sql_search_count .= " AND i.status = '".safe_output($params['inventory_status'])."'";
	}

	//Company
	if ($params['id_company'] != '') {
		$params['id_company'] = get_db_value ('id', 'tcompany', 'name', $params['id_company']);
		$sql_search .= " AND i.id IN (SELECT id_inventory FROM tinventory_acl WHERE `type`='company' AND id_reference='".$params['id_company']."')";
		$sql_search_pagination .= " AND i.id IN (SELECT id_inventory FROM tinventory_acl WHERE `type`='company' AND id_reference='".$params['id_company']."')";
		$sql_search_count .= " AND i.id IN (SELECT id_inventory FROM tinventory_acl WHERE `type`='company' AND id_reference='".$params['id_company']."')";
	}

	//Associated_user
	if ($params['associated_user'] != '') {
		$sql_search .= " AND i.id IN (SELECT id_inventory FROM tinventory_acl WHERE `type`='user' AND id_reference='".$params['associated_user']."')";
		$sql_search_pagination .= " AND i.id IN (SELECT id_inventory FROM tinventory_acl WHERE `type`='user' AND id_reference='".$params['associated_user']."')";
		$sql_search_count .= " AND i.id IN (SELECT id_inventory FROM tinventory_acl WHERE `type`='user' AND id_reference='".$params['associated_user']."')";
	}

	//Parent id
	if ($params['id_parent'] != 0) {
		$sql_search .= " AND i.id_parent =" . $params['id_parent'];
		$sql_search_pagination .= " AND i.id_parent =" . $params['id_parent'];
		$sql_search_count .=  " AND i.id_parent =" . $params['id_parent'];
	}

	//sort table
	switch ($params['sort_field_num']) {
		case 0: $sort_field = "i.id";break;
		case 1: $sort_field = "i.name";break;
		case 2: $sort_field = "i.owner";break;
		case 7: $sort_field = "i.status";break;
		case 8: $sort_field = "i.receipt_date";break;
		default:
			$sort_field = "name";
			break;
	}

	if ($params['mode'] == 'list'){
		if(!$params['last_update']){
			$sql_search .= " order by $sort_field ".$params['sort_mode'];
			$sql_search_pagination .= " group by i.id order by $sort_field ".$params['sort_mode'];
		} else {
			$sql_search .= " order by i.last_update desc";
			$sql_search_pagination .= " group by i.id order by i.last_update desc ";
		}
		$sql_search_count .=  " group by i.id";
	}

	if($params['object_fields'][11] == 'name_company'){
		$company_query = "SELECT tia.id_inventory, tia.id_reference as id_company, tc.name 
						  FROM tinventory_acl tia, tcompany tc, tinventory ti 
						  WHERE tc.id = tia.id_reference
						  AND ti.id = tia.id_inventory
						  AND tia.type = 'company'"; 
		if($params['id_object_type_search'] != -1){	
			$company_query .= " AND ti.id_object_type =" . $params['id_object_type_search'];
		}
	}

	if($params['object_fields'][12] == 'associated_user'){
		$associated_user_query = "SELECT tia.id_inventory, tia.id_reference as id_user, tu.nombre_real 
						  FROM tinventory_acl tia, tusuario tu, tinventory ti 
						  WHERE tu.id_usuario = tia.id_reference
						  AND ti.id = tia.id_inventory
						  AND tia.type = 'user'"; 
		if($params['id_object_type_search'] != -1){	
			$associated_user_query .= " AND ti.id_object_type =" . $params['id_object_type_search'];
		}
	}

	if($params['mode'] == 'list'){
		if($sql_search_not_value){
			$return = inventories_show_list2(null, null, $params, $params['block_size'], 
											0, $params['count_object_custom_fields'], null, false);
		}
		else{
			$return = inventories_show_list2($sql_search, $sql_search_count, $params, 
											 $params['block_size'], 0, 
											 $params['count_object_custom_fields'], 
											 $sql_search_pagination, 
											 $company_query, $associated_user_query);
		}
	} else {
		$return = inventories_print_tree($sql_search_count, $params['last_update']);
	}

	return $return;
}


function inventories_show_list2($sql_search, $sql_count, $params='', $block_size, $modal = 0, 
								$count_object_custom_fields = 1, $sql_search_pagination, 
								$company_query = false, $associated_user_query = false) {
	global $config;

	$is_enterprise = false;
	if (file_exists ("enterprise/include/functions_inventory.php")) {
		require_once ("enterprise/include/functions_inventory.php");
		$is_enterprise = true;
	}
	
	$write_permission = enterprise_hook ('inventory_check_acl', array ($config['id_user'], '', true));

	//csv querys
	$filter["query"] = $sql_search;
	$filter["query_pag"] = $sql_search_pagination;
	if($company_query){
		$filter["query_company"] = $company_query;
	}
	if($associated_user_query){
		$filter["query_associated_user"] = $associated_user_query;	
	}

	$params['mode'] = 'list';	

	if (!$sql_search) {
		$sql_search = "SELECT * FROM tinventory";
	}

	$pure = get_parameter("pure");
	if ($pure) {
		$block_limit = 5000;
	} else {
		$block_limit = $block_size;
	}

	$offset = get_parameter("offset", 0);
	if ($count_object_custom_fields == 0){
		$sql_search .= " LIMIT ".$block_limit;
		$sql_search .= " OFFSET $offset";
		$sql_search_pagination .= " LIMIT ".$block_limit;
	} else {
		$sql_search_pagination .= " LIMIT ".$block_limit;
	}

	$sql_search_pagination .= " OFFSET $offset";

	$count_inv_d= get_db_all_rows_sql($sql_count);
	$count_inv = count($count_inv_d);

	$inventories_aux = get_db_all_rows_sql($sql_search);

	$inventories_aux_pagination = get_db_all_rows_sql($sql_search_pagination);

	//if chech find company
	if($company_query){
		$find_companies = get_db_all_rows_sql($company_query);
		if(is_array($find_companies) || is_object($find_companies)){
			foreach ($find_companies as $key_comp => $value_comp) {
				$companies_inventory[$value_comp['id_inventory']][] = $value_comp['name'];
			}
		}
	}

	//if check associated user
	if($associated_user_query){
		$find_associated_user = get_db_all_rows_sql($associated_user_query);
		if(is_array($find_associated_user) || is_object($find_associated_user)){
			foreach ($find_associated_user as $key_user => $value_user) {
				$associated_user_inventory[$value_user['id_inventory']][] = $value_user['nombre_real'];
			}
		}
	}

	$i=0;
	$header=array();
	if(is_array($inventories_aux_pagination) || is_object($inventories_aux_pagination)){
		foreach ($inventories_aux_pagination[0] as $key => $value) {
			$header[$key] =1;
		}
		
		if($company_query){
			$header['name_company'] = 1;
		}

		if($associated_user_query){
			$header['associated_user'] = 1;
		}

		if(is_array($inventories_aux_pagination) || is_object($inventories_aux_pagination)){
			foreach ($inventories_aux_pagination as $key => $value) {
				unset($inventories_aux_pagination[$i]['label'], $inventories_aux_pagination[$i]['data']);
				if(is_array($inventories_aux) || is_object($inventories_aux)){
					foreach ($inventories_aux as $k => $v) {
						if(isset($v['label'])){
							$header[$v['label']] =1;
							if($value['id_not'] == $v['id_not']){
								$inventories_aux_pagination[$i][$v['label']] = $v['data'];
							}
						}
					}
				}

				if(is_array($companies_inventory) || is_object($companies_inventory)){
					if($companies_inventory[$value['id_not']]){
						$inventories_aux_pagination[$i]['name_company'] = json_encode($companies_inventory[$value['id_not']]);
					}
					else{
						$inventories_aux_pagination[$i]['name_company'] = '';
					}
				}
				else{
					$inventories_aux_pagination[$i]['name_company'] = '';
				}

				if(is_array($associated_user_inventory) || is_object($associated_user_inventory)){
					if($associated_user_inventory[$value['id_not']]){
						$inventories_aux_pagination[$i]['associated_user'] = json_encode($associated_user_inventory[$value['id_not']]);
					}
					else{
						$inventories_aux_pagination[$i]['associated_user'] = '';
					}
				}
				else{
					$inventories_aux_pagination[$i]['associated_user'] = '';
				}
				$i++;
			}
		}
	}
	//deleted label and data 
	unset($header['label'], $header['data'], $header['']);

	if ($is_enterprise) {
		$inventories = inventory_get_user_inventories($config['id_user'], $inventories_aux_pagination);
	} else {
		$inventories = $inventories_aux_pagination;
	}
	
	if(!$config['csv_compatibility_import']){
		$filter["headers"] = json_encode($header);	
	}

	serialize_in_temp($filter, $config["id_user"]);

	//print table
	if (count($header) == 0) {
		echo ui_print_error_message (__("Empty inventory"), '', true, 'h3', true);
	} else {

		$table = new stdClass();
		$table->id = 'inventory_list';
		$table->class = 'listing';
		$table->width = '100%';
		$table->data = array ();
		$table->head = array ();
		$table->colspan = array();
		
		//thead
		$i=13;

		foreach ($header as $key=>$inventory) {
			switch ($key) {
				case 'id': 			    $table->head[0]  = __('Id');break;
				case 'name': 		    $table->head[1]  = __('Name');break;
				case 'owner': 		    $table->head[2]  = __('Owner');break;
				case 'id_parent': 		$table->head[3]  = __("Parent object");break;
				case 'id_object_type':  $table->head[4]  = __('Object type');break;
				case 'id_manufacturer': $table->head[5]  = __('Manufacturer');break;
				case 'id_contract':     $table->head[6]  = __('Contract');break;
				case 'status':  		$table->head[7]  = __('Status');break;
				case 'receipt_date': 	$table->head[8]  = __('Receipt date');break;
				case 'issue_date': 		$table->head[9]  = __('Issue date');break;
				case 'description':     $table->head[10] = __('Description');break;
				case 'name_company': 	$table->head[11] = __('Company');break;
				case 'associated_user': $table->head[12] = __('Associated users');break;
				default: 
					if($key != 'id_not'){
						$table->head[$i] = $key;
						$i++;
						break;
					}
			}
		}
		
		//thead icon delete and checkbox delete all
		if (!$pure) {
			if (!$modal){
				$table->head[$i] = __('Actions');
				if ($write_permission) {
					$i = $i + 1;
					$table->head[$i] = print_checkbox ('inventorycb-all', "", false, true);
				}
			}
		}

		//tbody
		$idx = 0;
		foreach ($inventories as $key=>$inventory) {
			$i=13;
			foreach ($header as $k=>$headervalue) {
				if ($modal) {
					$url = "javascript:loadInventory(" . $inventory['id'] . ");";
				} else {
					$url = 'index.php?sec=inventory&sec2=operation/inventories/inventory_detail&id='.$inventory['id_not'];
				} 
				switch ($k) {
					case 'id': 
						$data[0] = "<a href=".$url.">".$inventory['id']."</a>";
						break;
					
					case 'name': 
						$data[1] = "<a href=".$url.">".$inventory['name']."</a>";
						break;

					case 'owner':
						if ($inventory['owner'] != '')
							$name_owner = get_db_value('nombre_real', 'tusuario', 'id_usuario', $inventory['owner']); 
						else 
							$name_owner = '--';
						$data[2] = "<a href=".'index.php?sec=users&sec2=operation/users/user_edit&id='.$inventory['owner'].">".$name_owner.'</a>';
						break;
					
					case 'id_parent': 
						if ($inventory['id_parent'] != 0) {
							$name_parent = get_db_value('name', 'tinventory', 'id', $inventory['id_parent']);
							$data[3] = "<a href=".'index.php?sec=inventory&sec2=operation/inventories/inventory_detail&id='.$inventory['id_parent'].">".$name_parent.'</a>';
						} else {
							$name_parent = '--';
							$data[3] = $name_parent;
						}
						break;
					
					case 'id_object_type': 
						if ($inventory['id_object_type'] != 0) {
							$name_object = get_db_value('name', 'tobject_type', 'id', $inventory['id_object_type']);
							$data[4] = "<a href=".'index.php?sec=inventory&sec2=operation/inventories/manage_objects&id='.$inventory['id_object_type'].">".$name_object.'</a>';
						} else { 
							$name_object = '--';
							$data[4] = $name_object;
						}
						break;
					
					case 'id_manufacturer': 
						if ($inventory['id_manufacturer'] != 0) {
							$name_manufacturer = get_db_value('name', 'tmanufacturer', 'id', $inventory['id_manufacturer']);
							$data[5] = "<a href=".'index.php?sec=inventory&sec2=operation/manufacturers/manufacturer_detail&id='.$inventory['id_manufacturer'].">".$name_manufacturer.'</a>';
						} else { 
							$name_manufacturer = '--';
							$data[5] = $name_manufacturer;
						}
						break;
					
					case 'id_contract': 
						if ($inventory['id_contract'] != 0) {
							$name_contract = get_db_value('name', 'tcontract', 'id', $inventory['id_contract']);
							$data[6] = "<a href=".'index.php?sec=customers&sec2=operation/contracts/contract_detail&id_contract='.$inventory['id_contract'].">".$name_contract.'</a>';
						} else { 
							$name_contract = '--';
							$data[6] = $name_contract;
						}
						break;
					
					case 'status': 
						if ($inventory['status'] != "") {
							$data[7] = __(safe_output($inventory['status']));
						} else { 
							$status_none = '--';
							$data[7] = $status_none;
						}
						break;
					case 'receipt_date': 
						if ($inventory['receipt_date'] != "") {
							$data[8] = $inventory['receipt_date'];
						} else { 
							$receipt_date = '--';
							$data[8] = $receipt_date;
						}
						break;
					case 'issue_date': 
						if ($inventory['issue_date'] != "0000-00-00") {
							$data[9] = $inventory['issue_date'];
						} else { 
							$issue_date = '--';
							$data[9] = $issue_date;
						}
						break;
					case 'description': 
						if ($inventory['description'] != "") {
							$count_description = mb_strlen(safe_output($inventory['description']), "UTF-8");
							if($count_description > 30){
								$description_short = mb_substr(safe_output($inventory['description']), 0, 30, "UTF-8");
								$data[10] = safe_input($description_short);
								$data[10] .= "<a href='javascript: show_description_more(".$inventory['id'].",\"".$inventory['description']."\" )'><img style='padding-left:2px;' id ='img_description_".$inventory['id']."' src='images/suspensivos.png'></a>";
							}
							else{
								$data[10] = $inventory['description'];
							}
						} else { 
							$issue_date = '--';
							$data[10] = $issue_date;
						}
						break;
					case 'name_company':
						if($inventory['name_company'] != ""){
							$save_companies = json_decode($inventory['name_company']);
							$data[11] = $save_companies[0];
							if(count($save_companies) > 1){
								$data[11] .= "<a href='javascript: show_companies_more(".$inventory['id'].",".$inventory['name_company']." )'><img style='padding-left:2px;' id ='img_".$inventory['id']."' src='images/suspensivos.png'></a>";
							}
						}
						else{
							$name_company = '--';
							$data[11] = $name_company;
						}
						break;
					case 'associated_user':
						if($inventory['associated_user'] != ""){
							$save_associated_user = json_decode($inventory['associated_user']);
							$data[12] = $save_associated_user[0];
							if(count($save_associated_user) > 1){
								$data[12] .= "<a href='javascript: show_users_more(".$inventory['id'].",".$inventory['associated_user']." )'><img style='padding-left:2px;' id ='img_users_".$inventory['id']."' src='images/suspensivos.png'></a>";
							}
						}
						else{
							$save_associated_user = '--';
							$data[12] = $save_associated_user;
						}
						break;
					case 'id_not':
						break;
					default:
					$sql = sprintf('SELECT type FROM tobject_type_field WHERE id_object_type = %d 
					AND show_list = "1" AND label = "%s"', $inventory["id_object_type"], $k);
					$data_field = get_db_value_sql($sql);
						if ($inventory[$k] != "") {
							if ($data_field == 'checkbox'){
								$data[$i] = print_image('images/checked.png', true);
								$i++;
							}else {
								$data[$i] = $inventory[$k];
								$i++;
							}
						} else { 
							if ($data_field == 'checkbox') {
								$data[$i] = print_image('images/unchecked.png', true);
								$i++;
							} else {
								$inventory_null = '--';
								$data[$i] = $inventory_null;
								$i++;
							}
						}
						break;
				}
			}

			//tbody icon delete and checkbox delete all
			if (!$pure) {
				if (!$modal){
					if ($write_permission) {
					//~ $data[$i] = "<a href='#' onClick='javascript: show_validation_delete_general(\"\", 0, 0, 0, {}, function() {delete_object_inventory(".$inventory["id"].")});'><img src='images/cross.png'></a>";
					$data[$i] = "<a href='#' onClick='javascript: show_validation_delete_general(\"delete_inventory\", ".$inventory['id'].",0,0,0);'><img src='images/cross.png'></a>";
					}
					else{
						$data[$i] = '';
					}
				}
			}
			if (!$pure) {
				if (!$modal){
					if ($write_permission) {
						$i = $i + 1;
						$data[$i] = print_checkbox_extended ('inventorycb-'.$inventory['id'], $inventory['id'], false, '', '', 'class="cb_inventory"', true);
					}
				}
			}

			$table->rowclass[$idx] = 'inventory_info_' . $inventory["id"];
			$idx++;	
			array_push ($table->data, $data);
		}
		
		echo '<div id= "inventory_only_table">';

			$count = $count_inv;
			$params = json_encode($params);
			$params = base64_encode($params);

			$url_pag = "index.php?sec=inventory&sec2=operation/inventories/inventory&params=".$params;
			
			$offset = get_parameter("offset");

			if(!$pure){
				ui_pagination ($count, $url_pag, $offset, $block_size, false, false, '');
			}

			print_table($table);

			if(!$pure){
				ui_pagination ($count, $url_pag, $offset, $block_size, false, true, '');
			}

		echo '</div>';
		if (!$pure) {
			if(!$modal){
				if ($write_permission) {	
					echo '<div class="button-form">';
						echo print_button(__('Delete All'), '', false, 'javascript: delete_massive_inventory()', 'class="sub"', true);
					echo '</div>';
				}
			}
		}
	}
}

function inventories_show_list($sql_search, $sql_count, $params='', $last_update = 0, $modal = 0) {
	global $config;

	$is_enterprise = false;
	if (file_exists ("enterprise/include/functions_inventory.php")) {
		require_once ("enterprise/include/functions_inventory.php");
		$is_enterprise = true;
	}
	
	$write_permission = enterprise_hook ('inventory_check_acl', array ($config['id_user'], $id, true));

	$params['mode'] = 'list';	

	if (!$sql_search) {
		$sql_search = "SELECT * FROM tinventory";
	}

	$pure = get_parameter("pure");

	if ($pure) {
		$block_limit = 5000;
	} else {
		$block_limit = $config["block_size"];
	}

	$sql_search .= " LIMIT ".$block_limit;

	$offset = get_parameter("offset", 0);	

	$sql_search .= " OFFSET $offset";
	
	$inventories_aux = get_db_all_rows_sql($sql_search);
	
	$count_inv = get_db_value_sql($sql_count);
	if ($is_enterprise) {
		$inventories = inventory_get_user_inventories($config['id_user'], $inventories_aux);
	} else {
		$inventories = $inventories_aux;
	}

	if ($inventories === false) {
		echo ui_print_error_message (__("Empty inventory"), '', true, 'h3', true);
	} else {
		$result_check = inventories_check_same_object_type_list($inventories);
		$table->id = 'inventory_list';
		$table->class = 'listing';
		$table->width = '100%';
		$table->data = array ();
		$table->head = array ();
		$table->colspan = array();
		$table->head[0] = __('Id');
		$table->head[1] = __('Name');
		$table->head[2] = __('Owner');
		$table->head[3] = __("Parent object");
		$table->head[4] = __('Object type');
		$table->head[5] = __('Manufacturer');
		$table->head[6] = __('Contract');
		$table->head[7] = __('Status');
		$table->head[8] = __('Receipt date');	
		
		if ($result_check) {
			$res_object_fields = inventories_get_all_type_field ($result_check, false, true);
			$i = 9;
			foreach ($res_object_fields as $key => $object_field) {
				if (isset($object_field["label"])) {
					$table->head[$i] = $object_field['label'];
					$i++;
				}
			}
			if (!$pure) {
				if (!$modal){
					$table->head[$i] = __('Actions');
					if ($write_permission) {
						$i = $i + 1;
						$table->head[$i] = print_checkbox ('inventorycb-all', "", false, true);
					}
				}
			}
		} else {
			if (!$pure) {
				if (!$modal){
					$table->head[9] = __('Actions');
					if ($write_permission) {
						$table->head[10] = print_checkbox ('inventorycb-all', "", false, true);
					}
				}
			}
		}
		
		$count = $count_inv;
		$params = json_encode($params);

		$params = base64_encode($params);

		$url_pag = "index.php?sec=inventory&sec2=operation/inventories/inventory&params=".$params;
		
		$offset = get_parameter("offset");

		if (!$pure) {
			ui_pagination ($count, $url_pag, $offset, 0, false, false, '', true);
		}

		$idx = 0;

		foreach ($inventories as $key=>$inventory) {
			$data = array();

			if ($modal) {
				$url = "javascript:loadInventory(" . $inventory['id'] . ");";
			} else {
				$url = 'index.php?sec=inventory&sec2=operation/inventories/inventory_detail&id='.$inventory['id'];
			} 
			
			$data[0] = "<a href=".$url.">".$inventory['id']."</a>";
			
			$data[1] = "<a href=".$url.">".$inventory['name'].'</a>';
			
			if ($inventory['owner'] != '')
				$name_owner = get_db_value('nombre_real', 'tusuario', 'id_usuario', $inventory['owner']);
			else 
				$name_owner = '--';

			$data[2] = "<a href=".'index.php?sec=users&sec2=operation/users/user_edit&id='.$inventory['owner'].">".$name_owner.'</a>';

			if ($inventory["id_parent"] != 0) {
				$name_parent = get_db_value('name', 'tinventory', 'id', $inventory['id_parent']);
				$data[3] = "<a href=".'index.php?sec=inventory&sec2=operation/inventories/inventory_detail&id='.$inventory['id_parent'].">".$name_parent.'</a>';
			} else {
				$name_parent = '--';
				$data[3] = $name_parent;
			}
			
			if ($inventory['id_object_type'] != 0) {
				$name_object = get_db_value('name', 'tobject_type', 'id', $inventory['id_object_type']);
				$data[4] = "<a href=".'index.php?sec=inventory&sec2=operation/inventories/manage_objects&id='.$inventory['id_object_type'].">".$name_object.'</a>';
			} else { 
				$name_object = '--';
				$data[4] = $name_object;
			}
			
			if ($inventory['id_manufacturer'] != 0) {
				$name_manufacturer = get_db_value('name', 'tmanufacturer', 'id', $inventory['id_manufacturer']);
				$data[5] = "<a href=".'index.php?sec=inventory&sec2=operation/manufacturers/manufacturer_detail&id='.$inventory['id_manufacturer'].">".$name_manufacturer.'</a>';
			} else { 
				$name_manufacturer = '--';
				$data[5] = $name_manufacturer;
				
			}
			
			if ($inventory['id_contract'] != 0) {
				$name_contract = get_db_value('name', 'tcontract', 'id', $inventory['id_contract']);
				$data[6] = "<a href=".'index.php?sec=customers&sec2=operation/contracts/contract_detail&id_contract='.$inventory['id_contract'].">".$name_contract.'</a>';
			} else { 
				$name_contract = '--';
				$data[6] = $name_contract;
			}
			
			if ($inventory['status'] != "") {
				$data[7] = __($inventory['status']);
			} else { 
				$status_none = '--';
				$data[7] = $status_none;
			}
			
			if ($inventory['receipt_date'] != "") {
				$data[8] = $inventory['receipt_date'];
			} else { 
				$receipt_date = '--';
				$data[8] = $receipt_date;
			}
			
			if ($result_check) {

				$result_object_fields = inventories_get_all_type_field ($result_check, $inventory['id'], true);
				$i = 9;
				foreach ($result_object_fields as $k => $ob_field) {
					if (isset($ob_field["label"])) {
						$data[$i] = $ob_field['data'];
						$i++;
					}
				}
				
				if (!$pure) {
					if (!$modal){
						if ($write_permission) {
						$data[$i] .= '<a href="index.php?sec=inventory&sec2=operation/inventories/inventory&quick_delete='.$inventory["id"].'&params='.$params.'" onClick="if (!confirm(\''.__('Are you sure?').'\')) return false;"><img src="images/cross.png"></a>';
						}
					}
				}
				if (!$pure) {
					if (!$modal){
						if ($write_permission) {
							$i = $i + 1;
							$data[$i] = print_checkbox_extended ('inventorycb-'.$inventory['id'], $inventory['id'], false, '', '', 'class="cb_inventory"', true);
						}
					}
				}

			} else {
				if (!$pure) {
					if (!$modal){
						if ($write_permission) {
							$data[9] .= '<a href="index.php?sec=inventory&sec2=operation/inventories/inventory&quick_delete='.$inventory["id"].'" onClick="if (!confirm(\''.__('Are you sure?').'\')) return false;"><img src="images/cross.png"></a>';
						}
					}
				}
				if (!$pure) {
					if (!$modal){
						if ($write_permission) {
							$data[10] = print_checkbox_extended ('inventorycb-'.$inventory['id'], $inventory['id'], false, '', '', 'class="cb_inventory"', true);
						}
					}
				}	
			}
			
			
			$table->rowclass[$idx] = 'inventory_info_' . $inventory["id"];
				$idx++;
				
				array_push ($table->data, $data);
			
		}
		echo '<div id= "inventory_only_table">';
			print_table($table);
		echo '</div>';
		if (!$pure) {
			ui_pagination ($count, $url_pag, $offset, 0, false, true, '', true);
			if(!$modal){
				if ($write_permission) {	
					echo '<div class="button-form">';
					echo print_button(__('Delete All'), '', false, 'javascript: delete_massive_inventory()', 'class="sub"', true);
					echo '</div>';
				}
			}
		}
	}
}
 
function objects_childs ($id_item){
	$sql = "SELECT id FROM tinventory WHERE `id_parent`=$id_item";
	$cont_invent = get_db_all_rows_sql($sql);
	echo $cont_invent;
}

/*
 * IMPORT INVENTORIES FROM CSV. 
 */
function inventories_load_file ($objects_file) {
	$file_handle = fopen($objects_file, "r");
	global $config;

	$line_head = fgets($file_handle);

	$values_head = explode($config["csv_separator"], $line_head);
	foreach ($values_head as $k => $v) {
		$values_head[$k] = trim($v);
	}
	
	$sort_object_type = array_search('id_object_type', $values_head);
	
	if($sort_object_type !== false){
		$save_object_type = $values_head[$sort_object_type];
		unset($values_head[$sort_object_type]);
		array_unshift($values_head, $save_object_type);
	}
	
	$check_name_head  = array_search('name', $values_head);

if($check_name_head !== false){
	$number_line = 1;
	while (!feof($file_handle)) {
		$create = true;
		$object_type_id = 0; 
		$line = fgets($file_handle);
	
		if (($line == '') || (!isset($line))) {
			continue;
		}
		
		preg_match_all('/(.*)'.$config["csv_separator"].'/', $line, $matches);
		$values = explode($config["csv_separator"], $line);

		if($sort_object_type !== false){
			$save_object_type = $values[$sort_object_type];
			unset($values[$sort_object_type]);
			array_unshift($values, $save_object_type);
		}

		$values_array = array(
			'name'            => '',
			'owner'           => '',
			'id_parent'       => 0,
			'id_object_type'  => 0,
			'id_manufacturer' => 0,
			'id_contract'     => 0,
			'status'          => 'new',
			'receipt_date'    => '0000-00-00',
			'issue_date'      => '0000-00-00',
			'description'     => '',
			'public'          => 1,
			'last_update'     => date ("Y-m-d", get_system_time())
		);

		$values_company = false;
		$values_users   = false;
		$values_custom  = false;
		$i = 0;
		if(is_array($values)){
			foreach ($values_head as $k => $v) {
				$v_clean    = trim($v);
				$values[$k] = safe_input(trim($values[$k]));
				switch ($v_clean) {
					case 'id':
						break;
					case 'name':
						if($values[$k] != ''){
							if(!$config['duplicate_inventory_name']){
								$inventory_id = get_db_value ('id', 'tinventory', 'name', $values[$k]);
								if($inventory_id){
									echo ui_print_error_message (
										__('Item name '). $values[$k] . 
										__(' already exists in line ') . $number_line, 
										'', true, 'h3', true
									);
									$create = false;
								}
								else{
									$values_array[$v_clean] = $values[$k];
								}
							}
							else{
								$values_array[$v_clean] = $values[$k];
							}
						}
						else{
							echo ui_print_error_message (
								__('Item name empty in line ') . $number_line, 
								'', true, 'h3', true
							);
							$create = false;
						}
						break;
					case 'owner':
						if($values[$k] != ''){
							$owner_id = get_db_value ('id_usuario', 'tusuario', 'id_usuario', $values[$k]);
							if($owner_id){
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('Owner does not exist in the bbdd in line ') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'id_parent':
						if($values[$k] != '' && $values[$k] != 0){
							$parent_id = get_db_value ('id', 'tinventory', 'id_parent', $values[$k]);
							if($parent_id){
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('Parent id does not exist in the bbdd in line ') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'id_object_type':
						if($values[$k] != '' && $values[$k] != 0){
							$object_type_id = get_db_value('id', 'tobject_type', 'id', $values[$k]);
							if($object_type_id){
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('Object id does not exist in the bbdd in line ') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'id_manufacturer':
						if($values[$k] != '' && $values[$k] != 0){
							$manufacturer_id = get_db_value('id', 'tmanufacturer', 'id', $values[$k]);
							if($manufacturer_id){
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('Manufacturer id does not exist in the bbdd in line') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'id_contract':
						if($values[$k] != '' && $values[$k] != 0){
							$contract_id = get_db_value('id', 'tcontract', 'id', $values[$k]);
							if($contract_id){
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('Contract id does not exist in the bbdd in line ') 
									. $number_line,'', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'status':
						if($values[$k] != ''){
							if($values[$k] == 'new' || $values[$k] == 'inuse' || 
							   $values[$k] == 'unused' || $values[$k] == 'issued'){
								$values_array[$v_clean] = $values[$k];
							}
						}
						break;
					case 'receipt_date':
						if($values[$k] != '' && $values[$k] != '0000-00-00'){
							$receipt_date_uti = strtotime($values[$k]);
							if($receipt_date_uti){
								$values[$k] = date ("Y-m-d", $receipt_date_uti);
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('receipt_date is not correct in line') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'issue_date':
						if($values[$k] != '' && $values[$k] != '0000-00-00'){
							$issue_date_uti = strtotime($values[$k]);
							if($issue_date_uti){
								$values[$k] = date ("Y-m-d", $issue_date_uti);
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('issue_date is not correct in line ') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;
					case 'description':
						if($values[$k] != ''){
							$values_array[$v_clean] = $values[$k];
						}
						break;
					case 'public':
						if($values[$k] != ''){
							if($values[$k] == 0 || $values[$k] == 1){
								$values_array[$v_clean] = $values[$k];
							}
							else{
								echo ui_print_error_message (
									__('Public only allows the values: 1 or 0 in line ') 
									. $number_line, '', true, 'h3', true
								);
								$create = false;
							}
						}
						break;

					case 'id_company':
						if($values[$k] != ""){
							$values[$k]  = preg_replace('/[\[|\]| ]/', '', safe_output($values[$k]));
							$aux_company = explode('.', $values[$k]);
							if(is_array($aux_company)){
								foreach ($aux_company as $key_com => $value_com) {
									$company_id = get_db_value('id', 'tcompany', 'id', $value_com);
									if(!$company_id){
										echo ui_print_error_message (
											__('Company with id = ') . $value_com .
											__(' does not exist in line '). $number_line, 
											'', true, 'h3', true
										);
										$create = false;
									}
								}
							}
							$values_company = $aux_company;		
						}
						else{
							$values_company = false;
						}
						break;
					
					case 'associated_user':
						if($values[$k] != ""){
							$values[$k] = preg_replace('/[\[|\]| ]/', '', safe_output($values[$k]));
							$aux_user   = explode('.', $values[$k]);
							if(is_array($aux_user)){
								foreach ($aux_user as $key_usr => $value_usr) {
									$user_id = get_db_value('id_usuario', 'tusuario', 'id_usuario', $value_usr);
									if(!$user_id){
										echo ui_print_error_message (
											__('User with id_usuario = ') . $value_usr .
											__(' does not exist in line '). $number_line, 
											'', true, 'h3', true
										);
										$create = false;
									}
								}
							}
							$values_users = $aux_user;	
						}
						else{
							$values_users = false;
						}
						break;

					default:
						if($object_type_id){
							$sql = 'SELECT * 
							        FROM tobject_type_field 
							        WHERE id_object_type='.$object_type_id . 
							        ' AND label = "' . safe_input($v_clean) . '"';
							$field = get_db_all_rows_sql($sql);
							
							if ($field == false) {
								echo ui_print_error_message (
									__('Field ') . $field[0]['label'] . 
									__(' is not a field custom of object type ') . $object_type_id .
									__(' in line ') . $number_line,
									'', true, 'h3', true
								);
								$create = false;
							}
						}

						if ($field[0]['inherit']) {
							$ok = inventories_check_unique_field($values[$k], $field[0]['type']);
							if (!$ok) {
								echo ui_print_error_message (
									__('Field ') . $field[0]['label'] . 
									__(' must be unique in line ') . $number_line, 
									'', true, 'h3', true
								);
								$create = false;
							}
						}

						switch ($field[0]['type']) {
							case 'combo':
								$combo_val = explode(",", $field[0]['combo_value']);

								$check_combo = array_search($values[$k], $combo_val);

								if ($check_combo === false) {
									echo ui_print_error_message (
										__('Field ') . $field[0]['label'] . 
										__(' does not match. Only allows the values: ') . $field[0]['combo_value'] . 
										__(' in line ') . $number_line , 
										'', true, 'h3', true
									);
									$create = false;
								}
								else{
									$values_custom[$i]['id_object_type_field'] = $field[0]['id'];
									$values_custom[$i]['data'] = $values[$k];
								}
								$i++;
								break;
							case 'numeric':
								$res = is_numeric($values[$k]);
								if (!$res) {
									echo ui_print_error_message (
										__('Field ') . $field[0]['label'] . 
										__(' must be numeric in line ') . $number_line, 
										'', true, 'h3', true
									);
									$create = false;
								}
								else{
									$values_custom[$i]['id_object_type_field'] = $field[0]['id'];
									$values_custom[$i]['data'] = $values[$k];
								}
								$i++;
								break;

							case 'external':
								$table_ext = $field[0]['external_table_name'];
								$exists_table = get_db_sql ("SHOW TABLES LIKE '$table_ext'");
								
								if (!$exists_table) {
									echo ui_print_error_message (
										__('External table ') . $table_ext . 
										__(' does not exist in line ') . $number_line, 
										'', true, 'h3', true
									);
									$create = false;
								}
								
								$id = $field[0]['external_reference_field'];
								$exists_id = get_db_sql ("SELECT $id FROM $table_ext");
								
								if (!$exists_id) {
									echo ui_print_error_message (
										__('Id ') . $id . __(' does not exist in line ') . $number_line, 
										'', true, 'h3', true
									);
									$create = false;
								}
								else{
									$values_custom[$i]['id_object_type_field'] = $field[0]['id'];
									$values_custom[$i]['data'] = $values[$k];
								}
								$i++;
								break;

							case 'text':
								$values_custom[$i]['id_object_type_field'] = $field[0]['id'];
								$values_custom[$i]['data'] = $values[$k];
								$i++;
								break;

							default:
								echo ui_print_error_message (
									__('Field ') . $v_clean . 
									__(' is not a field custom of object type ') . $object_type_id .
									__(' in line ') . $number_line,
									'', true, 'h3', true
								);
								$create = false;
								break;
						}
					break;
				}
			}
		}

		if ($create) {
			$result_id = process_sql_insert('tinventory', $values_array);
			if ($result_id) {
				if($values_custom){
					foreach ($values_custom as $k => $val_data) {
						$val_data['id_inventory'] = $result_id;

						process_sql_insert('tobject_field_data', $val_data);
					}
				}
		
				if ($values_company) {
					foreach ($values_company as $id_company) {
						$values_company_rev['id_inventory'] = $result_id;
						$values_company_rev['id_reference'] = $id_company;
						$values_company_rev['type'] = 'company';
						process_sql_insert('tinventory_acl', $values_company_rev);
					}
				}
				
				if ($values_users) {
					foreach ($values_users as $id_user) {
						$values_users_rev['id_inventory'] = $result_id;
						$values_users_rev['id_reference'] = $id_user;
						$values_users_rev['type'] = 'user';
						process_sql_insert('tinventory_acl', $values_users_rev);
					}
				}
			}
		}
		$number_line++;
	} //end while

	fclose($file_handle);
	echo ui_print_success_message (__('File loaded'), '', true, 'h3', true);
	return;
}
else{
	fclose($file_handle);
	echo ui_print_error_message (__('Invalid file. It does not contain name in the header'), '', true, 'h3', true);
	return;
}
	
}

//check if all inventories has same object type
function inventories_check_same_object_type_list($inventories) {
	$i = 0;
	foreach ($inventories as $key => $inventory) {
		if ($i == 0) {
			$id_object = $inventory['id_object_type'];
		}
		
		if ($inventory['id_object_type'] != $id_object) {

			return false;
		}
		$i++;	
	}
	
	return $id_object;
}

/**
 * Get all types of objects
 *
 */

function inventories_get_inventory_status () {
	$inventory_status = array();
	$inventory_status['new']    = __('New');
	$inventory_status['inuse']  = __('In use');
	$inventory_status['unused'] = __('Unused');
	$inventory_status['issued'] = __('Issued');

	return $inventory_status;
}


/*
 * Total stock = new + in use + unused
 */
function inventories_get_total_stock ($inventories) {
	$count = 0;

	if (!$inventories) {
		return $count;
	}

	foreach ($inventories as $key=>$inventory) {
		$inv_status = get_db_value('status', 'tinventory', 'id', $inventory['id']);
		if ($inv_status != 'issued') {
			$count++;
		}
	}
	return $count;
}

function inventories_get_stock ($inventories, $status='new') {
	$count = 0;

	if (!$inventories) {
		return $count;
	}

	foreach ($inventories as $key=>$inventory) {
		$inv_status = get_db_value('status', 'tinventory', 'id', $inventory['id']);
		if ($inv_status == $status) {
			$count++;
		}
	}
	return $count;
}

function get_inventory_tab ($section, $title, $img_src, $selected = false, $link_class = '') {
	$html = '<li class="' . ($selected ? 'ui-tabs-selected' : '') . '" title="' . $title . '">';
	$html .= '<a class="' . $link_class . '" href="index.php?sec=inventory&sec2=' . $section . '">';
	$html .= '<img src="' . $img_src . '">';
	$html .= '</a>';
	$html .= '</li>';
	
	return $html;
}

function get_inventory_tab_title ($tab) {
	switch ($tab) {
		case 'details':
			return __('Inventory object details');
		case 'tracking':
			return __('Tracking');
		case 'contacts':
			return __('Contacts');
		case 'incidents':
			return __('Tickets');
		case 'relationships':
			return __('Relationships');
		case 'ehorus':
			return __('eHorus');
	}
	
	return '';
}

function get_inventory_help ($tab) {
	switch ($tab) {
		case 'details':
			return integria_help('inventory_detail', true);
		case 'tracking':
			return integria_help('inventory_tracking', true);
		case 'contacts':
			return integria_help('inventory_contacts', true);
		case 'incidents':
			return integria_help('inventory_incidents', true);
		case 'relationships':
			return integria_help('inventory_relationship', true);
	}
	
	return '';
}

function print_inventory_header($selected_tab, $id, $inventory_name, $manage_permission = false, $content = null) {
	$subtitle = sprintf(__('Inventory object #%s: %s'), $id, $inventory_name);
	echo '<h2>' . strtoupper(get_inventory_tab_title($selected_tab)) . '</h2><h4>' . $subtitle . get_inventory_help($selected_tab);
	if ($manage_permission) {
		echo '<form id="delete_inventory_form" name="delete_inventory_form" class="delete action" method="post" action="index.php?sec=inventory&sec2=operation/inventories/inventory_detail">';
		print_input_hidden ('quick_delete', $id);
		echo "<a href='#' id='detele_inventory_submit_form'>".print_image("images/cross.png", true, array("title" => __("Delete inventory object")))."</a>";
		echo '</form>';
	}
	
	if (!empty($content)) echo $content;
	
	echo '</h4>';
}

function print_inventory_tabs($selected_tab, $id, $inventory_name, $manage_permission = false) {
	// Tabs
	$tabs_html = '<ul class="ui-tabs-nav">';
	
	// Tracking
	$tabs_html .= get_inventory_tab('operation/inventories/inventory_tracking&id=' . $id, get_inventory_tab_title('tracking'), 'images/list_view.png', $selected_tab == 'tracking');
	
	// Contacts
	$tabs_html .= get_inventory_tab('operation/inventories/inventory_contacts&id=' . $id, get_inventory_tab_title('contacts'), 'images/groups_small/system-users.png', $selected_tab == 'contacts');
	// Tickets
	$tabs_html .= get_inventory_tab('operation/inventories/inventory_incidents&id=' . $id, get_inventory_tab_title('incidents'), 'images/tickets_tab.png', $selected_tab == 'incidents');
	// Relationships
	$tabs_html .= get_inventory_tab('operation/inventories/inventory_relationship&id=' . $id, get_inventory_tab_title('relationships'), 'images/groups_small/chart_organisation.png', $selected_tab == 'relationships');
	
	// Check if the ehorus tab should be shown
	if (get_ehorus_id_from_inventory_object($id)) {
		// eHorus
		$tabs_html .= get_inventory_tab('operation/inventories/ehorus&inventory_id=' . $id, get_inventory_tab_title('ehorus'), 'images/ehorus/ehorus.png', $selected_tab == 'ehorus', $submenu);
	}
	
	// Details
	$tabs_html .= get_inventory_tab('operation/inventories/inventory_detail&id=' . $id, get_inventory_tab_title('details'), 'images/eye.png', $selected_tab == 'details');
	// Go back
	$tabs_html .= get_inventory_tab('operation/inventories/inventory', __('Back to list'), 'images/volver_listado.png');
	
	$tabs_html .= '</ul>';
	
	print_inventory_header($selected_tab, $id, $inventory_name, $manage_permission, $tabs_html);
}

function print_inventory_ehorus_integration_tabs($selected_client_tab, $id, $inventory_name, $manage_permission = false) {
	$ehorus_section = 'operation/inventories/ehorus';
	
	// Tabs
	$tabs_html = '<ul class="ui-tabs-nav tabs-ehorus">';
	
	// Files
	$tabs_html .= get_inventory_tab(
		$ehorus_section . '&inventory_id=' . $id . '&client_tab=files',
		__('Files'),
		'images/ehorus/files.png',
		$selected_client_tab == 'files',
		'tab_files'
	);
	// Services
	$tabs_html .= get_inventory_tab(
		$ehorus_section . '&inventory_id=' . $id . '&client_tab=services',
		__('Services'),
		'images/ehorus/services.png',
		$selected_client_tab == 'services',
		'tab_services'
	);
	// Processes
	$tabs_html .= get_inventory_tab(
		$ehorus_section . '&inventory_id=' . $id . '&client_tab=processes',
		__('Processes'),
		'images/ehorus/processes.png',
		$selected_client_tab == 'processes',
		'tab_processes'
	);
	// Display
	$tabs_html .= get_inventory_tab(
		$ehorus_section . '&inventory_id=' . $id . '&client_tab=display',
		__('Display'),
		'images/ehorus/vnc.png',
		$selected_client_tab == 'display',
		'tab_display'
	);
	// Terminal
	$tabs_html .= get_inventory_tab(
		$ehorus_section . '&inventory_id=' . $id . '&client_tab=terminal',
		__('Terminal'),
		'images/ehorus/terminal.png',
		$selected_client_tab == 'terminal',
		'tab_terminal'
	);
	// System
	$tabs_html .= get_inventory_tab(
		$ehorus_section . '&inventory_id=' . $id,
		__('Information'),
		'images/ehorus/ehorus.png',
		empty($selected_client_tab),
		'tab_system'
	);
	
	
	// Go back
	$tabs_html .= get_inventory_tab(
		'operation/inventories/inventory_detail&id=' . $id,
		__('Back to detail'),
		'images/flecha_volver.png'
	);
	
	$tabs_html .= '</ul>';
	
	print_inventory_header('ehorus', $id, $inventory_name, $manage_permission, $tabs_html);
}

function inventories_get_external_tables ($id_object_type) {
	global $config;
	
	$sql = "SELECT external_table_name FROM tobject_type_field WHERE id_object_type=".$id_object_type." AND `type`='external'";
	
	$tables = get_db_all_rows_sql($sql);
	
	if ($tables == false) {
		$tables = array();
	}
	
	$ext_tables = array();
	foreach ($tables as $ext) {
		$ext_tables[$ext['external_table_name']] = $ext['external_table_name'];
	}
	
	$external_tables = array_unique($ext_tables);
	return $external_tables;
}

function inventories_get_info($id_item, $id_father) {
	global $config;
	
	$result = array();

	$info_inventory = get_db_row('tinventory', 'id', $id_item);
	$info_fields = get_db_all_rows_filter('tobject_type_field', array('id_object_type' => $id_father));
	
	if ($info_inventory !== false) {
		$result['name'] = $info_inventory['name'];
		
		$result['data'] = array();
		
		if (!empty($info_inventory['owner'])) {
			$owner = $info_inventory['owner'];
			$name_owner = get_db_value('nombre_real', 'tusuario', 'id_usuario', $owner);
			
			if (empty($name_owner))
				$name_owner = '--';
		} else {
			$name_owner = '--';
		}
		$row = array();
		$row['label'] = __('Owner');
		$row['data'] = $name_owner;
		$result['data'][] = $row;
		
		if (!empty($info_inventory['id_parent'])) {
			$parent = $info_inventory['id_parent'];
			$name_parent = get_db_value('name', 'tinventory', 'id', $parent);
			
			if (empty($name_parent))
				$name_parent = '--';
		} else {
			$name_parent = '--';
		}
		$row = array();
		$row['label'] = __('Parent');
		$row['data'] = $name_parent;
		$result['data'][] = $row;
		
		if (!empty($info_inventory['id_manufacturer'])) {
			$manufacturer = $info_inventory['id_manufacturer'];
			$name_manufacturer = get_db_value('name', 'tmanufacturer', 'id', $info_inventory['id_manufacturer']);
			
			if (empty($name_manufacturer))
				$name_manufacturer = '--';
		} else {
			$name_manufacturer = '--';
		}
		$row = array();
		$row['label'] = __('Manufacturer');
		$row['data'] = $name_manufacturer;
		$result['data'][] = $row;
		
		if (!empty($info_inventory['id_contract'])) {
			$contract = $info_inventory['id_contract'];
			$name_contract = get_db_value('name', 'tcontract', 'id', $info_inventory['id_contract']);
			
			if (empty($name_contract))
				$name_contract = '--';
		} else {
			$name_contract = '--';
		}
		$row = array();
		$row['label'] = __('Contract');
		$row['data'] = $name_contract;
		$result['data'][] = $row;
		
		if ($info_fields !== false) {
			foreach ($info_fields as $info) {
				
				$filter = array(
						'id_inventory' => $id_item,
						'id_object_type_field' => $info['id']
					);
				$value = get_db_value_filter ('data', 'tobject_field_data', $filter);
				
				$data = '--';
				if (!empty($value))
					$data = $value;
				
				$info_field = array();
				$info_field['label'] = $info['label'];
				$info_field['data'] = $data;
				
				$result['data'][] = $info_field;
				
				if (($info['type'] == 'external') && ($value != false)) {
					
					$all_fields_ext = inventories_get_all_external_field ($info['external_table_name'], $info['external_reference_field'], $info['id']);
					
					foreach ($all_fields_ext as $field) {
						
						$data = '--';
						if (!empty($field['data']))
							$data = $field['data'];
						
						$info_field_external = array();
						$info_field['label'] = $field['label'];
						$info_field['data'] = $data;
						$result['data'][] = $info_field_external;
					}
				}
			}
		}
	}
	
	return $result;
}

/**
 * Update affected companies in an inventory.
 *
 * @param int inventory id to update.
 * @param array List of affected companies ids.
 */
function inventory_update_companies ($id_inventory, $companies, $update = false) {
	error_reporting (0);
	$where_clause = '';
	
	if (empty ($companies)) {
		$companies = array (0);
	}
	
	if ($update) {
		$sql = sprintf ("DELETE FROM tinventory_acl
			WHERE id_inventory = %d AND type='company'",
			$id_inventory);
		
		$res = process_sql ($sql);
		
		if ($res !== false && $res > 0) {
			$updated = true;
		}
		
	}
	
	$type = 'company';
	
	foreach ($companies as $id_company) {
		if($id_company != ''){
			$value = array();
			$value['id_inventory'] = $id_inventory;
			$value['id_reference'] = $id_company;
			$value['type'] = $type;
		$tmp = process_sql_insert('tinventory_acl', $value);
		}		
	}
	
	if ($update && $updated === true) {
		inventory_tracking($id_inventory, INVENTORY_COMPANIES_UPDATED);
	} else if (!empty($companies) && $companies != array(0)) {
		inventory_tracking($id_inventory, INVENTORY_COMPANIES_CREATED);
	}
}

/**
 * Update affected users in an inventory.
 *
 * @param int inventory id to update.
 * @param array List of affected users ids.
 * @param update = false to create and update = true to update
 */
function inventory_update_users ($id_inventory, $users, $update = false) {
	error_reporting (0);
	$where_clause = '';
	
	if (empty ($users)) {
		$users = array (0);
	}
	if ($update) {
		
		$sql = sprintf ("DELETE FROM tinventory_acl WHERE id_inventory = %d AND type='user'", $id_inventory);
		$res = process_sql ($sql);

		if ($res !== false && $res > 0) {
			$updated = true;
		}
	}
	
	$type = 'user';
	
	foreach ($users as $key=>$id_user) {
		if($id_user != ''){
			$value = array();
			$value['id_inventory'] = $id_inventory;
			$value['id_reference'] = $id_user;
			$value['type'] = $type;
			$tmp = process_sql_insert('tinventory_acl', $value);
		}
	}
	
	if ($update && $updated === true) {
		inventory_tracking($id_inventory, INVENTORY_USERS_UPDATED);
	} else if (!empty($users) && $users != array(0)) {
		inventory_tracking($id_inventory, INVENTORY_USERS_CREATED);
	}
}

function inventory_get_companies ($id_inventory, $only_names = true) {
	
	$sql = sprintf ("SELECT tcompany.* FROM tcompany, tinventory_acl
			WHERE tcompany.id = tinventory_acl.id_reference
			AND tinventory_acl.type = 'company'
			AND tinventory_acl.id_inventory = %d", $id_inventory);		
			
	$all_companies = get_db_all_rows_sql ($sql);
	if ($all_companies == false)
		return array ();
	
	global $config;
	$companies = array ();
	foreach ($all_companies as $company) {
		array_push ($companies, $company);
	}
	
	if ($only_names) {
		$result = array ();
		foreach ($companies as $company) {
			$result[$company['id']] = $company['name'];
		}
		return $result;
	}
	return $companies;
}

function inventory_get_users ($id_inventory, $only_names = true) {
	
	$sql = sprintf ("SELECT tusuario.* FROM tusuario, tinventory_acl
			WHERE tusuario.id_usuario = tinventory_acl.id_reference
			AND tinventory_acl.type = 'user'
			AND tinventory_acl.id_inventory = %d", $id_inventory);
				
	$all_users = get_db_all_rows_sql ($sql);
	
	if ($all_users == false)
		return array ();
	
	global $config;
	$users = array ();
	foreach ($all_users as $user) {
		array_push ($users, $user);
	}
	
	if ($only_names) {
		$result = array ();
		foreach ($users as $user) {
			$result[$user['id_usuario']] = $user['nombre_real'];
		}
		
		return $result;
	}
	
	return $users;
}

function inventory_get_user_inventories($id_user, $inventories) {
	if ($inventories == false) {
		return false;
	}

	$user_inventories = array();

	if (!$inventories) {

		return $user_inventories;
	}
	if (is_array($inventories) || is_object($inventories)){
		foreach ($inventories as $key => $inventory) {
			$read_perm = inventory_check_acl($id_user, $inventory['id']);
			
			if ($read_perm) {
				array_push($user_inventories, $inventory);
			}
		}
	}
	return $user_inventories;
}

function strings_without_translations () {
	
	__("new");
	__("inuse");
	__("unused");
	__("issued");
	
	return;
}
?>
