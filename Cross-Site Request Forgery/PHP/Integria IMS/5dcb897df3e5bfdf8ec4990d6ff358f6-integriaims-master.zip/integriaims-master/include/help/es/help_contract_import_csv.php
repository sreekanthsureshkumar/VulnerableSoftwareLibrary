<h1>Importación de Contratos</h2>

<p>
	La importación podrá ser hecha por medio de una exportación realizada en integria (en la cuál no se deberá manipular la estructura tal y como se genera en el sistema) y podrá hacerse por medio de un archivo de tipo CSV creado a mano.
</p>

</br>

<p>
    Para el primer caso el fichero de entrada será el mismo que previamente exportamos, con lo que no impone problemas a la hora procesar el CSV.
</p>

</br>

<p>
    Para el segundo caso se deberán meter una serie de parámetros por orden, unos obligatorios y otros no, pudiendo escoger valores vacíos para estos últimos. Los campos serán los siguientes siguiendo el orden lógico establecido por la herramienta:
</p>

</br>

<p>
    <strong>
        &emsp;Nombre
    </strong>
</p>

</br>
<p>
    <strong>
        &emsp;Número de contrato
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Descripción
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Fecha inicio
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Fecha fin
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id de empresa
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id de SLA
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id de grupo
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Privado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Estado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Tipo de contrato
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Campos personalizados:
    </strong> 
            deberán existir previamente en su sistema Integria IMS y deberán indicarse en orden, 
</p>
<p>
            &emsp;pudiendo elegir un valor, o en caso de no querer darles valor, espacio en blanco
</p>

<h2>Ejemplo (tipo 1 con dos campos personalizados, uno de texto y otro numerico)</h2>

<p>
    "Contrato prueba,123456789,Descripcion,2017-07-25,2017-07-31,1,,,0,1,1,Integria,20”
</p>