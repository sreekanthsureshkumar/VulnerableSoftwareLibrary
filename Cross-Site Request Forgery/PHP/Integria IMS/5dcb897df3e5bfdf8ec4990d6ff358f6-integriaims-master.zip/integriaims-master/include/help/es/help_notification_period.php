<h1>Periodo de notificación</h1>

<p>
Éste es el tiempo mínimo entre dos notificaciones de correo-e consecutivas para un aviso de S.L.A. Por ejemplo, si su parámetro de S.L.A. para la notificación por inactividad está configurado para avisarle cada 2 horas, y el periodo de notificación está configurado en 24 horas, no recibirá nada en un intervalo de 24 horas desde la primera notificación. Este parámetro es global.
</p>
