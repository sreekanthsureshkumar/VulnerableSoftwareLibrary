<h1>Descarga de archivos</h1>

<p>
Por defecto, todos los archivos y subdirectorios descargables deben encontrarse en el directorio /attachment/downloads en la ra&iacute;z del directorio base de Integria.
Pueden subirse con una conexión FTP o usando el Explorador de Archivos de Integria (no recomendado para archivos demasiado grandes, debido a las limitaciones de la configuraci&oacute;n de PHP).
</p>
