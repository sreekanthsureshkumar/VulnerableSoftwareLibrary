<h1>Cerrado autom&aacute;tico de incidentes</h1>

<p>
Define un l&iacute;mite (en D&Iacute;AS), en el cual Integria IMS cerrar&aacute; autom&aacute;ticamente los 
incidentes sin ning&uacute;n tipo de actualizaci&oacute;n en XX d&iacute;as (este l&iacute;mite est&aacute; 
configurado en la opci&oacute;n de la configuraci&oacute;n "Auto cerrado de incidente" y su unidad son los D&Iacute;AS).

El propietario del incidente recibe un aviso mediante mail.

<br><br><small>El valor 0 deshabilita esta funcionalidad.</small>
</p>
