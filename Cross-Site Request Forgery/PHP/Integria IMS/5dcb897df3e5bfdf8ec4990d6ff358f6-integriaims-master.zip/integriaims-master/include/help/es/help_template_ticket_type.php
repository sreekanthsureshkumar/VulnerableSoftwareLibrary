<h1>Plantillas para partes de trabajo</h1>
</br>
<p>
	Un ticket podrá tener asociado uno o varios partes de trabajo. Un parte de trabajo es un documento que se podrá descargar para su posterior validación. Para facilitar la creación de este documento de forma sencilla y flexible, tenemos las plantillas. Un tipo de ticket sólo podrá tener asociada una única plantilla.
</p>
<p>
	<b>Creación de plantilla</b>
	<ul>
		<li>- Opción 'Crear' que aparece debajo del listado.</li>
		<li>- Opción 'Crear plantilla de parte de trabajo' que se muestra en el menú lateral.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_1.png", false, false); ?>
</br>
<p>
	<b>Elementos que forman la plantilla:</b>
	<ul>
		<li>- Nombre de la plantilla.</li>
		<li>- Descripción: es opcional.</li>
		<li>- Asignar a: aquí se podrán elegir los tipos de ticket que van a tener asociada esa plantilla.</li>
		<li>- Contenido: puede ser texto plano o texto html. Para elegir la opción html, habrá que seleccionar el icono HTML en la barra de herramientas.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_3.png", false, false); ?>
</br>
<p>
	Se pueden añadir imágenes de forma sencilla seleccionando el siguiente icono:
</p>
</br>
	<?php print_image("images/help/wo_4.png", false, false); ?>
</br>
<p>El siguiente paso sería añadir la url de la imagen.</p>
</br>
<p>
	También podremos Utilizar macros: Las siguientes palabras serán reemplazadas por el valor real en las plantillas que las usen:
	<ul>
		<li>- <b>_sitename_:</b> Nombre de la página, tal y como está definido en la configuración.</li>
		<li>- <b>_incident_title_:</b> Título del incidente.</li>
		<li>- <b>_username_:</b> Nombre del usuario.</li>
		<li>- <b>_fullname_:</b> Nombre completo del usuario.</li>
		<li>- <b>_incident_id_:</b> ID del incidente.</li>
		<li>- <b>_url_:</b> URL del incidente.</li>
		<li>- <b>_creation_timestamp_:</b> Fecha/Hora de la creación del incidente.</li>
		<li>- <b>_update_timestamp_:</b> Última vez que el incidente fue actualizado.</li>
		<li>- <b>_owner_:</b> Usuario que gestiona el incidente.</li>
		<li>- <b>_group_:</b> Grupo asignado al incidente.</li>
		<li>- <b>_author_:</b> Creador del incidente.</li>
		<li>- <b>_type_tickets_:</b> Tipo de tickets.</li>
		<li>- <b>_priority_:</b> Prioridad del incidente.</li>
		<li>- <b>_status_:</b> Estado del incidente.</li>
		<li>- <b>_resolution_:</b> Resolución del incidente.</li>
		<li>- <b>_time_used_:</b> Tiempo total usado en el incidente.</li>
		<li>- <b>_incident_main_text_:</b> Descripción del incidente. </li>
		<li>- Plantillas de campos personalizados: Esto permite que al crear un tipo de objeto el nombre de los campos que agregas puedes incluirlos como una macro la cual mostrara el valor de dicho campo: _nombre del campo personalizado_.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wp_7.png", false, false); ?>
</br>
<p>
	Estas macros podrán ser utilizadas en código html:
</p>
</br>
	<?php print_image("images/help/wp_8.png", false, false); ?>
</br>
<p>
	A continuación, tenemos el listado con todas las plantillas que se han generado. En esta vista se muestra: nombre, descripción, a qué tipo de ticket está asignada, borrado y edición.
</p>
</br>
	<?php print_image("images/help/wo_5.png", false, false); ?>
</br>