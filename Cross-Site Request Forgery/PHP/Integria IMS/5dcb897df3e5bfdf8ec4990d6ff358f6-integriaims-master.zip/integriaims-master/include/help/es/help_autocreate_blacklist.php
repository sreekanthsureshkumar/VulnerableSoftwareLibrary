<h1>Auto creado de lista negra</h1>

<p>
Lista de nombres de usuario separados por espacios que no ser&aacute;n creados autom&aacute;ticamente.
</p>
