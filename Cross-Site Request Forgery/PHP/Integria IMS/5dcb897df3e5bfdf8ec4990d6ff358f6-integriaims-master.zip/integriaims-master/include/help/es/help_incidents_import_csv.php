<h1>Importación de incidencias</h2>

<p>
	La importación podrá ser hecha por medio de una exportación realizada en integria (en la cuál no se deberá manipular la estructura tal y como se genera en el sistema) y podrá hacerse por medio de un archivo de tipo CSV creado a mano.
</p>

</br>

<p>
    Para el primer caso el fichero de entrada será el mismo que previamente exportamos, con lo que no impone problemas a la hora procesar el CSV.
</p>

</br>

<p>
    Para el segundo caso se deberán meter una serie de parámetros por orden, unos obligatorios y otros no, pudiendo escoger valores vacíos para estos últimos. Los campos serán los siguientes siguiendo el orden lógico establecido por la herramienta:
</p>

</br>

<p>
    <strong>
        &emsp;Inicio
    </strong>
</p>

</br>
<p>
    <strong>
        &emsp;Cierre
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Título
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Descripción
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id de usuario
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Estado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Prioridad
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del grupo
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Actualización
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del creador
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id de la tarea
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Resolución
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Epílogo
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del padre
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;SLA deshabilitado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del SLA afectado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del tipo de incidencia
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Puntuación
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Correos en copia
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Editor
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del grupo creador
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Último estado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Cerrado por
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data 2
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Bloqueado
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Estado antiguo
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Resolución antigua
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Estado antiguo 2
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Resolución antigua 2
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data 3
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data 4
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Medallas negras
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Medallas de oro
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Campos personalizados:
    </strong> 
            deberán existir previamente en su sistema Integria IMS y deberán indicarse en orden, 
</p>
<p>
            &emsp;pudiendo elegir un valor, o en caso de no querer darles valor, espacio en blanco.
</p>
<p>
            &emsp;En el caso de los tickets será necesario crear el tipo al que pertenecen los campos y 
</p>
<p>
            &emsp;obviamente referenciar ese tipo en el propio ticket.
</p>

<h2>Ejemplo</h2>

<p>
    “2017-07-20 13:38:39,0000-00-00 00:00:00,Ticket prueba,,admin,New(ID),Medium(ID),Customer #B(ID),2017-07-20 13:38:39,admin,0,None,,,0,0,1,0,,admin,Customer #B(ID),0000-00-00 00:00:00,,,,0,1,0,0,0,,,0,0,Integria,20”
</p>