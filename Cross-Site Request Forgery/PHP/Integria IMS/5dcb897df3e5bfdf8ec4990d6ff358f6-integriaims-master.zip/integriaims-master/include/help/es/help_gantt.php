<h1>Gráfico de Gantt interactivo</h1>
<p>
	Muestra la información del proyecto, fusionando la imputación real (en rojo), con el progreso de la tarea (en verde) y la planificación original (azul). Muestra dependencias e hitos.
<p>
	<?php print_image("images/help/project14.png", false, false); ?>
</p>