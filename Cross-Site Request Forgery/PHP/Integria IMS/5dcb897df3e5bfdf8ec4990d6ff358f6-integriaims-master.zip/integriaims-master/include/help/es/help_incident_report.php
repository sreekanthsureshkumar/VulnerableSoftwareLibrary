<h1 style="font-size: 20px;">1. Los informes de incidentes:</h1><br>
	<ul>
		Para poder visualizar los informes de incidentes o soporte, se debe tener el siguiente perfil:
		<li>.-Ver incidentes y pertenecer al grupo de los ticket adecuado.</li>
		<li>.-Ver informes.</li>
	</ul>

<h2 style="font-size: 18px;">1.1. Tres tipos de informes:</h2>
		<li style="font-size: 16px;font-weight: bold;">Informe de soporte: </li>
<br>
	<?php print_image("images/help/inf_su_1.png", false, array('width'=>'900')); ?>
<br>
<p>
	Para crear un informe de este tipo, Integra IMS se basa en las búsquedas personalizadas creadas en la sección de búsqueda de tickets. Así, solo habría que seleccionar el tipo de búsqueda sobre el que queremos el reporte y aparecerá un formulario donde se pueden elegir las siguientes opciones: 
</p>
<br>
	<?php print_image("images/help/inf_su_2.png", false, array('width'=>'900')); ?>
<br>
	<ul>
		<li><strong>Mostrar estadísticas:</strong> Esto permite tener información global de todos los ticket que englobe la búsqueda:
			<ul>
				<li type="square">Gráfica de tickets por grupo: Los grupos a los que pertenecen dichos tickets en porcentaje.</li>
				<li type="square">Gráfica de los máximos creadores de tickets: Los creadores de estos tickets en porcentaje.</li>
				<li type="square">Gráfica de los usuarios asignados: Los usuarios asignados a tickets en porcentaje.</li>
				<li type="square">Estadísticas de tickets: Información detallado sobre los tickets.</li>
				<li type="square">Gráfica de grupos por tiempo.</li>
				<li type="square">Gráfica de cumplimiento de SLA de los ticket que engloba la búsqueda personalizada.</li>
				<li type="square">Listado de ticket clasificados según su estado.</li>
				<li type="square">Listado de ticket clasificados según su prioridad. </li>
				<li type="square">Gráfica de usuarios mas activos.</li>
				<li type="square">Gráfica de los 5 ticket mas activos.</li>
				<li type="square">Gráfica de relación de ticket abiertos y cerrados.</li>
				<li type="square">Histograma de tickets abiertos y cerrados.</li>
				<li type="square">Un pequeño calendario con la actividad de los tickets.</li>
			</ul>
		</li>
		<br>
			<?php print_image("images/help/inf_su_3.png", false, array('width'=>'900')); ?>
		<br>
		<br>
			<?php print_image("images/help/inf_su_4.png", false, array('width'=>'900')); ?>
		<br>
		<li><strong>Mostrar lista de ticket:</strong> lista de todos los tickets que engloba la búsqueda personalizada.
			 Si tenemos el bit de <strong>QA</strong> podemos ver también las valoraciones de cada tiquet y sus porcentajes de S.L.A.,
			  asi como la media de estos (abajo a la izquierda del informe). <strong>**</strong> La busqueda se limita a los primeros 500 resultados en orden de creación, del más nuevo al más antiguo.<strong>**</strong></li>
	</ul>
	<br>
		<?php print_image("images/help/inf_su_5.png", false, array('width'=>'900')); ?>
	<br>
	<li style="font-size: 16px;font-weight: bold;">Ticket único:</li>
<p>
	Para crear un informe de este tipo aparece un campo que se auto-completa si se busca por id o por el título del ticket, con lo cuál mostrara un informe detallado por el ticket buscado.
</p>
<br>
	<?php print_image("images/help/inf_su_6.png", false, array('width'=>'900')); ?>
<br>
<br>

	<?php print_image("images/help/inf_su_7.png", false, array('width'=>'900')); ?>
<br>

<li style="font-size: 16px;font-weight: bold;">Resolución:</li>
<p>
	Este informe está basado en tickets ya cerrados. Se podrá filtrar por usuario creador del ticket, compañía del usuario creador y fecha. Tenemos la opción de visualizar el informe en pantalla, exportarlo a PDF o exportarlo a CSV.
</p>
<br>
<p>
	<?php print_image("images/help/filtro_resolucion.png", false, array('width'=>'900')); ?>
</p>
<br>
<br>
<p>
	La información que muestra es la siguiente:
	<ul>
	<li type="square">Identificador del ticket</li>
	<li type="square">Tipo de ticket</li>
	<li type="square">Compañía del usuario creador del ticket</li>
	<li type="square">Usuario editor</li>
	<li type="square">Usuario creador</li>
	<li type="square">Usuario que cierra el ticket</li>
	<li type="square">Número de personas que intervienen</li>
	<li type="square">Prioridad</li>
	<li type="square">Tiempo que ha pasado hasta que se cierra el ticket</li>
	<li type="square">Tiempo que ha pasado el ticket  en estado Nuevo</li>
	<li type="square">Tiempo que ha pasado el ticket en estados diferentes a Asignado o Cerrado</li>
	<li type="square">Total del tiempo empleado en el ticket. Sumatorio del tiempo asignado en los comentarios.</li>
	
	</ul>
</p>
<br>
<br>
<p>
	<?php print_image("images/help/inf_res.png", false, array('width'=>'900')); ?>	
</p>

