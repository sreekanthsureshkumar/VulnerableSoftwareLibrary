<h1>Los informes de proyectos:</h1>
<p>
	<ul>
		Para poder visualizar los informes de proyectos se debe tener el siguiente perfil:
		<li>.-Ver proyectos o (rol project manager).</li>
		<li>.-Ver informes</li>
	</ul>
</p>
<p>
	Para crear el informe de una manera fácil aparecerá un selector para elegir los proyectos
</p>
<br>
<p>
	<?php print_image("images/help/inf_pr_1.png", false, false); ?>
</p>
<br>
<p>
	Una vez esté seleccionado el proyecto, se podrá visualizar un formulario que consta de:
</p>
<br>
<p>
	<?php print_image("images/help/inf_pr_2.png", false, false); ?>
</p>
<br>
<p>
	<ul>
		<li>Selector de las tareas de dicho proyecto.</li>
		<li>Un checkbox para más información de proyectos: Si utilizamos este check nos mostrará una información detallada de todo el proyecto dividida en diferentes secciones:
			<ul>
				<li>.-Información del proyecto que muestra los datos generales del proyecto (nombre, fecha de inicio, etc)</li>
				<li>.-Personas Involucradas: Todas las personas que participan en el proyecto.</li>
				<li>.-Mano de obra: Computo de horas dedicadas al proyecto.</li>
				<li>.-Presupuesto: Computo de costes del proyecto estimados.</li>
				<li>.-Gráfica de distribución de las tareas: Porcentaje de cada una de las tareas.</li>
				<li>.-Gráfica de distribución del trabajo: Porcentaje del trabajo realizado por cada usuario.</li>
				<li>.-Gráfica de Actividad del proyecto.</li>
				<li>.-Un resumen de cada una de las tareas de dicho proyecto.</li>
			</ul>
			<br>
			<p>
				<?php print_image("images/help/inf_pr_3.png", false, false); ?>
			</p>
			<br>
			<br>
			<p>
				<?php print_image("images/help/inf_pr_4.png", false, false); ?>
			</p>
			<br>
			<br>
			<p>
				<?php print_image("images/help/inf_pr_5.png", false, false); ?>
			</p>
			<br>
		</li>
		<li>Un checkbox para la actividad en cada tarea: Si utilizamos este check veremos un detalle específico de cada una de las tareas seleccionadas en el selector:
			<ul>
				<li>.-Gráfico de Actividad de tarea.</li>
				<li>.-Estadísticas de la tarea.</li>
			</ul>
			<br>
			<p>
				<?php print_image("images/help/inf_pr_6.png", false, false); ?>
			</p>
			<br>	
		</li>
		<li>Un checkbox para Mostrar las Unidades de trabajo por cada tarea del proyecto: Si utilizamos este check veremos un detalle de las unidades de trabajo de las tareas seleccionadas en el selector.</li>
		<br>
		<p>
			<?php print_image("images/help/inf_pr_7.png", false, false); ?>
		</p>
		<br>
	</ul>
</p>