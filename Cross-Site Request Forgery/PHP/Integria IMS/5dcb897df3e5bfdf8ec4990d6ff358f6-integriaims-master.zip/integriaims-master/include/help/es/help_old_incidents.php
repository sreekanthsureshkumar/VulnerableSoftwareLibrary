<h1>D&iacute;as m&aacute;ximos de incidentes cerrados</h1>

<p>
Se borrar&aacute;n los incidentes con una fecha de cierre m&aacute;s antigua que los
d&iacute;as indicados. Tambi&eacute;n se borrar&aacute;n los datos relacionados.
Si el valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 0.
</p>
