<h1>Configuraciones de correo POP/IMAP:</h1>
<br>
<p><b><i>
	Importante: Intentar en la medida de lo posible no utilizar la cuenta de IMAP/POP de ningún usuario interno de Integria, ya que esto puede provocar algún comportamiento extraño a la hora de la creación y actualización de los tickets en Integria.
</p></b></i>
<h1>
	Gmail:	Sólo permite esta configuración:
</h1>
<br>
<p>
	SSL/TLS:
</p>
<br>
<ul>
	<li>
		<p>IMAP:</p>
		<span>
			<?php print_image("images/help/gmail4.png", false, false); ?>
		</span>
	</li>
	<li>				
		<p>POP:</p>
		<span>
			<?php print_image("images/help/gmail3.png", false, false); ?>
		</span>
	</li>
</ul>
<br>
<ul>
	<li>- Nombre: imap.gmail.com / pop.gmail.com</li>
    <li>- Puerto: 993(IMAP)/995(POP)</li>
    <li>- Selección Protocolo: POP/IMAP</li>
    <li>- Compatibilidad: Gmail.</li>
</ul>
<br>
<p>
	<b>Nota:</b> la opción de aceptar todos los certificados no es recomendable utilizarla ya que no validaría los certificados para el cifrado.
</p>
<br>
<p>
	Una vez configurado, elegimos un grupo de Integria en el cual queremos que se creen los tickets de los emails de esta cuenta y editamos el grupo:
</p>
<br>
<p>
	<b>Personas -> Control de acceso -> Gestión de grupos -> Editar el grupo que deseemos</b>
</p>
<br>
<span>
	<?php print_image("images/help/gmail5.png", false, false); ?>
</span>
<br><br>

<ul>
	Para que un usuario externo a integria pueda crear ticket a traves de un email:
	<br><br>
	<li>
		<b>- La auto-creación de usuarios:</b> Permite crear un nuevo usuario de integria. El cual coincidira con el nombre del correo electrónico. Esta opción debe de estar habilitada.
	</li>
	<li>
		<b>- Permisos de acceso al usuario para crear tickets:</b> Permite dar al usuario creado los permisos necesarios para la edición de tickets. Esta opción debe estar habilitado.
	</li>
	<li>
		<b>- Mensaje de bienvenida:</b> Permite enviar un mensaje de bienvenida al usuario creado. Esta opción es Opcional.
	</li>
	<li>
		<b>- Estado del ticket:</b> Permite elegir el estado del ticket creado. Nuevo es la opción por defecto;
	</li>
	<li>
		<b>- Tipo de usuario:</b> Permite elegir el tipo de usuario que será el usuario creado. Usuario externo es la opción por defecto;
	</li>
	<li>
		<b>- Compañia:</b> Permite seleccionar a que compañia pertenecerá el ticket creado. Está opción es opcional.
	</li>
	<li>
		<b>- Perfil determinado:</b> Permite seleccionar el perfil del usuario creado. External es la opción por defecto;
	</li>
	<li>
		<b>- Tipo de ticket:</b> Permite seleccionar el tipo de ticket al que pertenecerá el ticket creado. Está opción es opcional.
	</li>
	<li>
		<b>- Cola de email:</b> Muy importante debe coincidir con el nombre de la configuración POP/IMAP.
	</li>
</ul>
<br>
<p>
	<b>Configuración propia de Gmail:</b>
	<p>
		Hay que habilitar dentro de la cuenta de correo el protocolo a utilizar (POP/IMAP) y en el caso de utilizar POP permitir que elimine los correos para que la herramienta pueda trabajar de forma correcta.
	</p>
</p>

<h1>
	Outlook: Sólo permite esta configuración:
</h1>
<br>
<p>
	SSL/TLS:
</p>
<br>
<ul>
	<li>
		<p>IMAP:</p>
		<span>
			<?php print_image("images/help/outlook4.png", false, false); ?>
		</span>
	</li>
	<li>				
		<p>POP:</p>
		<span>
			<?php print_image("images/help/outlook3.png", false, false); ?>
		</span>
	</li>
</ul>
<br>
<ul>
	<li>- Nombre: imap-mail.outlook.com / pop-mail.outlook.com</li>
    <li>- Puerto: 993(IMAP)/995(POP)</li>
    <li>- Selección Protocolo: POP/IMAP</li>
    <li>- Compatibilidad: Outlook.</li>
</ul>
<br>
<p>
	<b>Nota:</b> la opción de aceptar todos los certificados no es recomendable utilizarla ya que no validaría los certificados para el cifrado.
</p>
<br>
<p>
	Una vez configurado, elegimos un grupo de Integria en el cual queremos que se creen los tickets de los emails de esta cuenta y editamos el grupo:
</p>
<br>
<p>
	<b>Personas -> Control de acceso -> Gestión de grupos -> Editar el grupo que deseemos</b>
</p>
<br>
<span>
	<?php print_image("images/help/outlook5.png", false, false); ?>
</span>
<br><br>

<ul>
	Para que un usuario externo a integria pueda crear ticket a traves de un email:
	<br><br>
	<li>
		<b>- La auto-creación de usuarios:</b> Permite crear un nuevo usuario de integria. El cual coincidira con el nombre del correo electrónico. Esta opción debe de estar habilitada.
	</li>
	<li>
		<b>- Permisos de acceso al usuario para crear tickets:</b> Permite dar al usuario creado los permisos necesarios para la edición de tickets. Esta opción debe estar habilitado.
	</li>
	<li>
		<b>- Mensaje de bienvenida:</b> Permite enviar un mensaje de bienvenida al usuario creado. Esta opción es Opcional.
	</li>
	<li>
		<b>- Estado del ticket:</b> Permite elegir el estado del ticket creado. Nuevo es la opción por defecto;
	</li>
	<li>
		<b>- Tipo de usuario:</b> Permite elegir el tipo de usuario que será el usuario creado. Usuario externo es la opción por defecto;
	</li>
	<li>
		<b>- Compañia:</b> Permite seleccionar a que compañia pertenecerá el ticket creado. Está opción es opcional.
	</li>
	<li>
		<b>- Perfil determinado:</b> Permite seleccionar el perfil del usuario creado. External es la opción por defecto;
	</li>
	<li>
		<b>- Tipo de ticket:</b> Permite seleccionar el tipo de ticket al que pertenecerá el ticket creado. Está opción es opcional.
	</li>
	<li>
		<b>- Cola de email:</b> Muy importante debe coincidir con el nombre de la configuración POP/IMAP.
	</li>
</ul>
<br>
<p>
	<b>Configuración propia de Outlook:</b>
	<p>
		<ul>
			<li>IMAP: Por defecto viene habilitada.</li>
			<li>POP: Hay que permitir la opción así como el check que permita eliminar los emails.</li>
		</ul>
	</p>
</p>

<h1>
	Office365: Sólo permite esta configuración:
</h1>
<br>
<p>
	SSL/TLS:
</p>
<br>
<ul>
	<li>
		<p>IMAP:</p>
		<span>
			<?php print_image("images/help/office365_4.png", false, false); ?>
		</span>
	</li>
	<li>				
		<p>POP:</p>
		<span>
			<?php print_image("images/help/office365_3.png", false, false); ?>
		</span>
	</li>
</ul>
<br>


<ul>
	<li>- Nombre: outlook.office365.com valido tanto para POP/IMAP</li>
    <li>- Puerto: 993(IMAP)/995(POP)</li>
    <li>- Selección Protocolo: POP/IMAP</li>
    <li>- Compatibilidad: Office365.</li>
</ul>
<br>
<p>
	<b>Nota:</b> la opción de aceptar todos los certificados no es recomendable utilizarla ya que no validaría los certificados para el cifrado.
</p>
<br>
<p>
	Una vez configurado, elegimos un grupo de Integria en el cual queremos que se creen los tickets de los emails de esta cuenta y editamos el grupo:
</p>
<br>
<p>
	<b>Personas -> Control de acceso -> Gestión de grupos -> Editar el grupo que deseemos</b>
</p>
<br>
<span>
	<?php print_image("images/help/office365_5.png", false, false); ?>
</span>
<br><br>

<ul>
	Para que un usuario externo a integria pueda crear ticket a traves de un email:
	<br><br>
	<li>
		<b>- La auto-creación de usuarios:</b> Permite crear un nuevo usuario de integria. El cual coincidira con el nombre del correo electrónico. Esta opción debe de estar habilitada.
	</li>
	<li>
		<b>- Permisos de acceso al usuario para crear tickets:</b> Permite dar al usuario creado los permisos necesarios para la edición de tickets. Esta opción debe estar habilitado.
	</li>
	<li>
		<b>- Mensaje de bienvenida:</b> Permite enviar un mensaje de bienvenida al usuario creado. Esta opción es Opcional.
	</li>
	<li>
		<b>- Estado del ticket:</b> Permite elegir el estado del ticket creado. Nuevo es la opción por defecto;
	</li>
	<li>
		<b>- Tipo de usuario:</b> Permite elegir el tipo de usuario que será el usuario creado. Usuario externo es la opción por defecto;
	</li>
	<li>
		<b>- Compañia:</b> Permite seleccionar a que compañia pertenecerá el ticket creado. Está opción es opcional.
	</li>
	<li>
		<b>- Perfil determinado:</b> Permite seleccionar el perfil del usuario creado. External es la opción por defecto;
	</li>
	<li>
		<b>- Tipo de ticket:</b> Permite seleccionar el tipo de ticket al que pertenecerá el ticket creado. Está opción es opcional.
	</li>
	<li>
		<b>- Cola de email:</b> Muy importante debe coincidir con el nombre de la configuración POP/IMAP.
	</li>
</ul>
<br>
<p>
	<b>Configuración propia de Office365:</b>
	<p>
		Hay que habilitar dentro de la cuenta de correo el protocolo a utilizar (POP/IMAP) y en el caso de utilizar POP permitir que elimine los correos para que la herramienta pueda trabajar de forma correcta.
	</p>
</p>

<h1>Otros:</h1>
<ul>
	<li>
		- Cifrado: Podemos configurar el servidor POP/IMAP sin cifrado o con SSL/TLS, SSLv2, SSLv3 o STARTTLS.
	</li>
	<li>- Nombre: IP o DNS del servidor POP/IMAP.</li>
	<li>- Puerto: Puerto en el que esté escuchando el servidor POP/IMAP.</li>
	<li>- Usuario: Usuario configurado en el servidor de correo.</li>
	<li>- Contraseña: Contraseña configurada para el usuario indicado anteriormente.</li>
	<li>- Protocolo: POP o IMAP</li>
	<li>- Compatibilidad: otros</li>
	<li>
		- Aceptar todos los certificados: Marcado si se desea aceptar cualquier certificado, incluso los autofirmados.
	</li>
</ul>