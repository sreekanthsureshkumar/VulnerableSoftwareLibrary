<h1>D&iacute;as m&aacute;ximos de datos de sesiones</h1>

<p>
Se borrar&aacute;n las sesiones m&aacute;s antiguas
que los d&iacute;as indicados.
Si el valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 7.
</p>
