<h1>Horas de trabajo por día</h1>

<p>
Este número representa el número de horas de un día de trabajo normal, generalmente son 8 horas.
</p>
