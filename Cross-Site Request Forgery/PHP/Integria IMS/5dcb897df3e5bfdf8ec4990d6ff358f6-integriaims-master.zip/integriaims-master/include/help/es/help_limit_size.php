<h1>Límite del tamaño máx. de los datos</h1>

<p>
Éste es el límite máximo par alos datos en Integria IMS. Se usa para los datos, tales como los ficheros adjuntados.
</p>
