<h1>Gráfica de tiempo</h1>
<p>
	Similar al proyecto de tiempo por hombre/proyecto, este gráfico representa la imputación de tiempos de cada usuario por tarea en este proyecto, de forma proporcional y en escala. Es interactivo y me permite, situando el ratón, obtener más información.
<p>
	<?php print_image("images/help/project13.png", false, false); ?>
</p>