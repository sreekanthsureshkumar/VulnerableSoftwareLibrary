<h1>Búsqueda de tickets personalizadas</h1>
<br>
<p>
Los filtros personalizados se pueden CARGAR y GUARDAR para poder reutilizarlos.<br><br>

<p>
<?php print_image("images/help/help_custom_search2.png", false); ?>
</p>

<br><br>

<p>
Para crear su filtro personalizado, primero haga una búsqueda/filtrado complejo utilizando los filtros de la vista detallada de tickets, ejecute la búsqueda y compruebe que muestra los resultados que espera. Luego, seleccione 'Añadir filtro personalizado', escriba un nombre para ese filtro y pulse 'Guardar filtro personalizado'.
</p>

<?php print_image("images/help/help_custom_search1.png", false); ?>

<br><br>

A partir de ahora, podrá cargar ese filtro, pulsando el botón 'Filtros personalizados' y escogiendo en el combo selector el filtro que ha guardado previamente. En el dashboard, también aparecerá ahora un enlace a su filtro personalizado.
