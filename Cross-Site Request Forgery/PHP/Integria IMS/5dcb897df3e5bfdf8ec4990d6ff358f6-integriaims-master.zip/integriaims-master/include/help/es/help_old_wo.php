<h1>D&iacute;as m&aacute;ximos de &oacute;rdenes de trabajo</h1>

<p>
Se borrar&aacute;n las &oacute;rdenes de trabajo con una fecha de
actualizaci&oacute;n m&aacute;s antigua que los d&iacute;as indicados.
Si el valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 0.
</p>
