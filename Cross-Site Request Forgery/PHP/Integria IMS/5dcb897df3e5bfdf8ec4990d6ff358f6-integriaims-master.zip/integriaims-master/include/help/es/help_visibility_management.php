<h1>Gestión de visibilidad</h1>
<br>

<?php print_image("images/help/help_visibility1.png", false); ?>
<br><br>
<p>
<ul>
	Esta opción sirve para “ocultar” ciertas partes de Integria de cara a grupos de usuario. Esta es una característica Enterprise. Se puede configurar, para cada sección y grupo de usuarios, los siguientes niveles de visibilidad:<br><br>
	<li>Oculto: No se mostrará para nadie de ese grupo.</li>
	<li>Completo: Los usuarios con permisos en el grupo indicado tendrán acceso completo a la sección.</li>
</ul>
</p>

<p>
<ul>
	Información adicional:<br><br>
	<li>Si una sección no tiene ninguna configuración de visibilidad, por defecto el acceso será Completo para todos los usuarios.</li>
	<li>Si el usuario es administrador siempre tendrá acceso completo independientemente de la configuración de visibilidad de menú.</li>
	<li>Si un usuario tiene perfiles en varios grupos que tienen distintos niveles de visibilidad en una sección, la visibilidad para ese usuario en esa sección será la menos restrictiva.</li>
	<li>Si se crea un nivel de visibilidad para una sección seleccionando todos los grupos (grupo 'Todos'), se eliminarán toda configuración para esa sección permaneciendo solamente la introducida.</li>
</ul>
</p>

