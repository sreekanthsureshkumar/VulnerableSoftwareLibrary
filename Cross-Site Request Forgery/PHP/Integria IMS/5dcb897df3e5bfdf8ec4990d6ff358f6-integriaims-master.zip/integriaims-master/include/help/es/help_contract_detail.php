<h1>Contratos</h1>
<p>
	Vinculados a una empresa, llevan datos relevantes, como cuantía económica y fecha de inicio y fin. Especialmente útil para poder buscar por contratos a punto de vencer o conocer otros detalles.
</p>
<p>
	<?php print_image("images/help/company6.png", false, false); ?>
</p>
<p>
	En la versión <b>Enterprise</b> existe control de acceso a los contratos de una empresa. Tienen acceso a ellos, el usuario asociado a la empresa y los usuarios que pertenecen a la empresa padre.
</p>