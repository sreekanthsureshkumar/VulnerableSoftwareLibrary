<h1>Los informes de personas:</h1>
<p>
	<ul>
		Para poder visualizar los informes de personas, se debe tener el siguiente perfil:
		<li>.-Administración de usuarios.</li>
		<li>.-Ver informes.</li>
	</ul>
</p>
<p>
	Aparecerá un formulario que nos permitirá seleccionar el usuario sobre el que se quiera realizar el informe. Así después de haber seleccionado un usuario o proyecto, aparecen tres check que permiten:
	<br>
	<p>
		<?php print_image("images/help/inf_pe_1.png", false, false); ?>
	</p>
	</br>
	<ul>
		<li>Realizar búsquedas de todos los proyectos, actividades y unidades de trabajo, pudiendo ver los campos que engloban, los tipos de tareas, gráficas, etc. </li>
		<li>Ver resumen del ticket: muestra un resumen de los tickets y los tickets afectados.</li>
		<li>Ver sólo un resumen de los tickets: muestra un resumen de los tickets.</li>
	</ul>
	<br>
	<p>
		<?php print_image("images/help/inf_pe_2.png", false, false); ?>
	</p>
	</br>
	<br>
	<p>
		<?php print_image("images/help/inf_pe_3.png", false, false); ?>
	</p>
</p>

<h1>General:</h1>
<p>
	Nos muestra información sobre unidades de trabajo. Se podrá filtrar por usuario y fecha. Tenemos la opción de visualizar el informe en pantalla, exportarlo a PDF o exportarlo a CSV.
</p>
<br>
<p>
	<?php print_image("images/help/filtro_general.png", false, false); ?>
</p>
<br>
<br>
<p>
	La información que muestra es la siguiente:
	<ul>
	<li>Usuario que ha imputado las horas</li>
	<li>Fecha</li>
	<li>Duración en horas</li>
	<li>Tipo. Pueden ser horas imputadas desde ticket o bien desde una tarea</li>
	<li>Proyecto</li>
	<li>Grupo</li>
	<li>Título</li>
	<li>Descripción</li>
	<li>Creador</li>
	<li>Prioridad</li>
	<li>Empresa</li>
	
	</ul>
</p>
<br>
<br>
<p>
	<?php print_image("images/help/inf_general.png", false, false); ?>	
</p>
