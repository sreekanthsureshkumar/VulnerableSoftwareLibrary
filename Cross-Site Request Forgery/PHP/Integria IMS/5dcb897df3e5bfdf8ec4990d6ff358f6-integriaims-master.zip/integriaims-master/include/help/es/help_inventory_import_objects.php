<h1>Importar datos de inventario desde CSV</h1>
<p>
	Existe la opción de importar datos de inventario desde un fichero CSV. Para ello, se carga el fichero con una cabecera y una línea por objeto de inventario.
</p>
<p>
	Nombre,Propietario,ID Padre,ID Tipo de objeto,Empresas,ID Fabricante,ID Contrato,Estado,Fecha recepción,Fecha,Descripción,Campo1 del tipo de objeto,…,CampoN del tipo de objeto
	La cabecera debe estar en la primera fila de nuestro CSV y debe contener al menos la columna name ya que el nombre del objeto de inventario debe existir.
</p>
</br>
<p>
	<b>Veamos las columnas que podremos añadir:</b>
	</br>
	<ul>
		<li>.- <b>name</b> (nombre) Como hemos dicho es indispensable que aparezca en nuestro CSV, ya que no se pueden crear objetos de inventario sin nombre, también se tendrá en cuenta la opción del setup que permite tener nombres de objetos de inventario duplicados.</li>

		<li>.- <b>owner</b> (Propietario) Esta columna recoge los ids de los usuarios que sean propietarios del objeto los cuales deben de existir en la bbdd, si no se introduce esta columna el valor introducido por defecto estará vacío.</li>

		<li>.- <b>id_parent</b> (Objeto padre) en esta columna irá el id del objeto de inventario padre, los cuales deben de existir en la bbdd. Por defecto es 0.</li>

		<li>.- <b>id_manufacturer</b> (empresa) en esta columna irá el id de las empresa a la que pertenece cada objeto de inventario, con lo cual estas empresas deben de existir en la bbdd. Por defecto es 0.</li>

		<li>.- <b>id_contract</b> (contrato) en esta columna irá el id del contrato al que pertenece cada objeto de inventario. Por defecto es 0.</li>

		<li>.- <b>status</b> (estado) en esta columna solo se pueden recoger los cuatro tipos de estado que existen y por lo tanto no aceptara ningún valor que sea diferente a (new, inuse, unused, issued).</li>

		<li>.- <b>receipt_date</b> (fecha de recepción) en esta columna irá la fecha de recepción y deberá tener un formato de fecha valido.</li>

		<li>.- <b>issue_date</b> (fecha de uso) en esta columna irá la fecha de uso y deberá tener un formato de fecha valido.</li>

		<li>.- <b>description</b> aquí irá la descripción del objeto de inventario. Por defecto estará vacío.</li>
		
		<li>.- <b>public</b> solo admitirá valor 0 o 1 dependiendo si quiere que sea publico o no. por defecto 1</li>
		<li>.- <b>id_company</b> (compañías asociadas) las compañías asociadas pueden ser una o varias, por lo tanto introduciremos los ids de la siguiente manera: [ id1 . id2 .id3 . id4 ] es importante el uso de puntos.</li>

		<li>.- <b>associated_user</b> (usuarios asociados) las usuarios asociados pueden ser uno o varios, por lo tanto introduciremos los ids de la siguiente manera: [ id1 . id2 .id3 . id4 ] es importante el uso de puntos como separador</li>

		<li>.- <b>id_object_type</b> (tipo de objeto) En esta columna irá el id de los tipos de objetos los cuales deben de existir en la bbdd. Por defecto 0.</li>
	</ul>
</p>
</br>
<p>
	El resto de columnas que se añadan corresponderán a los los campos personalizados de un tipo de objeto, en ellos podemos encontrar cuatro tipo de campos diferentes los cuales deberán respetar las limitaciones de dichos campos:
	</br>
	<ul>
		<li>.- <b>Campos de tipo texto</b> No tiene ninguna limitación.</li>

		<li>.- <b>Campos de tipo numérico</b> Solo permite números, por lo tanto la columna de este campo deberá contener solo números.</li>

		<li>.- <b>Campos de tipo combo</b> Permite una lista de palabras, por lo tanto los caracteres introducidos en esta columna solo podrán ser los que se recogen en dicha lista.</li>

		<li>.- <b>Campos de tipo externo</b> Estos campos permiten asociar tablas externas para introducir los valores se validará que exista dicha tabla y sus referencias.</li>
	</ul>
</p>
</br>
<p>
	<b>El orden de los campos:</b>
	<ul>
		<li>nombre, creador, id_padre, id del tipo del objeto, empresas, id empresa, id contrato, estado, fecha de recepción, fecha de borrado, descripción.</br></br>
			<b><i>Ejemplo:</i></b></br>
			<pre>
				NuevoInventario,admin,25,,20::30,2,3,new,2016/10/09,,,

						nombre       = NuevoInventario
						creador      = Admin
						idpadre      = 25
						id tipo objt = Lo dejamos vacío.
						empresas     = 20::30
						id empresa   = 2
						id contrato  = 3
						estado       = new
						fecha recepc = 2016/10/09
						fecha borrad = Vacío.
						descripción  = Lo dejamos vacío.
			</pre>
			<br>
			<p>
				Como vemos en el ejemplo se rellenarían todos los datos necesarios para un objeto dejando vacío aquellos no necesarios los campos obligatorios son nombre, estado y fecha de recepción.
			</p>
		</li>
	</ul>
	</br>
	<ul>
		<b>Si queremos introducir los campos personalizados debemos tener en cuenta:</b>
		<li>.- Si introducimos un id de un tipo de objeto debe existir en la bbdd.</li>
		<li>.- Y tenemos que introducir tantos campos como tenga el tipo de objeto.</li>
		</br>
		<b><i>Ejemplo:</i></b></br>
		<pre>
			NuevoInventario,admin,,1,20::30,,,new,2016/10/09,,Descripción del objeto de inventario,1,pr1,pr2,pr3,pr4,pr5,pr6,pr7,1000,pr8,pr9,,
					nombre       = NuevoInventario
					creador      = Admin
					idpadre      = No tiene padre por lo cual lo dejamos vacio
					id tipo objt = 1
					empresas     = 20::30
					id empresa   = No tiene empresa asociada lo dejamos vacio
					id contrato  = No tiene contrato asociado lo dejamos vacio
					estado       = new
					fecha recepc = 2016/10/09
					fecha borrad = Vacio
					descripcion  = Descripción del objeto de inventario

			El resto de campos que aparecen pertenecen a todos los campos personalizados que tiene el tipo de objeto
		</pre>
	</ul>

	Todos los campos personalizados también deberán cumplir si son únicos o no. Esto depende de si he seleccionado la creación de los campos personalizados, con lo cual esto provocara no poder introducir valores que ya existan en estos campos personalizados.

</p>
</br>
<p>
	Veamos un ejemplo para entenderlo mejor:
</p>
</br>
<p>
	<?php print_image("images/help/import_csv.png", false, false); ?>
</p>
</br></br>
<p>
	Como vemos en la imagen aparecen las columnas ordenadas pero no es necesario mantener un orden especifico, en este csv introduciremos dos objetos, (test y test2) en los cuales introducimos todas las columnas fijas hasta public, solo es necesario introducir el nombre, el resto depende de si se desea rellenar o no. En el caso de que no aparezcan columnas se meterá el valor por defecto, solo en el caso de querer introducir también los campos personalizados de un tipo de objeto si que será necesario introducir la columna id_object_type para saber a que tipo de objeto pertenecen estos campos personalizados.
</p>
</br>
<p>
	En la imagen, las columna (Field text) son campos personalizados, estos campos pertenecen al id de objeto 18 pero no es necesario introducir todas las columnas de los campos, es decir que si mi tipo de objeto tiene 8 campos personalizados y solo quiero tener en cuenta dos de ellos, solo pondrás las columnas de esos dos. En el caso de que sea necesario que se llamen exactamente igual que el nombre que tiene el campo porque mi campo personalizado tiene ese nombre, por ejemplo nuestra imagen se llama Field text porque mi campo personalizado tiene ese nombre, si pusiese “Fieldtext1” al no llamarse exactamente como mi campo personalizado provocaría un error.
</p>




