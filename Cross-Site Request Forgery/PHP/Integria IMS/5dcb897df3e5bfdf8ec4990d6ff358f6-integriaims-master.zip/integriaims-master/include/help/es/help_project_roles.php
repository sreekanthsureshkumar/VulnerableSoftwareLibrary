<h1>Roles de proyecto y tarea</h1>

<p>
El perfil de gestor de proyecto permite el acceso a todas las
opciones del proyecto, aunque el usuario no sea el propietario.
Por razones de seguridad, el rol de gestor de proyecto s&oacute;lo
esta habilitado para el administrador en esta secci&oacute;n.<br><br>
Asignar un usuario a una tarea le dar&aacute; permisos de acceso al
proyecyo de la tarea con el rol seleccionado si a&uacute;n no tiene
acceso.<br>
</p>
