<h1>Los informes personalizados:</h1>
<p>
	<ul>
		Para poder visualizar los informes de personas deben de tener el siguiente perfil:
		<li>.-Administración de usuarios.</li>
		<li>.-Ver informes.</li>
	</ul>
</p>
<p>
	Estos informes permiten crear informes a través de una sentencia de mysql como en el ejemplo:
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_1.png", false, false); ?>
</p>
</br>
<p>
	Se puede visualizar de tres formas diferentes por html, pdf o csv.
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_2.png", false, false); ?>
</p>
</br>
<p>
	Un ejemplo de vista html:
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_3.png", false, false); ?>
</p>
</br>

<p>
	Permite crear informes programados que se enviaran por email (Sólo enterprise).
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_4.png", false, false); ?>
</p>
</br>