<h1>Importación de usuarios por CSV</h2>

<p>
    Un archivo CSV almacena datos tabulares (n&uacute;meros y texto) en formato de texto plano. Las columnas est&aacute;n separadas por comas:
</p>

</br>

<p>
    <strong>
        &emsp;id_usuario
    </strong>
</p>

</br>
<p>
    <strong>
        &emsp;password
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;real_name
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;email
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;telephone
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;description
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;avatar
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;disabled
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;id_company
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;num_employee
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;enable_login
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Campos personalizados:
    </strong> 
            deberán existir previamente en su sistema Integria IMS y deberán indicarse en orden, 
</p>
<p>
            &emsp;pudiendo elegir un valor, o en caso de no querer darles valor, espacio en blanco
</p>

<h2>Example</h2>

<p>
    "user,pass_user,alberto,alberto@gmail.com,012345678,new user,people_1,0,3,222,1,Integria,20”
</p>

