<h1>Horas de trabajo</h1>
<p>
	El detalle de las imputaciones de horas totales (y por tarea) de cada miembro muestra la acción de cada usuario, en la fecha que se hizo, la descripción, la tarea o subtarea y una serie de atributos que se muestran como iconos.
	</br>
	</br>
	El jefe de proyecto puede “certificar” (icono Bloquear) una WU, de forma que el usuario no la pueda modificar o borrar. La persona que reportó esa unidad de trabajo puede ver esa unidad de trabajo, modificarla (si no está certificada) y borrarla.
</p>
<p>
	<?php print_image("images/help/project16.png", false, false); ?>
</p>