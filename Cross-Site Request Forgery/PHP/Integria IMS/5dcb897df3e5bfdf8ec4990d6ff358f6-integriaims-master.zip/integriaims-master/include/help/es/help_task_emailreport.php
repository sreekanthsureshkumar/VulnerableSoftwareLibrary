<h1>Informe de tarea</h1>
<p>
	Integria IMS tiene una opción para enviar un informe automático sobre la tarea y su estado actual a todos los miembros de la tarea. Seleccione Proyecto → Tarea → Informe por email para acceder a esta herramienta.
	</br>
	</br>
	El informe de tarea generará automáticamente un texto que puede modificar o personalizar. Al darle al botón de enviar, generará un email automáticamente y lo enviará a cada uno de los participantes de la tarea.
</p>
<p>
	<?php print_image("images/help/project21.png", false, false); ?>
</p>