<h1>Autocompletado de UT (días)</h1>

<p>
	<br><br>
Número de días que se tendrán en cuenta, hacia atrás, para la asignación de horas de forma automática. Se chequeará que se hayan introducido un número mínimo de horas diarias a través de las unidades de trabajo. Éste número mínimo de horas diarias son las correspondientes al campo 'Horas de trabajo por día'. Esto será así para todos los usuarios que no estén incluidos en el campo 'Usuarios sin completado de UT'. <br><br>
</p>
<p>
Ejemplo:<br><br>

Horas de trabajo diarias: 8 <br>
Autocompletado de UT (días): 15 <br>
Usuarios sin completado de UT: vacío <br><br>

En éste caso, se comprobará que todos los usuarios han introducido 8 horas diarias a través de las unidades de trabajo durante los últimos 15 días. Si, por ejemplo, hay un usuario que un día ha introducido 4 horas en lugar de las 8 mínimas, se le asignarán las 4 horas restantes a la tarea 'Sin justificar'.

</p>
