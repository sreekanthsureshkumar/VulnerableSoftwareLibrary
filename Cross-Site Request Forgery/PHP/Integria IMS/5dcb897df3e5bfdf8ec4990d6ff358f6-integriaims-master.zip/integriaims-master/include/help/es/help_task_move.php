<h1>Mover tarea</h1>
<p>
	Es posible mover la tarea de un proyecto a otro. Para ello, navegue por el árbol de proyectos, localice el proyecto, y la tarea que quiere mover. Una vez ahí, elija la opción de mover tarea y seleccione el proyecto de destino. Si lo que desea es cambiar el padre de la tarea, edite las propiedades de la misma y cambie el padre. Las Unidades de Trabajo (WU) de la tarea van vinculadas a la tarea, así que si ésta se mueve de proyecto o de tarea padre, no importa ya que las WU van asociadas siempre a la tarea, no al proyecto.
</p>
<p>
	<?php print_image("images/help/project20.png", false, false); ?>
</p>