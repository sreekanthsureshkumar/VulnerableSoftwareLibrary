<h1>Gestión de la cola de correo</h1>
<p>
	<br>Son utilizadas para la creación y gestión de tickets por email. Para poder utilizar esta funcionalidad es necesario tener configurado una cuenta de correo en el apartado “Configuración de correo”, en el setup general de la consola. Integria utilizará esta cuenta saliente para la gestión de tickets por email.

	Los parámetros para configurar las colas de correo son los siguientes:

	<li>Autocrear usuarios: creación automática de nuevos usuarios cuando se recibe un mail.</li>
	<li>Dar acceso a usuarios: acceso de los nuevos usuarios creados automáticamente a la aplicación usando su usuario/contraseña.</li>
	<li>Enviar email de bienvenida: utilizará la plantilla especificada en el campo inferior.</li>
	<li>Estado por defecto: estado con el que se creará el ticket.</li>
	<li>Tipo usuario: tipo con el que se crearán los usuarios automáticamente.</li>
	<li>Compañía por defecto.</li>
	<li>Perfil de usuario por defecto: se asociará el perfil indicado al nuevo usuario para el grupo correspondiente.</li>
	<li>Tipo de ticket por defecto.</li>
	<li>Cola de correo: los emails que lleguen a las direcciones de correo que se espefiquen en éste apartado serán utilizados para la creación y actualización de tickets. Integria utiliza la cuenta configurada en el setup de correo, por lo que las direcciones que pongamos aquí deben ser esa misma dirección o bien alias que definamos en el propio servidor de correo. Este campo permite configurar varias direcciones o expresiones regulares una en cada línea. Por ejemplo:<br><br>
		support@integria.com <br>
		.*@otherdomain.com <br><br></li>
		
		Con esta configuración, todos los correos que lleguen a la dirección support@integria.com y todos aquellos que con el formato xxxx@otherdomain.com como por ejemplo: user1@otherdomain.com, superadmin@otherdomain.com, etc. serán utilizados para la gestión de tickets por email utilizando los parámetros definidos.

	<li>Email de bienvenida: se enviará a los nuevos usuarios que sean automáticamente creados al enviar un mail. Este campo de texto acepta las siguientes macros:
	_password_: cambiará esta macro por el password por defecto asignado en la creación del usuario.</li><br>
</p>

<h1>Gestión de tickets por email</h1>
<p>
	<br>Integria permite la creación y actualización de tickets mediante el envío de emails.<br><br>
	Dependiendo del cliente de correo electrónico usado, el formato de los emails podría ser diferente. La gestión de emails de Integria ha sido validada con los siguientes gestores de correo: Evolution, Gmail, Outlook y Mail.<br>
	La creación de tickets y workunits por email sigue los mismos principios de ACLs que el interfaz gráfico. <br>
	Internamente la gestión de tickets por email funciona de la siguiente manera:

	Supongamos que tenemos habilitada la siguiente dirección de correo para recibir los email: support@integria.com y configurado el parámetro 'Cola de emails de un grupo con el correo support@integria.com. Además enviaremos un email con los siguientes datos:<br>

<li>From: user@company.com</li>
<li>To: support@integria.com, myboss@company.com</li>
<li>CC: admin1@company.com, admin2@company.com</li>
<li>Subject: Another problem with the servers</li>
<li>Body: We are having a big problem with our servers!</li>
<li>Attachment: screen1.png, screen2.png</li><br>

<li>Una vez el email está en el inbox de la dirección support@integriaims.com se comprobará si corresponde con alguna cola de correo configurada.
<ul><li>Si no encuentra ninguna cola de correo el email se desecha.
<li>Si encuentra una cola de correo entonces se usaran los parámetros por defecto configurados en esa cola de correo para gestionar el ticket.</li></ul>
<li>Ahora la aplicación procesará el email, en este punto pueden suceder dos cosas:
<ul><li>El email no se corresponde con ningún ticket actual. En este caso se creará un nuevo ticket.
<li>El email se corresponde con un ticket creado en el sistema. En este caso se creará una nueva workunit y se actualizarán los datos del ticket.</ul></li><br>
La siguiente imagen explica el flujo de gestión de colas de emails de una forma resumida:
	<br>
</p>
<p>
	<?php print_image("images/help/gestionticketsemail.png", false, false); ?>
</p>
