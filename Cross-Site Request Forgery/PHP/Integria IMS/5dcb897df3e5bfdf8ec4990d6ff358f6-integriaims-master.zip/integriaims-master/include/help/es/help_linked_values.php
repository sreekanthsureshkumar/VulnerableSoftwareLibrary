<h1>Ejemplo: SEDE,DEPARTAMENTO,DIVISION</h1>
</br>
<ul>
	<li>.- Primero se crea el campo SEDE. En este caso, no se selecciona un campo padre porque es el primero en la jerarquía. Los valores irán separados por coma.</li>
	<br>
	<?php print_image("images/help/tk_11.png", false, false); ?>
	</br>
	<li>.- Después se creará el campo DEPARTAMENTO. En este caso, se selecciona el campo padre SEDE. Después se rellenará el campo con los valores separados por coma como en el caso anterior. Como este campo sí tiene un padre, habrá que asociar los valores. Para ello, se pondrá delante el valor del campo padre separado de |. De esta manera indicaremos que el nuevo campo pertenece al campo padre que precede (un departamento pertenece a una sede).</li>
	<br>
	<?php print_image("images/help/tk_11_1.png", false, false); ?>
	</br>
	<li>.- El siguiente campo que se va a crear es DIVISIÓN. Se selecciona el padre DEPARTAMENTO y se ponen los valores. Del mismo modo, la relación que se establece indica que una división pertenece a un departamento.</li>
	<br>
	<?php print_image("images/help/tk_112.png", false, false); ?>
	</br>
</ul>
