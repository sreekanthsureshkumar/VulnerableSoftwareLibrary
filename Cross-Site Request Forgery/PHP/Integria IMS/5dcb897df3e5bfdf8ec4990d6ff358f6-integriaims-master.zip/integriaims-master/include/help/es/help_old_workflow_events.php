<h1>D&iacute;as m&aacute;ximos de datos de eventos de reglas de flujo de trabajo</h1>

<p>
Se borrar&aacute;n los eventos de flujo de trabajo antiguos a partir de los d&iacute;as indicados. Si el
valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 900.
</p>
