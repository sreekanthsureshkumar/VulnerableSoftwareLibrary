<h1>Seguimiento de tareas</h1>
<p>
	Integria IMS realiza un seguimiento (tracking) de prácticamente todas aquellas secciones o elementos de información que son susceptibles a cambios. En el caso de la tarea registra todas las operaciones de apertura, cierre, cambio y adición de información; ya sea en forma de Workunit o en forma de fichero adjunto.
</p>
<p>
	<?php print_image("images/help/project22.png", false, false); ?>
</p>