<h1>D&iacute;as m&aacute;ximos de archivos de la secci&oacute;n de compartir archivos</h1>

<p>
Se borrar&aacute;n los archivos subidos que sean m&aacute;s antiguos que los d&iacute;as indicados.
Si el valor indicado es 0, los archivos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 7.
</p>