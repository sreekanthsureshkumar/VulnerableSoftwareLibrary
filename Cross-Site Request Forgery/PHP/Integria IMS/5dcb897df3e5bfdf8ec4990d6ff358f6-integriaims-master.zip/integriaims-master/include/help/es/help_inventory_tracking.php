<h1>Inventario Tracking</h1>
<p>
	La solapa <b>tracking</b> muestra los cambios que se producen en el objeto de inventario como el cambio de propietario, si se asocia un tipo de objeto, un objeto padre.
</p>
<p>
	<?php print_image("images/help/inventory11.png", false, false); ?>
</p>