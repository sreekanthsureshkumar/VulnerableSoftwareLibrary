<h1>Importación de empresas</h2>

<p>
	La importación podrá ser hecha por medio de una exportación realizada en integria (en la cuál no se deberá manipular la estructura tal y como se genera en el sistema) y podrá hacerse por medio de un archivo de tipo CSV creado a mano.
</p>

</br>

<p>
    Para el primer caso el fichero de entrada será el mismo que previamente exportamos, con lo que no impone problemas a la hora procesar el CSV.
</p>

</br>

<p>
    Para el segundo caso se deberán meter una serie de parámetros por orden, unos obligatorios y otros no, pudiendo escoger valores vacíos para estos últimos. Los campos serán los siguientes siguiendo el orden lógico establecido por la herramienta:
</p>

</br>

<p>
    <strong>
        &emsp;Nombre
    </strong>
</p>

</br>
<p>
    <strong>
        &emsp;Dirección
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id fiscal
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;País
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Sitio web
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Comentarios
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del rol de la compañía
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id del padre
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Manager de la empresa
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Última actualización
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Condiciones de pago
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Campos personalizados:
    </strong> 
            deberán existir previamente en su sistema Integria IMS y deberán indicarse en orden, 
</p>
<p>
            &emsp;pudiendo elegir un valor, o en caso de no querer darles valor, espacio en blanco
</p>

<h2>Ejemplo</h2>

<p>
    "Empresa prueba,,,España,,,,,admin,0000-00-00 00:00:00,,Integria,20”
</p>

</br>