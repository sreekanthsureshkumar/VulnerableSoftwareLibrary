<p>
	<h1>Campos personalizados</h1>
</p>
</br>
<p>
	<b>En la creación de campos se puede definir:</b>
</p>
</br>
<p>
		<ul>
		<li>- Nombre: es obligatorio y puede no ser único.</li>
		<li>- Mostrar en la lista de ticket: al marcar esta opción, aparecerá como columna en el listado de tickets.</li>
		<li>- Campo global: al marcar esta opción, aparecerá en el formulario de búsqueda de tickets dentro de las opciones avanzadas.</li>
		<ul>
			<li>- Tipo texto: Se mostrará en el formulario de creación/edición de tickets un campo de tipo input.</li>
			<br>
			<?php print_image("images/help/tk_8.png", false, false); ?>
			</br>
			<li>- Textarea: Se mostrará en el formulario de creación/edición de tickets un campo de tipo textarea.</li>
			<br>
			<?php print_image("images/help/tk_9.png", false, false); ?>
			</br>
			<li>- Combo: Se mostrará en el formulario de creación/edición de tickets un campo de tipo select con todas las opciones disponibles.</li>
			<br>
			<?php print_image("images/help/tk_10.png", false, false); ?>
			</br>
			<li>- Enlazado: Son campos personalizados relacionados entre sí. Los vamos a explicar con un ejemplo:</li>
			<ul>
				<li>.- Primero se crea el campo SEDE. En este caso, no se selecciona un campo padre porque es el primero en la jerarquía. Los valores irán separados por coma.</li>
				<br>
				<?php print_image("images/help/tk_11.png", false, false); ?>
				</br>
				<li>.- Después se creará el campo DEPARTAMENTO. En este caso, se selecciona el campo padre SEDE. Después se rellenará el campo con los valores separados por coma como en el caso anterior. Como este campo sí tiene un padre, habrá que asociar los valores. Para ello, se pondrá delante el valor del campo padre separado de |. De esta manera indicaremos que el nuevo campo pertenece al campo padre que precede (un departamento pertenece a una sede).</li>
				<br>
				<?php print_image("images/help/tk_11_1.png", false, false); ?>
				</br>
				<li>.- El siguiente campo que se va a crear es DIVISIÓN. Se selecciona el padre DEPARTAMENTO y se ponen los valores. Del mismo modo, la relación que se establece indica que una división pertenece a un departamento.</li>
				<br>
				<?php print_image("images/help/tk_112.png", false, false); ?>
				</br>
			</ul>
			<li>-Numérico: Se mostrará en el formulario de creación/edición de tickets un campo de tipo numérico.</li>
			<br>
			<?php print_image("images/help/tk_12.png", false, false); ?>
			</br>
			<li>-Fecha: Se mostrará en el formulario de creación/edición de tickets un campo de tipo fecha.</li>
			<br>
			<?php print_image("images/help/tk_13.png", false, false); ?>
			</br>
		</ul>
	</ul>
</p>
<br>
<p>
	A continuación se muestra el listado con todos los campos que se han creado.
</p>
<br>
	<?php print_image("images/help/tk_14.png", false, false); ?>
</br>
<p>
	<b>Las columnas que componen este listado son:</b>
</p>
<p>
	<ul>
		<li>Nombre del campo.</li>
		<li>Tipo del campo.</li>
		<li>Padre: Es exclusivo de los tipo enlazados ya que estos pueden hacer referencia a un padre.</li>
		<li>Valor: Es exclusivo de los tipo combo y enlazados ya que estos tienen un valor por defecto para seleccionar.</li>
		<li>Acciones: Permiten la edición o borrado del campo.</li>
		<li>Ordenar: permite asignar el orden en que serán mostrados.</li>
	</ul>
</p>
<p>
	Ejemplo de ordenación: Se quiere que los campos TIPO, MARCA, MODELO, MOTOR se vean los primeros, habría que seleccionar los cuatro campos en la lista y en el menú de ordenación seleccionamos la opción “antes de” y la posición que en este caso seria el primero.
</p>
<br>
	<?php print_image("images/help/tk_15.png", false, false); ?>
</br>
<p>
	Como se puede ver, ahora aparecen los campos enlazados al comienzo de la lista.
</p>
</br>
	<?php print_image("images/help/tk_16.png", false, false); ?>
</br>