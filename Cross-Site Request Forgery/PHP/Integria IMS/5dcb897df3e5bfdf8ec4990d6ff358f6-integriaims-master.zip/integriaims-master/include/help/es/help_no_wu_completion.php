<h1>Usuarios sin completado de UT</h1>

<p>
Esta es una lista de usuarios que no tienen autocompletado de horas de trabajo. Cada usuario debe estar separado del siguiente por un espacio en blanco &laquo; &raquo;.
</p>
