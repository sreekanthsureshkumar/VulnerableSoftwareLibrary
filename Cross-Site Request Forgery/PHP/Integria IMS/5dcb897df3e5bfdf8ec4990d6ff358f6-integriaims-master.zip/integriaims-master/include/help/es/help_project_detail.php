<h1>Vista general del proyecto</h1>
<p>
	Es la vista principal de un proyecto. Desde aquí podemos editar algunos detalles generales de proyecto y ver un informe global sobre el estado del proyecto.
</p>
<p>
	<?php print_image("images/help/project11.png", false, false); ?>
</p>