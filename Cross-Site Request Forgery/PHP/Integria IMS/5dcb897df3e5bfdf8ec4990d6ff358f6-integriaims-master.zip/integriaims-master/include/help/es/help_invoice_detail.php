<h1>Facturas</h1>
<p>
	<br>En esta sección se muestran las facturas del sistema. Sólo de las empresas a las que el usuario tiene acceso. Podrá realizar búsquedas, exportar esos resultados a excel, PDF o mostrar informes con los datos de la búsqueda desde estos iconos:<br><br>
</p>

<p>
	<?php print_image("images/help/help_invoice1.png", false, false); ?>
</p>
<p>
	<br>El usuario solo tendrá acceso a esta sección si tiene permisos de “Ver CRM” y las empresas están vinculadas a su nombre. También podrá verlas si tiene ese permiso y las empresas están asociadas a su compañía base (la compañía asociada al perfil de ese usuario).<br>
</p>
<p>
	<br>Para poder modificar las empresas visualizadas, deberá tener tener permisos de edición de CRM y ser propietario de esa empresa o que estén asociadas a su empresa base.	<br>
</p>
<p>
	<br>Si un usuario no ve una empresa en esta lista, revise de nuevo la asignación de permisos y perfiles de ese usuario y la ficha de la empresa, para verificar a qué usuario está asignada y/o a que empresa base está:<br>
</p>

<p>
	<?php print_image("images/help/help_invoice2.png", false, false); ?>
</p>
<br>
<h2>Bloqueo, borrado e impresión de facturas</h2>
<br>
<p>
	Desde el listado, y detrás de cada factura, podrá ver tres opciones con los siguientes iconos para imprimir en PDF, bloquear la factura o borrarla:<br>
</p>
<p>
	<?php print_image("images/help/help_invoice3.png", false, false); ?>
</p>
<p>
	<br>ATENCIÓN: Si borra una factura emitida dejará un “Número vacío” en la secuencia, que puede tener consecuencias contables, según su legislación. Si desactiva o mete una excepción, podrá luego crear una factura con el número de factura que va a borrar, pero tenga especial cuidado con esta opción.<br>
</p>
<p>
	Para personalizar el aspecto de la factura, utilice las opciones de configuración de la sección del CRM.<br>
</p>
