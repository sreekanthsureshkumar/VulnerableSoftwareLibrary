<h1>Dashboard (Vista principal)</h1>
<br>
<p>
	El dashboard es una vista que permite ver de un simple vistazo los tickets agrupados de diferentes maneras y tener acceso directo a las búsquedas personalizadas que hemos creado. Es la pantalla por defecto cuando se hace click en Tickets, en el menú principal.<br>

	Toda la información que se muestra aquí es a modo de “resumen” y al hacer click sobre ellas, nos llevará a la vista detallada de tickets, con la selección o búsqueda determinada por el tipo de agrupación que escoja: por ejemplo, tickets de un dueño específico, de un grupo concreto o un creador puntual:<br><br>
</p>

<?php print_image("images/help/help_dashboard1.png", false, false); ?>
<br><br>
<p>
<strong>Búsquedas personalizadas</strong><br>

En la parte superior muestra una caja (que en su caso, si no lo ha configurado todavía, estaría vacío). Aquí se colocan las búsquedas personalizadas que se configuran en la vista detallada de tickets y que sirven como “enlace rápido” a dichas búsquedas.
</p>

<?php print_image("images/help/help_dashboard2.png", false, false); ?>
