<h1>Los informes de grupos:</h1>
<p>
	<ul>
		Para poder visualizar los informes de grupos se debe tener el siguiente perfil:
		<li>.-Ver proyectos o (rol project manager).</li>
		<li>.-Ver informes</li>
	</ul>
</p>
<p>
	Para crear el informe de una manera fácil aparecerá un selector para elegir los grupos
</p>
<br>
<p>
	<?php print_image("images/help/group_report1.png", false, false); ?>
</p>
<br>
<p>
	Una vez esté seleccionado el grupo, se podrá visualizar un lista de las workunits asociadas a este grupo.
</p>
<br>
<p>
	También se dispone de un selector de fechas para filtrar estas workunit.
</p>
<br>
<p>
	<?php print_image("images/help/group_report2.png", false, false); ?>
</p>