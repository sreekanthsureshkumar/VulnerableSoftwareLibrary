<h1>Tipos de ticket</h1>
</br>
<p>
	Los tipos de tickets nos permiten crear tickets con campos personalizados para diferentes grupos, además de poder añadirle partes de trabajo específicos.
</p>
</br>
<p>
	<b>Para crear un tipo de ticket tenemos dos opciones:</b>
	<ul>
		<li>- El botón que aparece debajo de la lista de tipos de tickets.</li>
		<?php print_image("images/help/tk_2.png", false, false); ?>
		<br>
		<li>- La opcion crear tipo de ticket del menú lateral.</li>
		<br>
		<?php print_image("images/help/tk_2_2.png", false, false); ?>
	</ul>
</p>
</br>
<p>
	<b>Campos que se pueden definir en la creación/edición de un tipo de ticket:</b>
	<ul>
		<li><b>- Nombre:</b> es obligatorio y debe ser único, es decir, no puede coincidir con el nombre de otro tipo existente. Este campo es el que se mostrará en el formulario de creación/edición de tickets para poder seleccionar el tipo.</li>
		<li><b>- Descripción:</b> es opcional.</li>
		<li><b>- Plantilla de partes de trabajo:</b> es opcional y nos permite añadir una plantilla de parte de trabajo.</li>
		<li><b>- Grupos:</b> es opcional y nos permite relacionar el tipo a uno o varios grupos. Si lo dejamos vacío, se podrá asignar este tipo de ticket a cualquier grupo.</li>
	</ul>
</p>
</br>
<p>
	<?php print_image("images/help/tk_3.png", false, false); ?>
</p>
</br>
<p>
	Las acciones que se pueden aplicar a un tipo son:
	<ul>
		<li>- Añadir campos personalizados.</li>
		<li>- Actualizar los datos (nombre, descripción, plantilla, grupos).</li>
		<li>- Borrado.</li>
	</ul>
	A continuación vemos un ejemplo
</p>
<p>
	<?php print_image("images/help/tk_4.png", false, false); ?>
</p>
</br>
<p>
	Para actualizar, se hace click en el icono llave inglesa que nos llevará a la vista de edición. Una vez aquí, podremos modificar cualquier apartado.
</p>
</br>
<p>
	<?php print_image("images/help/tk_5.png", false, false); ?>
</p>
</br>
<p>
	Para borrar, se hace click en el icono papelera. Esta acción nos pedirá confirmación. Una vez aceptado, el borrado será definitivo y no se podrá deshacer esta acción.
</p>
</br>
<p>
	<?php print_image("images/help/tk_6.png", false, false); ?>
</p>
</br>
<p>
	Para añadir campos personalizados, se hace click en el icono suma.
</p>
</br>
<p>
	<?php print_image("images/help/tk_7.png", false, false); ?>
</p>
</br>
<p>
	<h1>Campos personalizados</h1>
</p>
</br>
<p>
	<b>En la creación de campos se puede definir:</b>
</p>
</br>
<p>
	<ul>
		<li>- Nombre: es obligatorio y puede no ser único.</li>
		<li>- Mostrar en la lista de ticket: al marcar esta opción, aparecerá como columna en el listado de tickets.</li>
		<li>- Campo global: al marcar esta opción, aparecerá en el formulario de búsqueda de tickets dentro de las opciones avanzadas.</li>
		<ul>
			<li>- Tipo texto: Se mostrará en el formulario de creación/edición de tickets un campo de tipo input.</li>
			<br>
			<?php print_image("images/help/tk_8.png", false, false); ?>
			</br>
			<li>- Textarea: Se mostrará en el formulario de creación/edición de tickets un campo de tipo textarea.</li>
			<br>
			<?php print_image("images/help/tk_9.png", false, false); ?>
			</br>
			<li>- Combo: Se mostrará en el formulario de creación/edición de tickets un campo de tipo select con todas las opciones disponibles.</li>
			<br>
			<?php print_image("images/help/tk_10.png", false, false); ?>
			</br>
			<li>- Enlazado: Son campos personalizados relacionados entre sí. Los vamos a explicar con un ejemplo:</li>
			<ul>
				<li>SEDE,DEPARTAMENTO,DIVISION</li>
					<li>.- Primero se crea el campo SEDE. En este caso, no se selecciona un campo padre porque es el primero en la jerarquía. Los valores irán separados por coma.</li>
					<br>
					<?php print_image("images/help/tk_11.png", false, false); ?>
					</br>
					<li>.- Después se creará el campo DEPARTAMENTO. En este caso, se selecciona el campo padre SEDE. Después se rellenará el campo con los valores separados por coma como en el caso anterior. Como este campo sí tiene un padre, habrá que asociar los valores. Para ello, se pondrá delante el valor del campo padre separado de |. De esta manera indicaremos que el nuevo campo pertenece al campo padre que precede (un departamento pertenece a una sede).</li>
					<br>
					<?php print_image("images/help/tk_11_1.png", false, false); ?>
					</br>
					<li>.- El siguiente campo que se va a crear es DIVISIÓN. Se selecciona el padre DEPARTAMENTO y se ponen los valores. Del mismo modo, la relación que se establece indica que una división pertenece a un departamento.</li>
					<br>
					<?php print_image("images/help/tk_112.png", false, false); ?>
					</br>
			</ul>
			<li>-Numérico: Se mostrará en el formulario de creación/edición de tickets un campo de tipo numérico.</li>
			<br>
			<?php print_image("images/help/tk_12.png", false, false); ?>
			</br>
			<li>-Fecha: Se mostrará en el formulario de creación/edición de tickets un campo de tipo fecha.</li>
			<br>
			<?php print_image("images/help/tk_13.png", false, false); ?>
			</br>
		</ul>
	</ul>
</p>
<br>
<p>
	A continuación se muestra el listado con todos los campos que se han creado.
</p>
<br>
	<?php print_image("images/help/tk_14.png", false, false); ?>
</br>
<p>
	<b>Las columnas que componen este listado son:</b>
</p>
<p>
	<ul>
		<li>Nombre del campo.</li>
		<li>Tipo del campo.</li>
		<li>Padre: Es exclusivo de los tipo enlazados ya que estos pueden hacer referencia a un padre.</li>
		<li>Valor: Es exclusivo de los tipo combo y enlazados ya que estos tienen un valor por defecto para seleccionar.</li>
		<li>Acciones: Permiten la edición o borrado del campo.</li>
		<li>Ordenar: permite asignar el orden en que serán mostrados.</li>
	</ul>
</p>
<p>
	Ejemplo de ordenación: Se quiere que los campos TIPO, MARCA, MODELO, MOTOR se vean los primeros, habría que seleccionar los cuatro campos en la lista y en el menú de ordenación seleccionamos la opción “antes de” y la posición que en este caso seria el primero.
</p>
<br>
	<?php print_image("images/help/tk_15.png", false, false); ?>
</br>
<p>
	Como se puede ver, ahora aparecen los campos enlazados al comienzo de la lista.
</p>
</br>
	<?php print_image("images/help/tk_16.png", false, false); ?>
</br>
<h1>Grupos</h1>
</br>
<p>
	La asignación de grupo a un tipo de ticket es opcional y nos permite relacionar el tipo a uno o varios grupos. Si lo dejamos vacío, este tipo de ticket se podrá asignar a cualquier grupo.
</p>
</br>
	<?php print_image("images/help/gr_1.png", false, false); ?>
</br>
<p>
	Los tipos de tickets nos permiten crear tickets con campos personalizados para diferentes grupos, además de poder añadirle partes de trabajo específicos.
</p>
</br>
<p>
	<?php print_image("images/help/tk_1.png", false, false); ?>
</p>
</br>
<p>
	<ul>
		<li>- example pertenece a los grupos Customer #A, Customer #B, Engineering.</li>
		<li>- example1 pertenece a Customer #A.</li>
		<li>- example3 pertenece Customer #B.</li>
	</ul>
</p>
</br>

<h1>Plantillas para partes de trabajo</h1>
<p>
	Un ticket podrá tener asociado uno o varios partes de trabajo. Un parte de trabajo es un documento que se podrá descargar para su posterior validación. Para facilitar la creación de este documento de forma sencilla y flexible, tenemos las plantillas. Un tipo de ticket sólo podrá tener asociada una única plantilla.
</p>
<p>
	<b>Creación de plantilla</b>
	<ul>
		<li>- Opción 'Crear' que aparece debajo del listado.</li>
		<li>- Opción 'Crear plantilla de parte de trabajo' que se muestra en el menú lateral.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_1.png", false, false); ?>
</br>
<p>
	<b>Elementos que forman la plantilla:</b>
	<ul>
		<li>- Nombre de la plantilla.</li>
		<li>- Descripción: es opcional.</li>
		<li>- Asignar a: aquí se podrán elegir los tipos de ticket que van a tener asociada esa plantilla.</li>
		<li>- Contenido: puede ser texto plano o texto html. Para elegir la opción html, habrá que seleccionar el icono HTML en la barra de herramientas.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_3.png", false, false); ?>
</br>
<p>
	Se pueden añadir imágenes de forma sencilla seleccionando el siguiente icono:
</p>
</br>
	<?php print_image("images/help/wo_4.png", false, false); ?>
</br>
<p>El siguiente paso sería añadir la url de la imagen.</p>
</br>
<p>
	También podremos Utilizar macros: Las siguientes palabras serán reemplazadas por el valor real en las plantillas que las usen:
	<ul>
		<li>- <b>_sitename_:</b> Nombre de la página, tal y como está definido en la configuración.</li>
		<li>- <b>_incident_title_:</b> Título del incidente.</li>
		<li>- <b>_username_:</b> Nombre del usuario.</li>
		<li>- <b>_fullname_:</b> Nombre completo del usuario.</li>
		<li>- <b>_incident_id_:</b> ID del incidente.</li>
		<li>- <b>_url_:</b> URL del incidente.</li>
		<li>- <b>_creation_timestamp_:</b> Fecha/Hora de la creación del incidente.</li>
		<li>- <b>_update_timestamp_:</b> Última vez que el incidente fue actualizado.</li>
		<li>- <b>_owner_:</b> Usuario que gestiona el incidente.</li>
		<li>- <b>_group_:</b> Grupo asignado al incidente.</li>
		<li>- <b>_author_:</b> Creador del incidente.</li>
		<li>- <b>_type_tickets_:</b> Tipo de tickets.</li>
		<li>- <b>_priority_:</b> Prioridad del incidente.</li>
		<li>- <b>_status_:</b> Estado del incidente.</li>
		<li>- <b>_resolution_:</b> Resolución del incidente.</li>
		<li>- <b>_time_used_:</b> Tiempo total usado en el incidente.</li>
		<li>- <b>_incident_main_text_:</b> Descripción del incidente. </li>
		<li>- Plantillas de campos personalizados: Esto permite que al crear un tipo de objeto el nombre de los campos que agregas puedes incluirlos como una macro la cual mostrara el valor de dicho campo: _nombre del campo personalizado_.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wp_7.png", false, false); ?>
</br>
<p>
	Estas macros podrán ser utilizadas en código html:
</p>
</br>
	<?php print_image("images/help/wp_8.png", false, false); ?>
</br>
<p>
	A continuación, tenemos el listado con todas las plantillas que se han generado. En esta vista se muestra: nombre, descripción, a qué tipo de ticket está asignada, borrado y edición.
</p>
</br>
	<?php print_image("images/help/wo_5.png", false, false); ?>
</br>


<h1>Aplicación prácticas de tipos a tickets.</h1>
<br>
<p>
	¿Qué utilidad tienen los tipos de ticket? Los tipos de ticket nos van a permitir crear tickets de una forma flexible, es decir, al seleccionar un tipo, nos van a aparecer sus campos personalizados y podremos generar partes de trabajo utilizando su plantilla. Lo vemos con un ejemplo:
</p>
</br>
	<?php print_image("images/help/tk_17.png", false, false); ?>
</br>
<p>
	Seleccionamos el tipo de ticket:
</p>
</br>
	<?php print_image("images/help/tk_18.png", false, false); ?>
</br>
<p>
	Y vemos que aparecen todos nuestros campos personalizados:
</p>
</br>
	<?php print_image("images/help/tk_19.png", false, false); ?>
</br>
<p>
	Rellenamos los campos y creamos el ticket:
</p>
</br>
	<?php print_image("images/help/tk_20.png", false, false); ?>
</br>
<p>
	Se puede encontrar un resumen con los campos personalizados asociados a un ticket en su vista general (dashboard).
</p>
</br>
	<?php print_image("images/help/tk_27.png", false, false); ?>
</br>
<p>
	Partes de trabajo asignados a un tipo de ticket
	</br>
	La gestión de partes de trabajo dentro de un ticket se hará en la pestaña Partes de Trabajo
</p>
</br>
	<?php print_image("images/help/tk_24.png", false, false); ?>
</br>
<p>
	Para crear un parte de trabajo simplemente clickamos en nuevo y se creará un parte de trabajo que podremos descargar, validar o borrar.
</p>
</br>
	<?php print_image("images/help/tk_25.png", false, false); ?>
</br>
<p>
	Hay que tener en cuenta que un parte de trabajo validado ya no se podrá borrar ni descargar. La única acción posible asociada a este parte será la descarga de su validación.
</p>
</br>
	<?php print_image("images/help/tk_26.png", false, false); ?>
</br>
</br>
</br>


