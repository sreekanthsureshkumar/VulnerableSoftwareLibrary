<h1>Inventario Tickets</h1>
<p>
	La solapa de <b>tickets asociadas</b> al objeto de inventario indica qué tickets ha sufrido este objeto, y en qué estado se encuentran. Podemos hacer click en cualquiera de ellas para acceder a su información directamente.
</p>
<p>
	<?php print_image("images/help/inventory10.png", false, false); ?>
</p>