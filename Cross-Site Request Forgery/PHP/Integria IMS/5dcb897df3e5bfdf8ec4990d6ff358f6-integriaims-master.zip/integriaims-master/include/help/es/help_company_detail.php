<h1>Empresas</h1>
<br>
<p>
	Aquí podrá ver un listado de las empresas a las que el usuario tiene acceso. Podrá realizar búsquedas, exportar esos resultados a excel o mostrar informes con los datos de la búsqueda desde estos iconos:<br><br>
</p>

<?php print_image("images/help/help_company1.png", false); ?>
<br><br>
<p>
	El usuario solo tendrá acceso a esta sección si tiene permisos de “Ver CRM” y las empresas están vinculadas a su nombre. También podrá verlas si tiene ese permiso y las empresas están asociadas a su compañía base (la compañía asociada al perfil de ese usuario).
<br>
	Para poder modificar las empresas visualizadas, deberá tener tener permisos de edición de CRM y ser propietario de esa empresa o que estén asociadas a su empresa base.
<br>
	Si un usuario no ve una empresa en esta lista, revise de nuevo la asignación de permisos y perfiles de ese usuario y la ficha de la empresa, para verificar a qué usuario está asignada y/o a que empresa base está:
<br>
</p>
<br>
<?php print_image("images/help/help_invoice2.png", false, array('width' => '900' )); ?>

