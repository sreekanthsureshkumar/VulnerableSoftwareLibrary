<h1>D&iacute;as m&aacute;ximos de horas de trabajo</h1>

<p>
Se borrar&aacute;n las horas de trabajo m&aacute;s antiguas que los d&iacute;as indicados,
siempre y cuando pertenezcan a proyectos deshabilitados.
Si el valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 0.
</p>
