<h1>Tipos de contrato</h1>
</br>
<p>
	Los tipos de contrato nos permiten crear contratos con campos personalizados asociados a estos tipos.
</p>
</br>
<p>
	<b>Para crear un tipo de contrato tenemos dos opciones:</b>
	<ul>
		<li>- El botón que aparece debajo de la lista de tipos de contratos.</li>
		<?php print_image("images/help/contract_type7.png", false, false); ?>
		<br>
		<li>- La opcion crear tipo de contrato del menú lateral.</li>
		<br>
		<?php print_image("images/help/contract_type1.png", false, false); ?>
	</ul>
</p>
</br>
<p>
	<b>Campos que se pueden definir en la creación/edición de un tipo de contrato:</b>
	<ul>
		<li><b>- Nombre:</b> es obligatorio y debe ser único, es decir, no puede coincidir con el nombre de otro tipo existente. Este campo es el que se mostrará en el formulario de creación/edición de contratos para poder seleccionar el tipo.</li>
		<li><b>- Descripción:</b> es opcional.</li>
	</ul>
</p>
</br>
<p>
	<?php print_image("images/help/contract_type8.png", false, false); ?>
</p>
</br>
<p>
	Las acciones que se pueden aplicar a un tipo son:
	<ul>
		<li>- Añadir campos personalizados.</li>
		<li>- Actualizar los datos (nombre, descripción).</li>
		<li>- Borrado.</li>
	</ul>
</p>
<p>
	Para actualizar, se hace click en el icono llave inglesa que nos llevará a la vista de edición. Una vez aquí, podremos modificar cualquier apartado.
</p>
</br>
<p>
	Para borrar, se hace click en el icono papelera. Esta acción nos pedirá confirmación. Una vez aceptado, el borrado será definitivo y no se podrá deshacer esta acción.
</p>
</br>
<p>
	Para añadir campos personalizados, se hace click en el nombre del tipo.
</p>
</br>
<p>
	<?php print_image("images/help/contract_type2.png", false, false); ?>
</p>
</br>
<p>
	<h1>Campos personalizados</h1>
</p>
</br>
<p>
	<b>En la creación de campos se puede definir:</b>
</p>
</br>
<p>
	<ul>
		<li>- Nombre: es obligatorio y puede no ser único.</li>
		<li>- Mostrar en la lista de contratos: al marcar esta opción, aparecerá como columna en el listado de contratos.</li>
		<ul>
			<li>- Tipo texto: Se mostrará en el formulario de creación/edición de contratos un campo de tipo input.</li>
			</br>
			<li>- Textarea: Se mostrará en el formulario de creación/edición de contratos un campo de tipo textarea.</li>
			</br>
			<li>- Combo: Se mostrará en el formulario de creación/edición de contratos un campo de tipo select con todas las opciones disponibles.</li>
			</br>
			<li>- Enlazado: Son campos personalizados relacionados entre sí. Los vamos a explicar con un ejemplo:</li>
            <ul>
				<li>TIPO,MARCA,MODELO</li>
				<li>--Primero se crea el campo TIPO. En este caso, no se selecciona un campo padre porque es el primero en la jerarquía. Los valores irán separados por coma.</li>
				<br>
				<?php print_image("images/help/contract_type9.png", false, false); ?>
				</br>
				<li>Después se creará el campo MARCA. En este caso, se selecciona el campo padre TIPO. Después se rellenará el campo con los valores separados por coma como en el caso anterior. Como este campo sí tiene un padre, habrá que asociar los valores. Para ello, se pondrá delante el valor del campo padre separado de |</li>
				<br>
				<?php print_image("images/help/contract_type10.png", false, false); ?>
				</br>
				<li>El siguiente campo que se va a crear es MODELO. Se selecciona el padre MARCA y se ponen los valores.</li>
				<br>
				<?php print_image("images/help/contract_type11.png", false, false); ?>
				</br>
			</ul>
            </br>
			<li>- Numérico: Se mostrará en el formulario de creación/edición de contratos un campo de tipo numérico.</li>
			<br>
			<li>- Fecha: Se mostrará en el formulario de creación/edición de contratos un campo de tipo fecha.</li>
			<br>
			<?php print_image("images/help/contract_type4.png", false, false); ?>
			</br>
		</ul>
	</ul>
</p>
<br>
<p>
	A continuación se muestra el listado con todos los campos que se han creado.
</p>
<br>
	<?php print_image("images/help/contract_type3.png", false, false); ?>
</br>
</br>
<p>
	<b>Las columnas que componen este listado son:</b>
</p>
</br>
<p>
	<ul>
		<li>Nombre del campo.</li>
		<li>Tipo del campo.</li>
		<li>Padre: Es exclusivo de los tipo enlazados ya que estos pueden hacer referencia a un padre.</li>
		<li>Valor: Es exclusivo de los tipo combo y enlazados ya que estos tienen un valor por defecto para seleccionar.</li>
		<li>Acciones: Permiten la edición o borrado del campo.</li>
	</ul>
</p>

<h1>Aplicación prácticas de tipos a contratos.</h1>
<br>
<p>
	¿Qué utilidad tienen los tipos de contratos? Los tipos de contrato nos van a permitir crear contratos de una forma flexible, es decir, al seleccionar un tipo, nos van a aparecer sus campos personalizados. Lo vemos con un ejemplo:
</p>
</br>
<p>
	Seleccionamos el tipo de contrato:
</p>
</br>
	<?php print_image("images/help/contract_type5.png", false, false); ?>
</br>
<p>
	Y vemos que aparecen todos nuestros campos personalizados:
</p>
</br>
<p>
	Rellenamos los campos y creamos el contrato:
</p>
</br>
	<?php print_image("images/help/contract_type6.png", false, false); ?>
</br>
<p>
    Hay que tener en cuenta que ahora se podrán hacer búsquedas de contratos para el tipo concreto que hayamos elegido y sus campos personalizados asociados.
</p>
</br>
</br>


