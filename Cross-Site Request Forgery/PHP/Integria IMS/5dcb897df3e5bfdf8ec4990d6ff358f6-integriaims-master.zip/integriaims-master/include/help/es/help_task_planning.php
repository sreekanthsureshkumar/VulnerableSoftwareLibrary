<h1>Gestión de proyectos con el Planificador de Tareas</h1>
<p>
	El planificador de tareas es una vista que permite una gestión ágil de las tareas. Es posible crear, editar y borrar tareas, la creación de nuevas unidades de trabajo (WU), tickets, etc.
</br>
</br>
	Además ofrece una estadísticas con: el número de tareas por estado, las horas trabajadas por empleado, y las tareas asignadas a cada empleado.
</p>


	<?php print_image("images/help/project7.png", false, array('width' => '720')); ?>

<p>
	Para actualizar la información de las tareas realice todos los cambios que quiera en la tabla y para salvarlos pulse en el botón Update. Si la tarea tiene más de un empleado asignado y quiere realizar algún cambio en este campo deberá ir al menú de edición detallado pulsando en el icono con forma de herramienta situado en la columna de la derecha. Para borrar una tarea puede usar el botón con forma de papelera situado en la columna de la derecha.
	</br>
	</br>
	El color mostrado en cada tarea se corresponde al siguiente porcentaje completado:
	<ul>
		<li>Pendientes (blanco): Entre 0% y 39%</li>
		<li>En procesos (amarillo): Entre 40% y 89%</li>
		<li>Completado (azul): Entre 90% y 99%</li>
		<li>Verificado (verde): 100%</li>
	</ul>
	</br>
	Para añadir una nueva tarea tiene que rellenar los campos y pulsar en el botón Create.
	</br>
	</br>
	Para borrar una tarea debemos irnos a Planificación de Tareas y pinchar sobre el icono de la derecha de una papelera en la tarea que queramos borrar.
</p>
	<?php print_image("images/help/project6.png", false,  array('width' => '720')); ?>
	<h1> Creación de nuevas unidades de trabajo (WUs) desde el planificador de tareas</h1>
<p>
	Mediante la creación manual de unidades de trabajo podemos imputar tiempo en un proyecto y tarea. No debemos confundir estas unidades de trabajo manuales con los comentarios de los tickets (también llamados unidades de trabajo). En el caso de las unidades de trabajo de tickets, imputarán automáticamente el tiempo total del ticket cuando éste se encuentre asignado a una tarea; en el caso de estas unidades de trabajo individuales, serán añadidas manualmente por el usuario e imputarán el tiempo directamente según lo introducido al crear la unidad de trabajo. El formulario de creación tiene una serie de campos básicos (descripción, número de horas empleadas en la unidad de trabajo, perfil asignado, etc). Además ofrece unos controles que permiten “dividir” la unidad de trabajo en bloques de X horas (por defecto 8 horas) y repartir ese tiempo en diferentes Unidades de Trabajo (WU) a lo largo del tiempo (para adelante o para detrás, según se elija) con el mismo contenido que la original, exceptuando por la fecha. Es la forma idónea de “rellenar” las horas para completar un calendario de vacaciones, por ejemplo.
</p><br>
<p>
	Las unidades de trabajo de un proyecto se pueden crear desde el <strong>planificador de tareas</strong>:
</p>
	<?php print_image("images/help/doc28.png", false,  array('width' => '720')); ?>
<p>
	O bien desde la sección de usuario (<strong>Usuarios → Agregar unidad de trabajo</strong>). Hay tres supuestos especiales que contempla Integria IMS:
</p><br>
<ul>
	<li type="disc">Vacaciones</li>
	<li type="disc">Baja por enfermedad</li>
	<li type="disc">No justificado</li>
</ul><br>
<p>
	Estos conceptos corresponden a tareas especiales dentro de un proyecto especial que se computa de manera diferente.<br>
	Las unidades de trabajo se pueden crear de una en una o en bloques de forma que sea más cómodo y se pueden previsualizar todas antes de subirlas al sistema.
</p>
<?php print_image("images/help/project17.png", false,  array('width' => '720')); ?>
<?php print_image("images/help/project18.png", false,  array('width' => '720')); ?>
