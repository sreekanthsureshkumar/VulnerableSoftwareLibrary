<h1>D&iacute;as m&aacute;ximos de datos de eventos</h1>

<p>
Se borrar&aacute;n los eventos antiguos a partir de los d&iacute;as indicados. Si el
valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 30.
</p>
