<h1>D&iacute;as m&aacute;ximos de datos de seguimiento de ficheros</h1>

<p>
Se borrar&aacute;n los datos de seguimiento de fichero m&aacute;s antiguos
que los d&iacute;as indicados.
Si el valor indicado es 0, los datos no se borrar&aacute;n nunca.
</p>
<p>
Valor por defecto: 15.
</p>