<h1>Perfiles</h1>

<p>
Esta característica le permite definir acceso granular a las características de Integria IMS.
</p>
<p>
<li>Incidentes: Permisos para gestionar incidentes</li>
<li>Inventario: Permisos para gestionar el inventario</li>
<li>Agenda: Permisos para gestionar la agenda</li>
<li>Proyectos: Permisos para gestionar los proyectos</li>
<li>Base de conocimiento: Permisos para gestionar la base de datos</li>
<li>Tareas: Permisos para gestionar las tareas</li>
<li>Usuarios: Permisos para gestionar los usuarios</li>
<li>Base de datos: Permisos para gestionar la base de datos</li>
<li>Integria IMS: Permisos para gestionar Integria IMS</li>
</p>
<p>
Para obtener más información consulte <a href="http://openideas.info/wiki/index.php?title=Integria:Documentation_es:Usuarios#Gestionar_perfiles">la documentación</a>.
</p>
