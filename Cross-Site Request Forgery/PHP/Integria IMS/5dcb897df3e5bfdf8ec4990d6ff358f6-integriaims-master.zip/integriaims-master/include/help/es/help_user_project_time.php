<h1>Mapa horario del proyecto / Gráfica de tiempo por proyecto</h1>
<p>
	Esta opción nos permite ver de una forma visual, para una persona dada, en un intervalo de tiempo dado, que a proyectos ha dedicado tiempo, y mostrarlo a escala.
</p>
<p>
	<?php print_image("images/help/project8.png", false, false); ?>
</p>