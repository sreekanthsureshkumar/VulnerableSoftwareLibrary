<h1>Ficheros adjuntos a las tareas</h1>
<p>
	El gestor de tareas de Integria IMS permite adjuntar archivos a las tareas. Estos archivos se almacenan en el servidor y se guardan en el directorio de adjuntos. Se pueden subir tantos archivos como se quiera (no hay gestor de cuota o almacenamiento máximo). Todos los archivos subidos serán accesibles por los usuarios con permisos de lectura de la tarea.
</p>
<p>
	<?php print_image("images/help/project19.png", false, false); ?>
</p>