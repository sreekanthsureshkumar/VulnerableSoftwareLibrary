<h1>Configuraciones de correo SMTP:</h1>

<h1><b>Gmail:</b></h1>
	<br>
	<p>
		<u>Sin cifrado:</u>
	</p>
	<p>
		Gmail no permite enviar correos sin cifrado por lo que al
		menos debemos configurar el cifrado como STARTTLS, la cual se puede utilizar en los puertos 25 ó 587.
	</p>
	<br>
	<p>
		<u>Con cifrado:</u> (STARTTLS)
	</p>
	</p>
		<span>
			<?php print_image("images/help/gmail1.png", false, false); ?>
		</span>
		<br><br>
		<p>
			Como vemos en la imagen anterior configuramos:
		<p>
			<ul>
		 		<li>- Método de cifrado: STARTTLS</li>
				<li>- SMTP Host: smtp.gmail.com</li>
				<li>- Puerto: 587 (también podría utilizarse el 25)</li>
			</ul>
		</p>
		<br>
		<p>	
			SSL y diferentes versiones:
		</p>
		<span>
			<?php print_image("images/help/gmail2.png", false, false); ?>
		</span>
		<br><br>
		<p>	
			Como vemos en la imagen anterior configuramos:
		</p>
		<p>
			<ul>
				<li>- Método de cifrado: SSL/TLS.</li>
				<li>- SMPT Host: smptp.gmail.com.</li>
				<li>- Puerto: 465.</li>
			</ul>
		</p>
		<br>
	<p>	
		Nota: Con el botón de test podremos probar si nuestra configuración es válida.
	</p>
<p>	
<h1><b>Outlook:</b></h1>
	<br>
	<p>
		<u>Sin cifrado:</u>
	</p>
	<p>
		Outlook no permite enviar correos sin cifrado por lo que al
		menos debemos configurar el cifrado como STARTTLS, la cual se puede utilizar en los puertos 25 ó 587.
	</p>
	<br>
	<p>
		<u>Con cifrado:</u>(STARTTLS:)
	</p>
	<span>
		<?php print_image("images/help/outlook1.png", false, false); ?>
	</span>
	<br><br>
	<p>
		Como vemos en la imagen anterior configuramos:
	</p>
	<ul>
		<li> - Método de cifrado: STARTTLS </li>
		<li> - SMTP Host: smtp-mail.outlook.com </li>
		<li> - Puerto: 587 (también podría utilizarse el 25) </li>
	</ul>
	<br>
	<p>
		SSL y diferentes versiones:
	</p>
	<p>
		No permite este tipo de cifrado, sólo STARTTLS.
	</p>
	<br>
	<p>	
		<ul>
			Nota: 
			<li>- Con el botón de test podremos probar si nuestra configuración es valida.</li>
			<li>- Outlook no permite utilizar usuarios de otros servicios de correo, sólo propios, por lo que es necesario especificar el mismo correo que se utiliza para la configuración SMTP.</li>
		</ul>
	</p>
	<span>
		<?php print_image("images/help/outlook2.png", false, false); ?>
	</span>
<h1><b>Office365:</b></h1>
	<br>
	<p>
		<u>Sin cifrado:</u>
	</p>
	<p>
		Outlook no permite enviar correos sin cifrado por lo que al
		menos debemos configurar la cifrado como STARTTLS, la cual se puede utilizar en los puertos 25 ó 587.
	</p>
	<br>
	</p>
		<u>Con cifrado:</u>(STARTTLS)
	</p>
	<span>
		<?php print_image("images/help/office365_1.png", false, false); ?>
	</span>
	<br>
	<p>
		Como vemos en la imagen anterior tenemos:
	</p>
	<ul>
		<li> - Método de cifrado: STARTTLS</li>
		<li> - SMTP Host: smtp.office365.com</li>
		<li> - Puerto: 587 (también podría utilizarse el 25)</li>
	</ul>
	<br>
	<p>	
		SSL y diferentes versiones:
	</p>
	<p>	
		No permite este tipo de cifrado, solo STARTTLS.
	</p>
	<br>
	<ul>
		Nota: 
		<li>- Con el botón de test podremos probar si nuestra configuración es valida.</li>
		<li>- Office no permite utilizar usuarios de otros servicios de correo, sólo propios, por lo que es necesario especificar el mismo correo que se utiliza para la configuración SMTP.</li>
	</ul>
	<span>
		<?php print_image("images/help/office365_2.png", false, false); ?>
	</span>
<h1><b>Otros:</b></h1>
	<br>
	<ul>
	    <li>  - Cifrado: Podemos configurar el servidor de correo sin cifrado o con SSL/TLS, SSLv2, SSLv3 o STARTTLS.</li>
	    <li>  - Nombre: Nombre DNS o IP del servidor de correo.</li>
	    <li>  - Puerto: Puerto en el que esté escuchando el servidor de correo.</li>
	    <li>  - Usuario: Usuario configurado en el servidor de correo.</li>
	    <li>  - Contraseña: Contraseña configurada para el usuario indicado anteriormente.</li>
	</ul>
</p>
