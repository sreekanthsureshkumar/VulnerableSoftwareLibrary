<h1>Seguimiento de Proyectos</h1>
<p>
	Integria IMS realiza un seguimiento (tracking) de prácticamente todas aquellas secciones o elementos de información que son susceptibles a cambios. En el caso del proyecto registra todas las operaciones de apertura, cierre, cambio y adición de información en las tareas de dicho proyecto.
<p>
	<?php print_image("images/help/project_track.png", false, false); ?>
</p>