<h1>Inventario Contactos</h1>
<p>
	La solapa de <b>contactos</b>, nos muestra las personas asociadas a ese objeto de inventario. Podemos hacer click en cualquiera de ellos para acceder a su información directamente.
</p>
<p>
	<?php print_image("images/help/inventory9.png", false, false); ?>
</p>