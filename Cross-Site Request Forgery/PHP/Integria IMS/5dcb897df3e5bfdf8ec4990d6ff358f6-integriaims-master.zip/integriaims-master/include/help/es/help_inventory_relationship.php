<h1>Inventario Relaciones</h1>
<p>
	La solapa de <b>relaciones</b>, muestra los demás objetos relacionados con éste. Se pueden asociar nuevos objetos, tan sólo hay que escogerlo del combo y vincularlo como se muestra a continuación. De esta forma, se pueden relacionar otros objetos además del objeto padre.
</p>
<p>
	<?php print_image("images/help/inventory8.png", false, false); ?>
</p>
