<h1>Work order templates</h1>
<p>
	A ticket can be associated with one or more work orders . A work order is a document that can be downloaded for subsequent validation . There are two templates to facilitate the document’s creation. A ticket type can only have one template associated with it.
</p>
<p>
	<b>Template creation</b>
	<ul>
		<li>- ‘Create’ option that appears at the bottom of the list.</li>
		<li>- ‘Create work order template’ that appears in the sidebar.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_1.png", false, false); ?>
</br>
<p>
	<b>Template elements:</b>
	<ul>
		<li>- Template name.</li>
		<li>- Description: optional.</li>
		<li>- Assign to: choose the ticket type that the template will be associated with</li>
		<li>- Content: plain text or HTML. To choose HTML click the icon in the toolbar.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_3.png", false, false); ?>
</br>
<p>
	Add images by clicking this icon:
</p>
</br>
	<?php print_image("images/help/wo_4.png", false, false); ?>
</br>
<p>Add the image’s URL.</p>
</br>
<p>
	The following words will be replaced on templates that use them with actual values:
	<ul>
		<li>- <b>_sitename_:</b> As configured.</li>
		<li>- <b>_incident_title_:</b> title incident</li>
		<li>- <b>_username_:</b> Of the person who receives the email.</li>
		<li>- <b>_fullname_:</b> Of the person who receives the email.</li>
		<li>- <b>_incident_id_:</b></li>
		<li>- <b>_url_:</b> incident URL.</li>
		<li>- <b>_creation_timestamp_:</b> Date/time incident was created.</li>
		<li>- <b>_update_timestamp_:</b>  Last time incident was updated.</li>
		<li>- <b>_owner_:</b> User responsible for managing the incident.</li>
		<li>- <b>_group_:</b> Group assigned to the incident.</li>
		<li>- <b>_author_:</b>  Incident creator.</li>
		<li>- <b>_type_tickets_:</b> Ticket type.</li>
		<li>- <b>_priority_:</b> Of incident.</li>
		<li>- <b>_status_:</b> Of incident.</li>
		<li>- <b>_resolution_:</b> Of incident.</li>
		<li>- <b>_time_used_:</b> Total of incident.</li>
		<li>- <b>_incident_main_text_:</b> Description of incident. </li>
		<li>- Custom field templates:When creating an object type , the name of the included fields can be added as a macro displaying the value of said field: _customizable field name_.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wp_7.png", false, false); ?>
</br>
<p>
	These macros can be used in html code:
</p>
</br>
	<?php print_image("images/help/wp_8.png", false, false); ?>
</br>
<p>
	You now have a list with all the templates generated. Here you can see: name, description, what ticket type it’s assigned to, delete and edit.
</p>
</br>
	<?php print_image("images/help/wo_5.png", false, false); ?>
</br>