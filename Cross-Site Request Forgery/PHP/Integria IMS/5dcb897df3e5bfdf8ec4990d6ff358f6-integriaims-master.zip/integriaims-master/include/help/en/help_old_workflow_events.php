<h1>Maximum days of workflow event data</h1>

<p>
The workflow event data older than the days specified will be deleted.
If the value is 0, the data never will be deleted.
</p>
<p>
Default value: 900.
</p>
