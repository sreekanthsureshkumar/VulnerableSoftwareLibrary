<h1>Groups reports:</h1>
<p>
	<ul>
		You need the following profile to view the group reports:
		<li>.-View projects (Project manager role)</li>
		<li>.-View reports</li>
	</ul>
</p>
<p>
	You need to choose the group in the selector to generate the report.
</p>
<br>
<p>
	<?php print_image("images/help/group_report1.png", false, false); ?>
</p>
</br>
<p>
	Once the group is selected you'll see the workunits asociated to this group.
</p>
</br>
<p>
	A date selector is also available to filter these workunits.
</p>
<br>
<p>
	<?php print_image("images/help/group_report2.png", false, false); ?>
</p>