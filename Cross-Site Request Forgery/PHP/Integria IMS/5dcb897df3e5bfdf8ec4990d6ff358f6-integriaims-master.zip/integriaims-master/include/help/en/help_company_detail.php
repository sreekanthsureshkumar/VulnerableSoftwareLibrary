
<h1>Company</h1>
 <br>
<p>
	Here is a list of companies to which the user has access. It will be possible to make searches, export those results to excel or show reports with the data of the search from these icons: <br><br>
</p>

<?php print_image("images/help/help_company1.png", false); ?>
 <br><br>
<p>
	The user will only have access to this section with "View CRM" permissions and the companies are linked to their name. This section can also be viewed if the user has this permission and the companies are associated with their base company (the company associated with that user's profile).

<br>
	In order to modify the displayed companies, the user must have CRM editing permissions and be the owner of that company or be associated to its base company.
<br>
	If a user cannot view a company in this list, check the assignment of permissions and profiles of that user again and the information of the company to verify to which user it is assigned and/or to which base company it belongs:

<br>
</p>
<br>
<?php print_image("images/help/help_invoice2.png", false, array('width' => '900' )); ?>
