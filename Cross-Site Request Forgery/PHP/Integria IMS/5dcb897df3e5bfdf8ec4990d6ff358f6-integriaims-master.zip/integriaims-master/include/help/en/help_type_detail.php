<h1>Ticket types</h1>
</br>
<p>
	Ticket types allow custom tickets to be created for different groups, as well as allowing specific work orders to be included.
</p>
</br>
<p>
	<b>To create a ticket type there are two options:</b>
	<ul>
		<li>- The button below the ticket types list.</li>
		<?php print_image("images/help/tk_2.png", false, false); ?>
		<br>
		<li>- The ‘Create ticket type’ option that appears in the sidebar.</li>
		<br>
		<?php print_image("images/help/tk_2_2.png", false, false); ?>
	</ul>
</p>
</br>
<p>
	<b>Definable fields in ticket type creation/editing:</b>
	<ul>
		<li><b>- Name:</b> obligatory and must not be repeated, i.e. no two tickets may share a name. This is the field that is displayed in ‘create/edit tickets’ in order to select the type.</li>
		<li><b>- Description:</b> optional field.</li>
		<li><b>- Template work order: </b> optional. Allows a template to be added to a work order.</li>
		<li><b>- Groups:</b> optional. Allows a type to be related to one or various groups. If left empty this kind of ticket can be assigned to any group.</li>
	</ul>
</p>
</br>
<p>
	<?php print_image("images/help/tk_3.png", false, false); ?>
</p>
</br>
<p>
	Actions applicable to a type are:
	<ul>
		<li>- Add custom fields.</li>
		<li>- Update information (name, description, template, group</li>
		<li>- Delete.</li>
	</ul>
	E.g.
</p>
<p>
	<?php print_image("images/help/tk_4.png", false, false); ?>
</p>
</br>
<p>
	To update, click on the wrench icon to go to edit view. You can modify any section from here.
</p>
</br>
<p>
	<?php print_image("images/help/tk_5.png", false, false); ?>
</p>
</br>
<p>
	To delete, click the trashcan icon. You’ll be asked to confirm. Once the action is performed it is definitive.
</p>
</br>
<p>
	<?php print_image("images/help/tk_6.png", false, false); ?>
</p>
</br>
<p>
	To add more custom fields click the ‘add’ icon.
</p>
</br>
<p>
	<?php print_image("images/help/tk_7.png", false, false); ?>
</p>
</br>
<p>
	<h1>Custom fields</h1>
</p>
</br>
<p>
	<b>In field creation you can define:</b>
</p>
</br>
<p>
	<ul>
		<li>- Name: obligatory field. Doesn’t have to be unique.</li>
		<li>- Display in ticket list: if you select this option it will appear as a column in the ticket list.</li>
		<li>- Global field: if you select this option it will appear in the ticket search form in advanced options.</li>
		<li>- Field type:</li>
		<ul>
			<li>- Text type: in the “create/edit ticket” form an input field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_8.png", false, false); ?>
			</br>
			<li>- Textarea: in the “create/edit ticket” form a text area field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_9.png", false, false); ?>
			</br>
			<li>- Combo box: in the “create/edit ticket” form a select form will be displayed where you can see all available options.</li>
			<br>
			<?php print_image("images/help/tk_10.png", false, false); ?>
			</br>
			<li>- Linked: interrelated custom fields</li>
			<ul>
				<li>e.g., BRANCH, DEPARTMENT, DIVISION</li>
				<li>--First you create the BRANCH field. In this case, a parent field is not selected because it is the first field in the hierarchy. The values are separated by a comma.</li>
				<br>
				<?php print_image("images/help/tk_11.png", false, false); ?>
				</br>
				<li>--Then, the DEPARTMENT field is created. In this case, the parent field BRANCH is selected. The field is then filled with the values separated by commas as above. As this field does have a parent, the values will have to be associated. To do this, place the value of the parent field ath the beginnning, separated by | from the rest. Like this we will indicate that the new field belongs to the parent field that precedes it (a department belongs to a headquarters).</li>
				<br>
				<?php print_image("images/help/tk_11_1.png", false, false); ?>
				</br>
				<li>--The next field to be created is DIVISION. The parent DEPARTMENT is selected and the values are set. Similarly, the relationship established indicates that a division belongs to a department.</li>
				<br>
				<?php print_image("images/help/tk_112.png", false, false); ?>
				</br>
			</ul>
			<li>-Numeric: in the “create/edit ticket” form a numeric field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_12.png", false, false); ?>
			</br>
			<li>-Date: in the “create/edit ticket” form a date field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_13.png", false, false); ?>
			</br>
		</ul>
	</ul>
</p>
<br>
<p>
	A list with all the fields you created will be displayed.
</p>
<br>
	<?php print_image("images/help/tk_14.png", false, false); ?>
</br>
<p>
	<b>The list is made up of the following columns:</b>
</p>
<p>
	<ul>
		<li>Field name.</li>
		<li>Field type.</li>
		<li>Parent: exclusive to linked types as these can refer to a parent.</li>
		<li>Value: exclusive to combo box and linked types as these have a selectable default value.</li>
		<li>Actions: allow the field to be edited or deleted.</li>
		<li>Ordering: to assign the order in which they are displayed.</li>
	</ul>
</p>
<p>
	Example of ordering: If you want the TYPE, MAKE, MODEL, MOTOR fields to appear first, and in that order, select the four categories from the list and in the ordering menu select the “before” option and the position (in this case, first position).
</p>
<br>
	<?php print_image("images/help/tk_15.png", false, false); ?>
</br>
<p>
	As can be seen, the linked fields appear at the beginning of the list.
</p>
</br>
	<?php print_image("images/help/tk_16.png", false, false); ?>
</br>
<h1>Groups</h1>
</br>
<p>
	Assigning a group to a ticket is optional and allows you to relate a type to one or more groups. If left empty, this kind of ticket can be assigned to any group.
</p>
</br>
	<?php print_image("images/help/gr_1.png", false, false); ?>
</br>
<p>
	E.g.
</p>
</br>
<p>
	<?php print_image("images/help/tk_1.png", false, false); ?>
</p>
</br>
<p>
	<ul>
		<li>- example belongs to the Customer #A, Customer #B,, Engineerin</li>
		<li>- example1 belongs to Customer #A.</li>
		<li>- example3 belongs to Customer #B.</li>
	</ul>
</p>
</br>

<h1>Work order templates</h1>
<p>
	A ticket can be associated with one or more work orders . A work order is a document that can be downloaded for subsequent validation . There are two templates to facilitate the document’s creation. A ticket type can only have one template associated with it.
</p>
<p>
	<b>Template creation</b>
	<ul>
		<li>- ‘Create’ option that appears at the bottom of the list.</li>
		<li>- ‘Create work order template’ that appears in the sidebar.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_1.png", false, false); ?>
</br>
<p>
	<b>Template elements:</b>
	<ul>
		<li>- Template name.</li>
		<li>- Description: optional.</li>
		<li>- Assign to: choose the ticket type that the template will be associated with</li>
		<li>- Content: plain text or HTML. To choose HTML click the icon in the toolbar.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wo_3.png", false, false); ?>
</br>
<p>
	Add images by clicking this icon:
</p>
</br>
	<?php print_image("images/help/wo_4.png", false, false); ?>
</br>
<p>Add the image’s URL.</p>
</br>
<p>
	The following words will be replaced on templates that use them with actual values:
	<ul>
		<li>- <b>_sitename_:</b> As configured.</li>
		<li>- <b>_incident_title_:</b> title incident</li>
		<li>- <b>_username_:</b> Of the person who receives the email.</li>
		<li>- <b>_fullname_:</b> Of the person who receives the email.</li>
		<li>- <b>_incident_id_:</b></li>
		<li>- <b>_url_:</b> incident URL.</li>
		<li>- <b>_creation_timestamp_:</b> Date/time incident was created.</li>
		<li>- <b>_update_timestamp_:</b>  Last time incident was updated.</li>
		<li>- <b>_owner_:</b> User responsible for managing the incident.</li>
		<li>- <b>_group_:</b> Group assigned to the incident.</li>
		<li>- <b>_author_:</b>  Incident creator.</li>
		<li>- <b>_type_tickets_:</b> Ticket type.</li>
		<li>- <b>_priority_:</b> Of incident.</li>
		<li>- <b>_status_:</b> Of incident.</li>
		<li>- <b>_resolution_:</b> Of incident.</li>
		<li>- <b>_time_used_:</b> Total of incident.</li>
		<li>- <b>_incident_main_text_:</b> Description of incident. </li>
		<li>- Custom field templates:When creating an object type , the name of the included fields can be added as a macro displaying the value of said field: _customizable field name_.</li>
	</ul>
</p>
</br>
	<?php print_image("images/help/wp_7.png", false, false); ?>
</br>
<p>
	These macros can be used in html code:
</p>
</br>
	<?php print_image("images/help/wp_8.png", false, false); ?>
</br>
<p>
	You now have a list with all the templates generated. Here you can see: name, description, what ticket type it’s assigned to, delete and edit.
</p>
</br>
	<?php print_image("images/help/wo_5.png", false, false); ?>
</br>


<h1>Practical Applications of Tickets Types</h1>
<br>
<p>
	Ticket types allow you to create tickets flexibly, i.e., when you select a type, the custom fields will appear and you can generate work orders using the template. E.g.
</p>
</br>
	<?php print_image("images/help/tk_17.png", false, false); ?>
</br>
<p>
	Select ticket type:
</p>
</br>
	<?php print_image("images/help/tk_18.png", false, false); ?>
</br>
<p>
	All the custom fields will appear:
</p>
</br>
	<?php print_image("images/help/tk_19.png", false, false); ?>
</br>
<p>
	Fill out the fields and create the tickets:
</p>
</br>
	<?php print_image("images/help/tk_20.png", false, false); ?>
</br>
<p>
	You can find a summary of the custom fields associated with a ticket on the Dashboard.
</p>
</br>
	<?php print_image("images/help/tk_27.png", false, false); ?>
</br>
<p>
	Work orders assigned to a ticket type
	</br>
	Use the ‘Work orders’ tab to manage work orders on a ticket
</p>
</br>
	<?php print_image("images/help/tk_24.png", false, false); ?>
</br>
<p>
	Click ’new’ to create a work order that you can then download, validate or delete.
</p>
</br>
	<?php print_image("images/help/tk_25.png", false, false); ?>
</br>
<p>
	Keep in mind that a validated work order can’t be deleted or downloaded. Only the validation itself can be downloaded here.
</p>
</br>
	<?php print_image("images/help/tk_26.png", false, false); ?>
</br>
</br>
</br>