<h1>Informe de tarea</h1>
<p>
	Integria IMS has an option to send an automated report on the task in its current status to all members in that task. Select the menu button Project→Task→Email Reports to access this tool.
	</br>
	</br>
	The task report will automatically generate a text that an user can modify or customize. By pressing the “send” button, an email will be generated and sent automatically to each member participating in the task.
</p>
<p>
	<?php print_image("images/help/project21.png", false, false); ?>
</p>