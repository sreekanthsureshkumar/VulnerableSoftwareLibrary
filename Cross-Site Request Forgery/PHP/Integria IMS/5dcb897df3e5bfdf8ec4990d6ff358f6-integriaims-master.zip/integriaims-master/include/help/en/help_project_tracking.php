<h1>Project follow up</h1>
<p>
	Integria IMS tracks practically all those sections or information elements that are subject to change. In the case of a project, it'll register all opening, closing, changing or information adding operations on said project's tasks.
<p>
	<?php print_image("images/help/project_track.png", false, false); ?>
</p>