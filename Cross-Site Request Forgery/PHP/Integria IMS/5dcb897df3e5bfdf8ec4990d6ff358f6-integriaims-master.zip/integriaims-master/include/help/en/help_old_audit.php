<h1>Maximum days of audit data</h1>

<p>
The audit data older than the days specified will be deleted.
If the value is 0, the data never will be deleted.
</p>
<p>
Default value: 15.
</p>
