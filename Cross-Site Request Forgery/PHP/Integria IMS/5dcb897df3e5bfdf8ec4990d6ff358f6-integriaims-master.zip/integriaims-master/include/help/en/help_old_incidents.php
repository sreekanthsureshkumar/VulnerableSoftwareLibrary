<h1>Maximum days of closed incidents</h1>

<p>
The incidents with a closing date older than the days specified will
be deleted. The related data will be deleted too.
If the value is 0, the data never will be deleted.
</p>
<p>
Default value: 0.
</p>
