<h1>Auto Workunit Completion</h1>

<p>
	<br><br>
Number of days that will be taken into account, backwards, for the automatic allocation of hours. Check that a minimum number of daily hours has been entered through the work units. This minimum number of hours per day corresponds to the field 'Hours of work per day'. This will be the case for all users who are not included in the 'Users without WU Completion' field. <br><br>
</p>
<p>
Example:<br><br>

Daily WU hours: 8 <br>
WU Autocomplete (days): 15 <br>
Users without WU Autocomplete: empty <br><br>

In this case, it will be checked that all users have entered 8 hours per day through the work units during the last 15 days. If, for example, there is a user who one day has entered 4 hours instead of the minimum 8 hours, the remaining 4 hours will be assigned to the 'Unjustified' task.

</p>
