<h1>POP/IMAP mail settings:</h1>
<br>
<p><b><i>
	Important: Try not to use the IMAP/POP account of any internal Integria IMS user, as this may cause some strange behavior when creating and updating tickets in Integria IMS.
</p></b></i>
<h1>
	Gmail: Allows only this setting:
</h1>
<br>
<p>
	SSL/TLS:
</p>
<br>
<ul>
	<li>
		<p>IMAP:</p>
		<span>
			<?php print_image("images/help/gmail4.png", false, false); ?>
		</span>
	</li>
	<li>				
		<p>POP:</p>
		<span>
			<?php print_image("images/help/gmail3.png", false, false); ?>
		</span>
	</li>
</ul>
<br>
<ul>
	<li>- Name: imap.gmail.com / pop.gmail.com</li>
    <li>- Port: 993(IMAP)/995(POP)</li>
    <li>- Protocol Selection: POP/IMAP</li>
    <li>- Compatibility: Gmail.</li>
</ul>
<br>
<p>
	<b>Note:</b> It is not recommended to use the accept all certificates option as it would not validate certificates for encryption.
</p>
<br>
<p>
	Once configured, we need to choose a group of Integria IMS in which we want the tickets of the emails of this account to be created and we edit the group:
</p>
<br>
<p>
	<b>People -> Access Control -> Group Management -> Edit the group that we want</b>
</p>
<br>
<span>
	<?php print_image("images/help/gmail5.png", false, false); ?>
</span>
<br><br>

<ul>
	In order for a user (external from Integrate IMS) to create a ticket through an email:
	<br><br>
	<li>
		<b>- User self-creation</b> Allows you to create a new Integria IMS user, Which will match the name of the email. This option must be enabled
	</li>
	<li>
		<b>- User access permissions to create tickets:</b> Allows the user to create the necessary permissions for ticket editing. This option must be enabled.
	</li>
	<li>
		<b>- Welcome message:</b> Send a welcome message to the created user. This option is optional.
	</li>
	<li>
		<b>- Ticket Status:</b> Allows you to choose the status of the created ticket. New is the default option.
	</li>
	<li>
		<b>- User type</b> It allows to choose the type of user that will be the created user. External user is the default option.
	</li>
	<li>
		<b>- Company:</b> It allows to select to which company the created ticket will belong. This option is optional.
	</li>
	<li>
		<b>- Specific profile:</b> Allows you to select the profile of the created user. External is the default option.
	</li>
	<li>
		<b>- Ticket type:</b> Select the type of ticket to which the ticket created will belong. This option is optional.
	</li>
	<li>
		<b>- Email Queue:</b> It must match with the name of the POP/IMAP configuration.
	</li>
</ul>
<br>
<p>
	<b>Gmail settings:</b>
	<p>
		You must enable the protocol to use (POP/IMAP) in the email account and in the case of using POP, allow it to delete the mails so that the tool can work correctly.
	</p>
</p>

<h1>
	Outlook: Allows only this setting:
</h1>
<br>
<p>
	SSL/TLS:
</p>
<br>
<ul>
	<li>
		<p>IMAP:</p>
		<span>
			<?php print_image("images/help/outlook4.png", false, false); ?>
		</span>
	</li>
	<li>				
		<p>POP:</p>
		<span>
			<?php print_image("images/help/outlook3.png", false, false); ?>
		</span>
	</li>
</ul>
<br>
<ul>
	<li>- Name: imap-mail.outlook.com / pop-mail.outlook.com</li>
    <li>- Port: 993(IMAP)/995(POP)</li>
    <li>- Protocol Selection: POP/IMAP</li>
    <li>- Compatibility: Outlook.</li>
</ul>
<br>
<p>
	<b>Note:</b> It is not recommended to use the accept all certificates option as it would not validate certificates for encryption.
</p>
<br>
<p>
	Once configured, we need to choose a group of Integria IMS in which we want the tickets of the emails of this account to be created and we edit the group:
</p>
<br>
<p>
	<b>People -> Access Control -> Group Management -> Edit the group that we want</b>
</p>
<br>
<span>
	<?php print_image("images/help/outlook5.png", false, false); ?>
</span>
<br><br>

<ul>
	In order for a user (external from Integrate IMS) to create a ticket through an email:
	<br><br>
	<li>
		<b>- User self-creation</b> Allows you to create a new Integria IMS user, Which will match the name of the email. This option must be enabled
	</li>
	<li>
		<b>- User access permissions to create tickets:</b> Allows the user to create the necessary permissions for ticket editing. This option must be enabled.
	</li>
	<li>
		<b>- Welcome message:</b> Send a welcome message to the created user. This option is optional.
	</li>
	<li>
		<b>- Ticket Status:</b> Allows you to choose the status of the created ticket. New is the default option.
	</li>
	<li>
		<b>- User type</b> It allows to choose the type of user that will be the created user. External user is the default option.
	</li>
	<li>
		<b>- Company:</b> It allows to select to which company the created ticket will belong. This option is optional.
	</li>
	<li>
		<b>- Specific profile:</b> Allows you to select the profile of the created user. External is the default option.
	</li>
	<li>
		<b>- Ticket type:</b> Select the type of ticket to which the ticket created will belong. This option is optional.
	</li>
	<li>
		<b>- Email Queue:</b> It must match with the name of the POP/IMAP configuration.
	</li>
</ul>
<br>
<p>
	<b>Outlook settings:</b>
	<p>
		You must enable the protocol to use (POP/IMAP) in the email account and in the case of using POP, allow it to delete the mails so that the tool can work correctly.
	</p>
</p>

<h1>
	Office365: Allows only this setting:
</h1>
<br>
<p>
	SSL/TLS:
</p>
<br>
<ul>
	<li>
		<p>IMAP:</p>
		<span>
			<?php print_image("images/help/office365_4.png", false, false); ?>
		</span>
	</li>
	<li>				
		<p>POP:</p>
		<span>
			<?php print_image("images/help/office365_3.png", false, false); ?>
		</span>
	</li>
</ul>
<br>
<ul>
	<li>- Name: outlook.office365.com is valid for both POP/IMAP</li>
    <li>- Port: 993(IMAP)/995(POP)</li>
    <li>- Protocol Selection: POP/IMAP</li>
    <li>- Compatibility: Office365.</li>
</ul>
<br>
<p>
	<b>Note:</b> It is not recommended to use the accept all certificates option as it would not validate certificates for encryption.
</p>
<br>
<p>
	Once configured, we need to choose a group of Integria IMS in which we want the tickets of the emails of this account to be created and we edit the group:
</p>
<br>
<p>
	<b>People -> Access Control -> Group Management -> Edit the group that we want</b>
</p>
<br>
<span>
	<?php print_image("images/help/office365_5.png", false, false); ?>
</span>
<br><br>

<ul>
	In order for a user (external from Integrate IMS) to create a ticket through an email:
	<br><br>
	<li>
		<b>- User self-creation</b> Allows you to create a new Integria IMS user, Which will match the name of the email. This option must be enabled
	</li>
	<li>
		<b>- User access permissions to create tickets:</b> Allows the user to create the necessary permissions for ticket editing. This option must be enabled.
	</li>
	<li>
		<b>- Welcome message:</b> Send a welcome message to the created user. This option is optional.
	</li>
	<li>
		<b>- Ticket Status:</b> Allows you to choose the status of the created ticket. New is the default option.
	</li>
	<li>
		<b>- User type</b> It allows to choose the type of user that will be the created user. External user is the default option.
	</li>
	<li>
		<b>- Company:</b> It allows to select to which company the created ticket will belong. This option is optional.
	</li>
	<li>
		<b>- Specific profile:</b> Allows you to select the profile of the created user. External is the default option.
	</li>
	<li>
		<b>- Ticket type:</b> Select the type of ticket to which the ticket created will belong. This option is optional.
	</li>
	<li>
		<b>- Email Queue:</b> It must match with the name of the POP/IMAP configuration.
	</li>
</ul>
<br>
<p>
	<b>Office365 settings:</b>
	<p>
		You must enable the protocol to use (POP/IMAP) in the email account and in the case of using POP, allow it to delete the mails so that the tool can work correctly.
	</p>
</p>

<h1>Others:</h1>
<ul>
	<li>
		- Encryption: We can configure the POP/IMAP server without encryption or with SSL/TLS, SSLv2, SSLv3 or STARTTLS.
	</li>
	<li>- Name: IP or DNS of the POP/IMAP server.</li>
	<li>- Port: Port on which the POP/IMAP server is listening.</li>
	<li>- User: User configured on the mail server.</li>
	<li>- Password: Password configured for the user indicated above.</li>
	<li>- Protocol: POP or IMAP</li>
	<li>- Compatibility: other</li>
	<li>
		- Accept all certificates: Click if you want to accept any certificate, even the self-signed ones.
	</li>
</ul>