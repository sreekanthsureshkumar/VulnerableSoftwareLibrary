<h1>Invoices</h1>
<p>
	<br>This section contains only the invoices of the system from the companies to which the user has access. The user will be able to perform searches, export those results to excel or PDF or display reports with the search data from these icons:
<br><br>
</p>

<p>
	<?php print_image("images/help/help_invoice1.png", false, false); ?>
</p>
<p>
	<br>The user will only have access to this section with "View CRM" permissions and the companies are linked to their name. They can also be viewed if they have that permission and the companies are associated with their base company (the company associated with that user's profile)..<br>
</p>
<p>
	<br>In order to modify the displayed companies, the user must have CRM editing permissions and be the owner of that company or be associated with their base company.

	<br>
</p>
<p>
	<br>If a user cannot view a company in this list, they must check again the assignment of permissions and profiles of that user and the information of the company to verify to which user it is assigned and/or to which base company it belongs:<br>
</p>

<p>
	<?php print_image("images/help/help_invoice2.png", false, false); ?>
</p>
<br>
<h2>Blocking, deleting and printing invoices</h2>
<br>
<p>
	In the last column of the invoice list there are three options with the following icons to print in PDF, block the invoice or delete it:
<br>
</p>
<p>
	<?php print_image("images/help/help_invoice3.png", false, false); ?>
</p>
<p>
	<br>ATTENTION: If you delete an issued invoice, it will leave an "empty number" in the sequence, which may have accounting consequences, depending on your legislation. If you deactivate or enter an exception, you can then create an invoice with the invoice number to be deleted, but be especially careful with this option.<br>
</p>
<p>
	To customize the appearance of the invoice, use the configuration options in the CRM section.
<br>
</p>
