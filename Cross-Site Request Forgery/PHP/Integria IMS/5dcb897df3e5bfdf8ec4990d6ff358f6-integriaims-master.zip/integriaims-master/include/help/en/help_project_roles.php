<h1>Project and task roles</h1>

<p>
The project manager's profile allows access to all the
project options, even though the user was not the owner.
For security reasons, the project manager's role is enabled
only for the administrator in this section.<br><br>
Assigning an user to a task will give him access to the
task project with the role selected if he was not have
access yet.<br>
</p>
