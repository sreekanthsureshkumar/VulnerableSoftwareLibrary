<h1>Custom reports:</h1>
<p>
	<ul>
		To view personnel reports the following profile is necessary:
		<li>.-User admin.</li>
		<li>.-View reports.</li>
	</ul>
</p>
<p>
	These reports allow the user to create reports using a sql phrase, as below:
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_1.png", false, false); ?>
</p>
</br>
<p>
	Viewable in html, pdf or csv.
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_2.png", false, false); ?>
</p>
</br>
<p>
	An html example:
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_3.png", false, false); ?>
</p>
</br>

<p>
	Create programmed reports to be sent by email (Enterprise only).
</p>
<br>
<p>
	<?php print_image("images/help/inf_cu_4.png", false, false); ?>
</p>
</br>