<h1>Dashboard</h1>
<br>
<p>
	The dashboard is a view that allows to see at a glance the tickets grouped in different ways and have direct access to the custom searches created. This is the default screen when clicking on Tickets in the main menu.<br>

	All the information shown here is a "summary" and clicking on it will take the user to the detailed view of tickets, with the selection or search determined by the type of grouping chosen: for example, tickets from a specific owner, a specific group or a specific creator:<br><br>
</p>

<?php print_image("images/help/help_dashboard1.png", false, false); ?>
<br><br>
<p>
<strong>Personalized searches</strong><br>

In the upper part there is a box (that in this case, if it has not been configured yet, would be empty). Custom searches are placed here, which are configured in the detailed view of tickets and serve as a "quick link" to these searches.

</p>

<?php print_image("images/help/help_dashboard2.png", false, false); ?>
