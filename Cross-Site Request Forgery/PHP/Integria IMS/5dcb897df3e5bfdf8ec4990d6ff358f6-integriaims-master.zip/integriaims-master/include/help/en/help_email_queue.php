<h1>Email queue management</h1>
<p>
	<br>They are used for the creation and management of tickets by email. To be able to use this feature it is necessary to have a mail account configured in the “Mail Settings” section of the console's general setup. Integria will use this outgoing account for email ticket management.

	The configuration parameters for email queues are the following:

	<li>Autocreate users: automatic creation of new users in the system when an email is received.</li>
	<li>Grant user access: allows the access for new users so they can enter the application using their username/password.</li>
	<li>Send welcome email: sends a welcome email upon the creation of a new user.</li>
	<li>Default status: status with which the ticket will be created.</li>
	<li>User type: type of user that will be created automatically.</li>
	<li>Default company.</li>
	<li>Default user profile: the profile indicated will be associated with the new user for the corresponding group.</li>
	<li>Default ticket type.</li>
	<li>Email queue: emails sent to the email addresses specified in this section will be used for the creation and updating of tickets. Integria uses the account configured in the mail setup, so the addresses that we put here must be the same addresses or aliases that we define in the mail server itself. This field allows you to configure several addresses or regular expressions, one in each line. For example:<br><br>
		support@integria.com <br>
		.*@otherdomain.com <br><br></li>
		
		With this configuration, all emails that reach the address support@integria.com and all those with the format xxxx@otherdomain.com as for example: user1@otherdomain.com, superadmin@otherdomain.com, etc. will be used for the management of tickets by email using the defined parameters.

	<li>Welcoming email: sends a welcome message to all new users when an account is created. This text field accepts the following macros:
	_password_: this macro will change for the default password assigned upon user creation.</li><br>
</p>

<h1>Ticket management via email</h1>
<p>
	<br>Integria allows creating and updating tickets by sending emails.<br><br>
	Depending on the email client used, the email format may differ. Integria's email management has been validated on the following mail clients: Evolution, Gmail, Outlook and Mail. <br>
	Ticket and WU creation via email uses the same ACL principles as the GUI.  <br>
	Ticket management using email is based on managing email queues, configured for each existing group in Integria IMS. You are required to configure email parameters as specified in the “Email setup” section.

	Let's suppose you have the following email address enabled for mail reception: support@integria.com and you've configured a group's “Email Queue” parameter with the following information: support@integria.com y configurado el parámetro 'Cola de emails de un grupo con el correo support@integria.com. We'll send an email with the following data:<br>

<li>From: user@company.com</li>
<li>To: support@integria.com, myboss@company.com</li>
<li>CC: admin1@company.com, admin2@company.com</li>
<li>Subject: Another problem with the servers</li>
<li>Body: We are having a big problem with our servers!</li>
<li>Attachment: screen1.png, screen2.png</li><br>

<li>Once the email has reached the inbox at suppor@integriaims.com, it'll be checked for correspondance with any adress configured in the parametere 'Email queues'.
<ul><li>If it can't find any correspondance with 'Email queues', the message is discarded.
<li>If it finds a correspondance with 'Email queues' then the default parameters configured for that queue will be used to manage the ticket (default ticket status, ticket type, associated company… etc.)</li></ul>
<li>If it coincides with a valid address, the application will process the message. At this point two things can happen:
<ul><li>The email doesn't correspond to any current tickets. In this case a new ticket will be created.
<li>The email corresponds to a previously created ticket on the system. In this case a new WorkUnit will be created and ticket data will be updated.</ul></li><br>
<li>In order to create a ticket the following parameters need to be configured:
<ul><li>Author: this will correspond to the user whose address was in the “FROM” field of the message. If the user doesn't exist, it'll be created (only if this option is enabled in the 'Email queues' configuration).
<li>Editor: this will use the same user corresponding to the “FROM” field of the message.
<li>Group: the group that corresponds to the email queue.
<li>Owner: the user related by default to this email queue.
<li>Title: the “Subject” field from the email.
<li>Description: the email body.
<li>Email notifications: In this field of a ticket all email addresses apparing on the “TO” and “CC” fields that don't correspond with the address found for the email queue. In this example the following addresses will be used: admin1@company.com, admin2@company.com, myboss@company.com
<li>Ticket files: any attachments on the email will be added.</li></ul>
<li>If the ticket exists on the system, then the content of the email body will be added as a WorkUnit and necessary modifications on ticket status will be made.</li>
	<br>
The following image summarizes management flow on email queues:
</p>
<p>
	<?php print_image("images/help/gestionticketsemail.png", false, false); ?>
</p>
