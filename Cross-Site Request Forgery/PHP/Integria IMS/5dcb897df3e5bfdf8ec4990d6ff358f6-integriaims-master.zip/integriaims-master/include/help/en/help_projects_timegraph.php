<h1>Time graph</h1>
<p>
	Similar to the graph that shows time per person and project, this graph represents each user's time inputs per task on this project, in a proportionate and scaled wat. It's interactive, and by hovering the mouse over this graph an user can obtain more information from it.
<p>
	<?php print_image("images/help/project13.png", false, false); ?>
</p>