<h1>Max. data limit size</h1>

<p>
This is the maximum limit for the data in Integria IMS. This is used for data such as attached files.
</p>
