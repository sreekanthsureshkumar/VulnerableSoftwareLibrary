<h1>Tickets Inventory</h1>
<p>
	The <b>linked tickets</b> tab indicates the inventory item what tickets have been applied to it, along with the status for those tickets. We can click on any of them to directly access their information.
</p>
<p>
	<?php print_image("images/help/inventory10.png", false, false); ?>
</p>