<h1>Work hours</h1>
<p>
	The details for total hour inputs (per task) for each member show each user's actions, the date on which it was performed, the description, the task or subtask and a series of attributes shown as icons.
	</br>
	</br>
	The head of project can “certify” (Block icon) a WU in such a way that the user cannot modify or delete it. The person who reported this WU can see that WU, modify it (if it's not certified) and delete it.
</p>
<p>
	<?php print_image("images/help/project16.png", false, false); ?>
</p>