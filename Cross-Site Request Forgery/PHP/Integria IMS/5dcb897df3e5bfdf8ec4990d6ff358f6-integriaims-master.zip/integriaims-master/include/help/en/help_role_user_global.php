<h1>Global task assignment</h1>
<p>
	The section for Global Task Assignment allows the users to see the tasks they have assigned as single users, their roles in the task, the WUs inputted to it and total WUs for the task.
	</br>
	</br>
	Plus, from here we can quickly assign (“in bulk”) specific tasks to a single user.
	</br>
	</br>
	This section is especially useful for administrators because on it they can see if an user has inappropriate tasks assigned, whether it be globally or by noticing that the user hasn't inputted any hours into the task. Administrators can also use this to confirm that an user's rol in the task is the correct one. Here we can “expel” an user from a task with just a single click.
</p>
<p>
<?php print_image("images/help/project26.png", false, false); ?>
</p>