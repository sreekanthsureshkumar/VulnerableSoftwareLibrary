<h1>Custom filters</h1>
<br>
<p>
Custom filters can be LOADED and SAVED for reusing them.<br><br>

<p>
<?php print_image("images/help/help_custom_search2.png", false); ?>
</p>

<br><br>

<p>
To create a custom filter, first do a complex search/filtering using the filters in the ticket detail view, run the search and make sure it shows the results you expect. Then click on 'Add custom filter', type a name for that filter and press 'Save custom filter'.

</p>

<?php print_image("images/help/help_custom_search1.png", false); ?>

<br><br>

From now on, it will be possible to load that filter, displaying the custom filters box and choosing in the combo selector the filter previously saved. In the dashboard, a link to the custom filter will now appear.
