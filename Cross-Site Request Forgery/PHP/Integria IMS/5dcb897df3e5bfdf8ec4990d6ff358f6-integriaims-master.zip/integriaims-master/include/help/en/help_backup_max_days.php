<h1>Maximum days of backups</h1>

<p>
The backups older than the days specified will be deleted.
If the value is 0, the data never will be deleted.
</p>
<p>
Default value: 30.
</p>