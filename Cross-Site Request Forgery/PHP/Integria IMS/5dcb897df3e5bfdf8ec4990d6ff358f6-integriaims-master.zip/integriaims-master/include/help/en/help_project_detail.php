<h1>General project view</h1>
<p>
	It's the main overview for a project. From here we can edit some general project details and view a global report on the project's status.
</p>
<p>
	<?php print_image("images/help/project11.png", false, false); ?>
</p>