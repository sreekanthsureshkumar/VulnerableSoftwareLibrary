<h1>Relationships Inventory</h1>
<p>
	The Relationships tab shows the other items related to a primary item. New items can be related, users only need to choose it from the combination and link it like we show below. This way other items apart from a fathering item can be interrelated.
</p>
<p>
	<?php print_image("images/help/inventory8.png", false, false); ?>
</p>