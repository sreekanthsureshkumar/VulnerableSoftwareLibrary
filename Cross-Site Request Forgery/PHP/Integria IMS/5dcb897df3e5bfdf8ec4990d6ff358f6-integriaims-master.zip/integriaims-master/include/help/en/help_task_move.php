<h1>Move task</h1>
<p>
	It's possible to move a task from one project to another. In order to do this, navigate the project tree, find the project and the task that needs to be moved. Once there, choose the option “move task” and select the destined project. If what's needed is to change the “parent” for a task, edit its properties and change the “Parent” option. WUs for the task will be linked to the parent, so if a task moves to another project or parent task, it doesn't matter, since WUs are always task-related, not project-related.
</p>
<p>
	<?php print_image("images/help/project20.png", false, false); ?>
</p>