<h1>Interactive Gantt Graph</h1>
<p>
	Shows project information, mixing real inputs (in red) with the task's progress (in green) and original planning (blue). It also shows dependencies and milestones.
<p>
	<?php print_image("images/help/project14.png", false, false); ?>
</p>