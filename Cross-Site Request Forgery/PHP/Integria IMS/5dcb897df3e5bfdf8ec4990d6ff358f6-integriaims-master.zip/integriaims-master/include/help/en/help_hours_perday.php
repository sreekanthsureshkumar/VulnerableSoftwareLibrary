<h1>Work hours per day</h1>

<p>
This number represents the hours of a normal laboral working day, usually it's 8 hours.
</p>
