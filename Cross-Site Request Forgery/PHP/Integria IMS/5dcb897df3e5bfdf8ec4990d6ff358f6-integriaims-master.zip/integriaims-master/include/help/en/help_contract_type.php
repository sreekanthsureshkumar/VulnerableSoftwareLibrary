<h1>Contract types</h1>
</br>
<p>
	Contract types allow us to create contracts with custom fields associated with these types.
</p>
</br>
<p>
	<b>To create a contract type there are two options:</b>
	<ul>
		<li>- The button below the contract types list.</li>
		<?php print_image("images/help/contract_type7.png", false, false); ?>
		<br>
		<li>- The ‘Create contract type’ option that appears in the sidebar.</li>
		<br>
		<?php print_image("images/help/contract_type1.png", false, false); ?>
	</ul>
</p>
</br>
<p>
	<b>Definable fields in contract type creation/editing:</b>
	<ul>
		<li><b>- Name:</b> obligatory and must not be repeated, i.e. no two contracts may share a name. This is the field that is displayed in ‘create/edit contracts’ in order to select the type.</li>
		<li><b>- Description:</b> optional field.</li>
	</ul>
</p>
</br>
<p>
	<?php print_image("images/help/contract_type8.png", false, false); ?>
</p>
</br>
<p>
	Actions applicable to a type are:
	<ul>
		<li>- Add custom fields.</li>
		<li>- Update information (name, description, template, group).</li>
		<li>- Delete.</li>
	</ul>
</p>
<p>
	To update, click on the wrench icon to go to edit view. You can modify any section from here.
</p>
</br>
<p>
	To delete, click the trashcan icon. You’ll be asked to confirm. Once the action is performed it is definitive.
</p>
</br>
<p>
	To add more custom fields click the ‘add’ icon.
</p>
</br>
<p>
	<?php print_image("images/help/contract_type2.png", false, false); ?>
</p>
</br>
<p>
	<h1>Custom fields</h1>
</p>
</br>
<p>
	<b>In field creation you can define:</b>
</p>
</br>
<p>
	<ul>
		<li>- Name: obligatory field. Doesn’t have to be unique.</li>
		<li>- Display in contract list: if you select this option it will appear as a column in the contract list.</li>
		<ul>
			<li>- Text type: in the “create/edit contract” form an input field will be displayed.</li>
			</br>
			<li>- Textarea: in the “create/edit contract” form a text area field will be displayed.</li>
			</br>
			<li>- Combo box: in the “create/edit contract” form a select form will be displayed where you can see all available options.</li>
			</br>
			<li>- Linked: interrelated custom fields.</li>
            <ul>
				<li>e.g., TYPE, MAKE, MODEL</li>
				<li>--First, create the TYPE field. In this case, no parent field is selected because it is the first in hierarchy. Values are separated by commas.</li>
				<br>
				<?php print_image("images/help/contract_type9.png", false, false); ?>
				</br>
				<li>--Then create the MAKE field. In this case, select the parent field TYPE. After, fill out the field with the values separated by commas as in the previous example. Because this field has a parent, the values must be associated with it. To do this, first include the parent field value separated by |</li>
				<br>
				<?php print_image("images/help/contract_type10.png", false, false); ?>
				</br>
				<li>--Next, create MODEL field. Select the parent MAKE and input the values.</li>
				<br>
				<?php print_image("images/help/contract_type11.png", false, false); ?>
				</br>
			</ul>
            </br>
			<li>- Numeric: in the “create/edit contract” form a numeric field will be displayed.</li>
			<br>
			<li>- Date: in the “create/edit contract” form a date field will be displayed.</li>
			<br>
			<?php print_image("images/help/contract_type4.png", false, false); ?>
			</br>
		</ul>
	</ul>
</p>
<br>
<p>
	A list with all the fields you created will be displayed.
</p>
<br>
	<?php print_image("images/help/contract_type3.png", false, false); ?>
</br>
</br>
<p>
	<b>The list is made up of the following columns:</b>
</p>
</br>
<p>
	<ul>
		<li>Field name.</li>
		<li>Field type.</li>
		<li>Parent: exclusive to linked types as these can refer to a parent.</li>
		<li>Value: exclusive to combo box and linked types as these have a selectable default value.</li>
		<li>Actions: allow the field to be edited or deleted.</li>
	</ul>
</p>

<h1>Practical Applications of contract Types</h1>
<br>
<p>
	Contract types allow you to create contracts flexibly, i.e., when you select a type, the custom fields will appear and you can generate work orders using the template. E.g.
</p>
</br>
<p>
	Select contract type:
</p>
</br>
	<?php print_image("images/help/contract_type5.png", false, false); ?>
</br>
<p>
	All the custom fields will appear:
</p>
</br>
<p>
	Fill out the fields and create the contract:
</p>
</br>
	<?php print_image("images/help/contract_type6.png", false, false); ?>
</br>
<p>
    Keep in mind that you can now search for contracts for the specific type that we have chosen and their associated custom fields.
</p>
</br>
</br>


