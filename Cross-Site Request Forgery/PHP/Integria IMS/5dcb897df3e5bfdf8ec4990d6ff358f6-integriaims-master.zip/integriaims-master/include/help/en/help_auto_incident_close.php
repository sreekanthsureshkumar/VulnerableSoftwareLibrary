<h1>Auto ticket close</h1>

<p>
Defines a limit (in DAYS), where Integria IMS automatically will close the tickets without any kind of update in XX days  (this limit is configured in the setup option "Auto ticket close" and its in DAYS).

Ticket owner is warn about this by mail.

<br><br><small>Set to 0 to disable this functionality.</small>
</p>
