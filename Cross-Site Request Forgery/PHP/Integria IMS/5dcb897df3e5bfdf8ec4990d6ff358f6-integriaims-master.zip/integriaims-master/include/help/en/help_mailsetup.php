<h1>SMTP mail settings:</h1>

<h1><b>Gmail:</b></h1>
	<br>
	<p>
		<u>No encryption:</u>
	</p>
	<p>
		Gmail does not allow us to send emails without encryption, so at least we must configure the encryption as STARTTLS, which can be used in ports 25 or 587.
	</p>
	<br>
	<p>
		<u>With encryption:</u> (STARTTLS)
	</p>
	</p>
		<span>
			<?php print_image("images/help/gmail1.png", false, false); ?>
		</span>
		<br><br>
		<p>
			As we can see in the picture, we configure:
		<p>
			<ul>
		 		<li>- Encryption method: STARTTLS</li>
				<li>- SMTP Host: smtp.gmail.com</li>
				<li>- Port: 587 (25 could also be used)</li>
			</ul>
		</p>
		<br>
		<p>	
			SSL and different versions:
		</p>
		<span>
			<?php print_image("images/help/gmail2.png", false, false); ?>
		</span>
		<br><br>
		<p>	
			As we can see in the previous picture, we configure:
		</p>
		<p>
			<ul>
				<li>- Encryption method: SSL/TLS.</li>
				<li>- SMPT Host: smptp.gmail.com.</li>
				<li>- Port: 465.</li>
			</ul>
		</p>
		<br>
	<p>	
		Note: With the test button, we can test if our configuration is valid.
	</p>
<p>	
<h1><b>Outlook:</b></h1>
	<br>
	<p>
		<u>No encryption:</u>
	</p>
	<p>
		Outlook does not allow us to send emails without encryption, so at least we must configure the encryption as STARTTLS, which can be used in ports 25 or 587.
	</p>
	<br>
	<p>
		<u>With encryption:</u>(STARTTLS:)
	</p>
	<span>
		<?php print_image("images/help/outlook1.png", false, false); ?>
	</span>
	<br><br>
	<p>
		As we can see in the previous picture,  we configure:
	</p>
	<ul>
		<li> - Encryption method: STARTTLS </li>
		<li> - SMTP Host: smtp-mail.outlook.com </li>
		<li> - Port: 587 (25 could also be used) </li>
	</ul>
	<br>
	<p>
		SSL and different versions:
	</p>
	<p>
		It does not allow this type of encryption, only STARTTLS.
	</p>
	<br>
	<p>	
		<ul>
			Note:
			<li>- With the test button, we can test if our configuration is valid.</li>
			<li>- Outlook does not allow to use users from other mail services , only their own ones , so it is necessary to specify the same mail that is used for the SMTP configuration.</li>
		</ul>
	</p>
	<span>
		<?php print_image("images/help/outlook2.png", false, false); ?>
	</span>
<h1><b>Office365:</b></h1>
	<br>
	<p>
		<u>No encryption:</u>
	</p>
	<p>
		Outlook does not allow us to send emails without encryption, so at least we must configure the encryption as STARTTLS, which can be used in ports 25 or 587.
	</p>
	<br>
	</p>
		<u>With encryption:</u>(STARTTLS)
	</p>
	<span>
		<?php print_image("images/help/office365_1.png", false, false); ?>
	</span>
	<br>
	<p>
		As we can see in the previous picture, we have:
	</p>
	<ul>
		<li> - Encryption method: STARTTLS</li>
		<li> - SMTP Host: smtp.office365.com</li>
		<li> - Port: 587 (25 could also be used)</li>
	</ul>
	<br>
	<p>	
		SSL and different versions:
	</p>
	<p>	
		It does not allow this type of encryption, only STARTTLS.
	</p>
	<br>
	<ul>
		Note: 
		<li>- With the test button, we can test if our configuration is valid.</li>
		<li>- Office does not allow to use users from other mail services , only their own ones , so it is necessary to specify the same mail that is used for the SMTP configuration.</li>
	</ul>
	<span>
		<?php print_image("images/help/office365_2.png", false, false); ?>
	</span>
<h1><b>Others:</b></h1>
	<br>
	<ul>
	    <li>  - Encryption: We can configure the mail server without encryption or with SSL/TLS, SSLv2, SSLv3 or STARTTLS.</li>
	    <li>  - Name: DNS name or IP address of the mail server.</li>
	    <li>  - Port: Port on which the mail server is listening.</li>
	    <li>  - User: User configured on the mail server.</li>
	    <li>  - Password: Password configured for the user indicated above.</li>
	</ul>
</p>
