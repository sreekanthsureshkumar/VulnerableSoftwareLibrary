<h1>Task tracking</h1>
<p>
	Integria IMS performs a task tracking on practically each section or information element that is subject to changes. In this case the tasks registers all open, close, change and addition operation; whether that's in the form of a file or attachment.
</p>
<p>
	<?php print_image("images/help/project22.png", false, false); ?>
</p>