<h1>Contracts</h1>
<p>
	Linked to a company, they carry important data such as economic quantities or start/end dates. It's especially useful to search for contracts that are about to expire, or know other details.
</p>
<p>
	<?php print_image("images/help/company6.png", false, false); ?>
</p>
<p>
	In the <b>Enterprise</b> version, there is access controls to a company's contracts. Those who can access them are users related to the company, and users belonging to the parent company.
</p>