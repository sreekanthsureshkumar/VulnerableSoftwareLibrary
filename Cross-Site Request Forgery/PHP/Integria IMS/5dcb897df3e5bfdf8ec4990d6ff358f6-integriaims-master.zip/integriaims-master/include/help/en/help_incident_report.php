<h1>Incident reports:</h1>
<p>
	<ul>
		You need the following profile to view these or support reports:
		<li>.-View incidents and belong to the correct ticket group.</li>
		<li>.-View reports.</li>
	</ul>
</p>
<p>
There are three types of reports:
	<h1>Support reports:</h1>
</p>
<br>
<p>
	<?php print_image("images/help/inf_su_1.png", false, false); ?>
</p>
<br>
<p>
	To create this kind of report Integria IMS uses custom searches created in the ticket search section. Select the type of report from the scrolldown menu, to see a form with the following options: 
</p>
<br>
<p>
	<?php print_image("images/help/inf_su_2.png", false, false); ?>
</p>
<br>
<p>
	<ul>
		<li>Show all statistics: A comprehensive view of all tickets found with the search term(s):
			<ul>
				<li>Ticket groups graph: Percentage of groups belonging to said ticket.</li>
				<li>Max ticket creator graph: as a percentage.</li>
				<li>Assigned users graph: Users assigned to a ticket as a percentage.</li>
				<li>Ticket statistics: Detailed ticket information.</li>
				<li>Groups/time graph.</li>
				<li>SLA compliance graph related to tickets included in the custom search.</li>
				<li>List of tickets classified according to status.</li>
				<li>List of tickets classified according to priority. </li>
				<li>Graph of most active users.</li>
				<li>Graph of the top five most active tickets.</li>
				<li>Comparative graph showing the relation of open to closed tickets.</li>
				<li>History of open and closed tickets.</li>
				<li>Ticket activity calendar.</li>
			</ul>
		</li>
		<li>Show ticket list: all tickets included in the custom search.</li>
	</ul>
	<br>
	<p>
		<?php print_image("images/help/inf_su_3.png", false, false); ?>
	</p>
	<br>
	<br>
	<p>
		<?php print_image("images/help/inf_su_4.png", false, false); ?>
	</p>
	<br>
	<br>
	<p>
		<?php print_image("images/help/inf_su_5.png", false, false); ?>
	</p>
	<br>
</p>
<h1>Single ticket: </h1>
<p>
	To create this type of report an auto-complete form will appear if the search term is the ID or ticket title. You'll see a detailed report of the ticket.
</p>
<br>
<p>
	<?php print_image("images/help/inf_su_6.png", false, false); ?>
</p>
<br>
<br>
<p>
	<?php print_image("images/help/inf_su_7.png", false, false); ?>
</p>

<h1>Resolution:</h1>
<p>This report is based on already closed tickets. It will be possible to filter by creator user of the ticket, company of the creator user and date. We have the option of displaying the report on screen or exporting it to PDF or CSV.
</p>
<br>
<p>
	<?php print_image("images/help/filtro_resolucion.png", false, false); ?>
</p>
<br>
<br>
<p>
	The information displayed is as follows:
	<ul>
	<li>Ticket identifier</li>
	<li>Ticket type</li>
	<li>Company of the user who created the ticket</li>
	<li>Editor User</li>
	<li>Creator User</li>
	<li>User who closes the ticket</li>
	<li>Number of people involved</li>
	<li>Priority</li>
	<li>Time elapsed until the ticket is closed</li>
	<li>Time the ticket has spent in New status</li>
	<li>Time the ticket has been in status other than Assigned or Closed</li>
	<li>Total time spent on the ticket. Summation of assigned time in commentaries.</li>
	
	</ul>
</p>
<br>
<br>
<p>
	<?php print_image("images/help/inf_res.png", false, false); ?>	
</p>
