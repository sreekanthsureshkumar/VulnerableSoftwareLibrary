<h1>Project schedule map / Graph of time per project</h1>
<p>
	This option allows us to see in a visual way, for a specific person, in a specific time interval, which projects he or she has dedicated time to, and show it at a scale.
</p>
<p>
	<?php print_image("images/help/project8.png", false, false); ?>
</p>