<h1>Maximum days of sessions data</h1>

<p>
The sessions older than the days specified will be deleted.
If the value is 0, the data never will be deleted.
</p>
<p>
Default value: 7.
</p>
