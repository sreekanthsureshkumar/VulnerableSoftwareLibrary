<h1>Maximum days of work units</h1>

<p>
The work units that belong to disabled projects and are older than
the days specified will be deleted.
If the value is 0, the data never will be deleted.
</p>
<p>
Default value: 0.
</p>
