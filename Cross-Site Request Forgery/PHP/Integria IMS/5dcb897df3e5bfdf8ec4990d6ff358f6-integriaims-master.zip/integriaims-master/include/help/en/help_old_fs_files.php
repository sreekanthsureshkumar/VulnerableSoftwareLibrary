<h1>Maximum days of files of the file sharing section</h1>

<p>
The uploaded files older than the days specified will be deleted.
If the value is 0, the files never will be deleted.
</p>
<p>
Default value: 7.
</p>