<h1>User import from CSV</h2>

<p>
    A CSV file stores tabular data (numbers and text) in plain-text form. The columns are separated by commas:
</p>

</br>

<p>
    <strong>
        &emsp;id_usuario
    </strong>
</p>

</br>
<p>
    <strong>
        &emsp;password
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;real_name
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;email
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;telephone
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;description
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;avatar
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;disabled
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;id_company
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;num_employee
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;enable_login
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Custom fields:
    </strong> 
            must previously exist in your Integria IMS system and must be indicated in order, 
</p>
<p>
            &emsp;being able to choose a value, or in case of not wanting to give them value, blank space.
</p>

<h2>Example</h2>

<p>
    "user,pass_user,alberto,alberto@gmail.com,012345678,new user,people_1,0,3,222,1,Integria,20”
</p>
