<h1>Company import from csv</h2>

<p>
	The import can be done by an export made in Integria (in which the structure as it is generated in the system shoud not be manipulated) and it can be done by a CSV file.
</p>

</br>

<p>
    For the first case the input file will be the same as the one we previously exported, so it does not impose problems when processing the CSV.
</p>

</br>

<p>
    For the second case a series of parameters must be entered in order, some required and some not, being able to choose empty values for the latter. The fields will be the following for the logical order established by the tool:
</p>

</br>

<p>
    <strong>
        &emsp;Name
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Adrress
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Fiscal id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Country
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Website
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Comments
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id company role
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Id parent
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Manager
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Last update
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Payment conditions
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Custom fields:
    </strong> 
            must previously exist in your Integria IMS system and must be indicated in order, 
</p>
<p>
            &emsp;being able to choose a value, or in case of not wanting to give them value, blank space.
</p>

<h2>Example</h2>

<p>
    "copmany test,,,Spain,,,,,admin,0000-00-00 00:00:00,,Integria,20”
</p>

</br>