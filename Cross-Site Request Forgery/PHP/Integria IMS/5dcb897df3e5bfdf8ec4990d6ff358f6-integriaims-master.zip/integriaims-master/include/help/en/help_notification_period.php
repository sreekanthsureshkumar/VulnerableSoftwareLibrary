<h1>Notification period</h1>

<p>
This is the minimun time between two consecutive email notifications for the SLA warning reason. For example if your SLA parameter for notification by inactivity is configured to warn you each 2 hours, and notification period is set to 24hr, you don't receive anything in an interval of 24hr since the first notification. This is a global parameter.
</p>
