<h1>Tracking Inventory</h1>
<p>
	The <b>Tracking</b> tab shows changes that take place on the inventory item such as owner changes, if an item type is assigned, fathering items, etc.
</p>
<p>
	<?php print_image("images/help/inventory11.png", false, false); ?>
</p>