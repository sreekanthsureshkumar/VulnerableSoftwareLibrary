<h1>Importing inventory data from a CSV file</h1>
<p>
	There is an option to import inventory data from a CSV file. To do this, the file has to be loaded with a header and a line per inventory object
</p>
<p>
	Name, Owner, Parent ID, ID Item type, Companies, Manufacturer ID, Contract ID, Status, Receipt date, Issued date, Description, Field1 for item type,…,FieldN for item type.
	The header must be in the first row of our CSV and must contain at least the name column since the name of the inventory object must exist.
</p>
</br>
<p>
	<b>Let’s have a look at the columns to be added:</b>
	</br>
	<ul>
		<li>.- <b>name</b> As we’ve said previously, it has to appear in our CSV, since inventory objects cannot be created without a name, we also need to consider the setup option that allows you to have names of duplicated inventory objects.</li>

		<li>.- <b>owner</b> This column collects ids of the users who are owners of the object, which must exist in the bbdd, if this column is not added, the value entered by default will be empty.</li>

		<li>.- <b>id_parent</b> The id of the parent inventory object will be in this column, which must exist in the bbdd. By default it is 0.</li>

		<li>.- <b>id_manufacturer</b> The id of the companies to which each inventory object belongs will be in this column, therefore these companies must exist in the bbdd. By default it is 0.</li>

		<li>.- <b>id_contract</b> the contract id to which each inventory object belongs will be in this column. By default it is 0.</li>

		<li>.- <b>status</b> the four state types that exist can only be collected in this column and therefore it will not accept any value different from (new, inuse, unused, issued).</li>

		<li>.- <b>receipt_date</b> the date of receipt will be in this column and it must have a valid date format.</li>

		<li>.- <b>issue_date</b> the date of use will be in this column and it must have a valid date format.</li>

		<li>.- <b>description</b> the description of the inventory object will be here. By default, it will be empty.</li>
		
		<li>.- <b>public</b> It will only admit value 0 or 1 depending on whether it’s private or not. By default 1</li>
		<li>.- <b>id_company</b> There might be one or several associated companies, therefore we will introduce the ids as follows : [ id1 . id2 .id3 . id4 ] It’s quite important to use full stops here</li>

		<li>.- <b>associated_user</b> There might be one or several associated users, therefore we will introduce the ids as follows: [ id1 . id2 .id3 . id4 ]  It’s quite important to use full stops here.</li>

		<li>.- <b>id_object_type</b> the id of the type of objects which must exist in the bbdd will be in this column. By default 0.</li>
	</ul>
</p>
</br>
<p>
	The rest of the columns to be added will belong to the custom fields of a type of object; in which we can find four types of different fields, which must respect the limitations of these fields:
	</br>
	<ul>
		<li>.- <b>Fields of text type:</b> It has no limitations.</li>

		<li>.- <b>Fields of numeric type:</b> it only allows numbers, therefore the column of this field should only contain numbers.</li>

		<li>.- <b>Fields of combo type:</b> it allows a list of words, therefore the characters to be entered in this column can only be those that are included in that list.</li>

		<li>.- <b>Fields of external type</b> Fields of external type: These fields allow you to associate external tables to introduce the values, the existence of ​such table and its references will be validated.</li>
	</ul>
</p>
</br>
<p>
	<b>Order for completing fields:</b>
	<ul>
		<li>name, creator, parent ID, Object type ID, companies, company ID, contract ID, status, receive date, issue date, description.</br></br>
			<b><i>E.g:</i></b></br>
			<pre>
				NewInventory,admin,25,,Company1_Id::Company2_Id,2,3,new,2016/10/09,,
 
						name         = NewInventory
						creator      = Admin
						parent ID    = 25
						object ID    = leave blank.
						companies    = 20::30
						company ID   = 2
						contract ID  = 3
						status       = new
						receive date = 2016/10/09
						issue date   = leave blank.
						description  = leave blank.
			</pre>
			<br>
			<p>
				As in the example, complete all fields necessary for an object, leaving the others unfilled. Obligatory fields are name, status and receive date.
			</p>
		</li>
	</ul>
	</br>
	<ul>
		<b>To introduce personalized fields, keep in mind</b>
		<li>.- To introduce an object ID it should already exist in the database.</li>
		<li>.- Introduce as many fields as the object has.</li>
		</br>
		<b><i>E.g:</i></b></br>
		<pre>
			NewInventory,admin,,1,20::30,,,new,2016/10/09,,inventory object description,1,pr1,pr2,pr3,pr4,pr5,pr6,pr7,1000,pr8,pr9,,
							name        = NewInventory
							creator     = Admin
							parent ID   = No tiene padre por lo cual lo dejamos vacio
							Object ID   = 1
							companies   = 20::30
							company ID  = no company associated, so leave blank
							contract ID = no contract associated, so leave blank
							status      = new
							recibe date = 2016/10/09
							issue date  = leave blank
							description = inventory object description
                Other fields which appear are personalized fields with the object typ
		</pre>
	</ul>
</p>
</br>
<p>
	<?php print_image("images/help/import_csv.png", false, false); ?>
</p>
</br></br>
<p>
	As we see in the image, the ordered columns are shown but it is not necessary to maintain a specific order, in this csv we will introduce two objects, (test and test2) in which we’ll introduce all the fixed columns up to public, it is only necessary to enter the name, the rest depends on whether you want to fill in or not. When no columns are shown, the default value will be entered, only when you want to enter the custom fields of an object type then it will be necessary to enter the column id_object_type to find out what type of object these custom fields belong to.
</p>
</br>
<p>
	In the image, the column (Field text) has custom fields, these fields belong to the id of object 18 but it is not necessary to enter all the columns of the fields, which means that if your object type has 8 custom fields and you just want to consider two of them, you will only put the columns of those two. If it’s necessary to call them exactly the same as the name of the field because your custom field has that name, for example our image is called Field text because my custom field has that name, if I was to put “Fieldtext1” (as it is not called exactly as my custom field) then it would cause an error.
</p>