<h1>Visibility management</h1>
<br>

<?php print_image("images/help/help_visibility1.png", false); ?>
<br><br>
<p>
<ul>
	This option allows you to "hide" certain parts of Integria from user groups. This is an Enterprise feature. You can configure, for each section and group of users, the following levels of visibility:<br><br>
	<li>Hidden: It will not be shown to anyone in that group.</li>
	<li>Full: Users with permissions in the specified group will have full access to the section.</li>
</ul>
</p>

<p>
<ul>
	Additional information:<br><br>
	<li>If a section does not have any visibility settings, by default the access will be Full for all users.</li>
	<li>If the user is administrator he will always have full access regardless of the menu visibility setting.</li>
	<li>If a user has profiles in several groups that have different levels of visibility in a section, the visibility for that user in that section will be the least restrictive.</li>
	<li>If a visibility level is created for a section by selecting all groups ('All' group), all settings for that section will be removed and only the one entered will remain.</li>
</ul>
</p>

