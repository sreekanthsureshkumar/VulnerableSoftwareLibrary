<h1>Incidents import from CSV</h2>

<p>
	The import can be done by an export made in Integria (in which the structure as it is generated in the system shoud not be manipulated) and it can be done by a CSV file.
</p>

</br>

<p>
    For the first case the input file will be the same as the one we previously exported, so it does not impose problems when processing the CSV.
</p>

</br>

<p>
    For the second case a series of parameters must be entered in order, some required and some not, being able to choose empty values for the latter. The fields will be the following for the logical order established by the tool:
</p>

</br>

<p>
    <strong>
        &emsp;Begin
    </strong>
</p>

</br>
<p>
    <strong>
        &emsp;Close
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Title
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Description
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;User id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Status
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Priority
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Group id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Update
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Creator id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Task id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Resolution
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Epilog
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Parent id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;SLA disabled
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Affected SLA id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Incident type id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Score
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Email copy
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Editor
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Group creator id
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Last stat check
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Closed by
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data 2
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Blocked
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Old status
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Old resolution
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Old status 2
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Old resolution 2
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data 3
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Extra data 4
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Black medals
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Gold medals
    </strong>
</p>

</br>

<p>
    <strong>
        &emsp;Custom fields:
    </strong> 
            must previously exist in your Integria IMS system and must be indicated in order, 
</p>
<p>
            &emsp;being able to choose a value, or in case of not wanting to give them value, blank space
</p>
<p>
            &emsp;In the case of tickets it will be necessary to create the type to which the fields belong and 
</p>
<p>
            &emsp;obviously to reference that type in the ticket itself.
</p>

<h2>Example</h2>

<p>
    “2017-07-20 13:38:39,0000-00-00 00:00:00,Ticket test,,admin,New(ID),Medium(ID),Customer #B(ID),2017-07-20 13:38:39,admin,0,None,,,0,0,1,0,,admin,Customer #B(ID),0000-00-00 00:00:00,,,,0,1,0,0,0,,,0,0,Integria,20”
</p>