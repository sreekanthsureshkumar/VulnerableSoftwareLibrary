<h1>Project management with the Task Planner</h1>
<p>
	The task planner is a view mode that allows for agile task management. It gives the possibility to create, edit and delete tasks, create work units (WU), tickets, etc.
</br>
</br>
	Also, it offers statistics that include: number of tasks per status, hours worked per employee, and tasks assigned to each user.
</p>


	<?php print_image("images/help/project7.png", false, array('width' => '720')); ?>

<p>
	To update task information, make all the changes you deem necessart on the chart and save them by pressing the update button. If the task has more than one employee assigned to it and you wish to make any changes in this field, you must head over to the detailed editing menu and click on the icon with a wrench icon, found on the right hand column. To delete a task you can use the button with a trashcan icon found on the right hand column.
	</br>
	</br>
	Status coding for a task corresponds to the following completion rate percentage:
	<ul>
		<li>Pending (white): between 0% and 39%</li>
		<li>In progress (yellow): between 40% and 89%</li>
		<li>Complete (blue): between 90% and 99%</li>
		<li>Verified (green): 100%</li>
	</ul>
	</br>
	To add a new task you need to fill out the fields and press the “Create” button.
	</br>
	</br>
	To delete a task we must go to Task Planning and click on the right side icon of a trash can on the task we wish to delete.
</p>
	<?php print_image("images/help/project6.png", false,  array('width' => '720')); ?>
	<h1> Creating new WorkUnits (WUs) from the Task planning section</h1>
<p>
	Manually creating a WU allows a user to input the time dedicated to a project and task. Don't confuse these manual WUs with comments on tickets (also labeled work units). In the case of work unit tickets that are assigned to a task the total ticket time is inputted automatically; in the case of individual work units, times are entered manually by the user, and are inputted according to the time entered when creating the ticket. The user fills in a series of basic fields (description, number of hours applied to the WU, assigned profile, etc.). Apart from these fields there is a series of controls that allow you to “divide” the WU into blocks of X amount of hours (default is 8 hours) and distribute this time among different WUs throughout time (forward or backward in that time span) with the same content as the original, except for the date. This is the optimal way to “fill out” hours to complete, for example, a vacations calendar.

</p><br>
<p>
	WorkUnits for a project can be created from the <strong>Task planning</strong>:
</p>
	<?php print_image("images/help/doc28.png", false,  array('width' => '720')); ?>
<p>
	It can also be done from the user's general view (<strong>Users→Add Spare WorkUnit</strong>). The only way to add work hours in all three special ways that Integria IMS contemplates, is from the user view (<strong>Add Spare WorkUnits</strong>):
</p><br>
<ul>
	<li type="disc">Vacations</li>
	<li type="disc">Sick days</li>
	<li type="disc">Unjustified nonattendance</li>
</ul><br>
<p>
	These concepts correspond to special tasks within a special project which is computed differently.<br>
	WUs can be created one by one or in blocks, for convenience. They can also be previewed before being inputted to the system.
</p>
<?php print_image("images/help/project17.png", false,  array('width' => '720')); ?>
<?php print_image("images/help/project18.png", false,  array('width' => '720')); ?>
