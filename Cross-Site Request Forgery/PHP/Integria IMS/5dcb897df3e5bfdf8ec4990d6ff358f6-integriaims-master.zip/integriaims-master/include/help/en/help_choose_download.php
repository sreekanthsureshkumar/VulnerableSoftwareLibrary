<h1>Download files</h1>

<p>
By default, all downloadable files and subdirectories must be placed at /attachment/downloads directory in the Integria root directory. Upload it with a FTP connection or using the Integria File Explorer (not suitable for too big files, due limitations of PHP.ini max. upload size and/or timeouts settings.
</p>
