<h1>Contacts Inventory</h1>
<p>
	The <b>Contacts</b> tab shows us people related to that inventory item. We can click on any of them to directly access their information.
</p>
<p>
	<?php print_image("images/help/inventory9.png", false, false); ?>
</p>