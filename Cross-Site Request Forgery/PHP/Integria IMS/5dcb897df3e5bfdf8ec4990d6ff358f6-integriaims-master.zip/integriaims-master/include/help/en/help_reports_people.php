<h1>Personnel reports:</h1>
<p>
	<ul>
		To view personnel reports the user needs the following profile:
		<li>.-User admin.</li>
		<li>.-See reports.</li>
	</ul>
</p>
<p>
	A form will appear allowing you to select the user whom the report is about. After selecting a user or a project three checks will appear where you can:
	<br>
	<p>
		<?php print_image("images/help/inf_pe_1.png", false, false); ?>
	</p>
	</br>
	<ul>
		<li>Search all projects, activities and work units, with their corresponding fields, task types, graphs, etc.</li>
		<li>See ticket summary: a summary of tickets and affected tickets.</li>
		<li>See ticket summary only.</li>
	</ul>
	<br>
	<p>
		<?php print_image("images/help/inf_pe_2.png", false, false); ?>
	</p>
	</br>
	<br>
	<p>
		<?php print_image("images/help/inf_pe_3.png", false, false); ?>
	</p>
</p>

<h1>Ticket único:</h1>
<p>
	Para crear un informe de este tipo aparece un campo que se auto-completa si se busca por id o por el título del ticket, con lo cuál mostrara un informe detallado por el ticket buscado.
</p>
<br>
<p>
	<?php print_image("images/help/inf_su_6.png", false, false); ?>
</p>
<br>
<br>
<p>
	<?php print_image("images/help/inf_su_7.png", false, false); ?>
</p>

<h1>General:</h1>
<p>
	It shows information about work units. This info can be filtered by user and date. We have the option of displaying the report on screen, exporting it to PDF or exporting it to CSV.
</p>
<br>
<p>
	<?php print_image("images/help/filtro_general.png", false, false); ?>
</p>
<br>
<br>
<p>
	The information displayed is as follows:
	<ul>
	<li>User who has imputed the hours</li>
	<li>Date</li>
	<li>Duration in hours</li>
	<li>Type. It can be hours allocated from ticket or from a task</li>
	<li>Project</li>
	<li>Group</li>
	<li>Title</li>
	<li>Description</li>
	<li>Creator</li>
	<li>Priority</li>
	<li>Company</li>
	
	</ul>
</p>
<br>
<br>
<p>
	<?php print_image("images/help/inf_general.png", false, false); ?>	
</p>
