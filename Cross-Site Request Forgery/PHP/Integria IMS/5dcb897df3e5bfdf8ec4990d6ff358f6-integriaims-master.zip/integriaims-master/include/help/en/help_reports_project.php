<h1>Projects reports:</h1>
<p>
	<ul>
		You need the following profile to view:
		<li>.-View projects (Project manager role)</li>
		<li>.-View reports</li>
	</ul>
</p>
<p>
	Set up a profile by going to the selector to choose the project
</p>
<br>
<p>
	<?php print_image("images/help/inf_pr_1.png", false, false); ?>
</p>
</br>
<p>
	Once the project is selected you'll see this formula:
</p>
<br>
<p>
	<?php print_image("images/help/inf_pr_2.png", false, false); ?>
</p>
</br>
<p>
	<ul>
		<li>Task selector for said project.</li>
		<li>A checkbox for more project information: Click to view detailed project information divided into:
			<ul>
				<li>.-General information (name, start date, etc).</li>
				<li>.-Personnel involved: who is participating</li>
				<li>.-Man power: Calculation of hours worked.</li>
				<li>.-Budget: Calculation of estimated costs.</li>
				<li>.-Task distribution graph: percentage share of the different tasks.</li>
				<li>.-Work distribution graph: percentage share of each users' contribution.</li>
				<li>.-Project activity graph.</li>
				<li>.-A summary of each task of said project.</li>
			</ul>
			<p>
				<?php print_image("images/help/inf_pr_3.png", false, false); ?>
			</p>
			</br></br>
			<p>
				<?php print_image("images/help/inf_pr_4.png", false, false); ?>
			</p>
			</br></br>
			<p>
				<?php print_image("images/help/inf_pr_5.png", false, false); ?>
			</p>
			</br></br>
		</li>
		<li>A checkbox for each task's activity: Click to view any specific details of each of the selected tasks:
			<ul>
				<li>.-Task activity graph.</li>
				<li>.-Task statistics.</li>
			</ul>
			<p>
				<?php print_image("images/help/inf_pr_6.png", false, false); ?>
			</p>
			</br></br>	
		</li>
		<li>A checkbox that displays Work Units for each project task: Click to view selected Work Unit details.</li>
		<p>
			<?php print_image("images/help/inf_pr_7.png", false, false); ?>
		</p>
		</br></br>
	</ul>
</p>
