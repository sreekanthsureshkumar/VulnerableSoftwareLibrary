<h1>Files attached to tasks</h1>
<p>
	Integria IMS' task manager allows attaching files to tasks. These files are stored on the server and can be saved in the attachment directory. As many files as needed by the user can be uploaded (there is no share manager or storage cap). All files uploaded will be accessible by the users who have read permits over the task.
</p>
<p>
	<?php print_image("images/help/project19.png", false, false); ?>
</p>