<p>
	<h1>Custom fields</h1>
</p>
</br>
<p>
	<b>In field creation you can define:</b>
</p>
</br>
<p>
	<ul>
		<li>- Name: obligatory field. Doesn’t have to be unique.</li>
		<li>- Display in ticket list: if you select this option it will appear as a column in the ticket list.</li>
		<li>- Global field: if you select this option it will appear in the ticket search form in advanced options.</li>
		<li>- Field type:</li>
		<ul>
			<li>- Text type: in the “create/edit ticket” form an input field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_8.png", false, false); ?>
			</br>
			<li>- Textarea: in the “create/edit ticket” form a text area field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_9.png", false, false); ?>
			</br>
			<li>- Combo box: in the “create/edit ticket” form a select form will be displayed where you can see all available options.</li>
			<br>
			<?php print_image("images/help/tk_10.png", false, false); ?>
			</br>
			<li>- Linked: interrelated custom fields</li>
			<ul>
				<li>e.g., BRANCH, DEPARTMENT, DIVISION</li>
				<li>--First you create the BRANCH field. In this case, a parent field is not selected because it is the first field in the hierarchy. The values are separated by a comma.</li>
				<br>
				<?php print_image("images/help/tk_11.png", false, false); ?>
				</br>
				<li>--Then, the DEPARTMENT field is created. In this case, the parent field BRANCH is selected. The field is then filled with the values separated by commas as above. As this field does have a parent, the values will have to be associated. To do this, place the value of the parent field ath the beginnning, separated by | from the rest. Like this we will indicate that the new field belongs to the parent field that precedes it (a department belongs to a headquarters).</li>
				<br>
				<?php print_image("images/help/tk_11_1.png", false, false); ?>
				</br>
				<li>--The next field to be created is DIVISION. The parent DEPARTMENT is selected and the values are set. Similarly, the relationship established indicates that a division belongs to a department.</li>
				<br>
				<?php print_image("images/help/tk_112.png", false, false); ?>
				</br>
			</ul>
			<li>-Numeric: in the “create/edit ticket” form a numeric field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_12.png", false, false); ?>
			</br>
			<li>-Date: in the “create/edit ticket” form a date field will be displayed.</li>
			<br>
			<?php print_image("images/help/tk_13.png", false, false); ?>
			</br>
		</ul>
	</ul>
</p>
<br>
<p>
	A list with all the fields you created will be displayed.
</p>
<br>
	<?php print_image("images/help/tk_14.png", false, false); ?>
</br>
<p>
	<b>The list is made up of the following columns:</b>
</p>
<p>
	<ul>
		<li>Field name.</li>
		<li>Field type.</li>
		<li>Parent: exclusive to linked types as these can refer to a parent.</li>
		<li>Value: exclusive to combo box and linked types as these have a selectable default value.</li>
		<li>Actions: allow the field to be edited or deleted.</li>
		<li>Ordering: to assign the order in which they are displayed.</li>
	</ul>
</p>
<p>
	Example of ordering: If you want the TYPE, MAKE, MODEL, MOTOR fields to appear first, and in that order, select the four categories from the list and in the ordering menu select the “before” option and the position (in this case, first position).
</p>
<br>
	<?php print_image("images/help/tk_15.png", false, false); ?>
</br>
<p>
	As can be seen, the linked fields appear at the beginning of the list.
</p>
</br>
	<?php print_image("images/help/tk_16.png", false, false); ?>
</br>