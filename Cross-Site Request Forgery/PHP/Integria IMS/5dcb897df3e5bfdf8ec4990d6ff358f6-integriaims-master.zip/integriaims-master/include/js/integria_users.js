function process_massive_operation (operation, token) {
	var checked_ids = new Array();
	var id;
	var checked;
	
	$(".user_checkbox").each(function () {
		id = $(this).val();
		checked = $(this).attr('checked');
		if(checked) {
			$(this).attr('checked', false);
			checked_ids.push(id);
		}
	});

	if(checked_ids.length == 0) {
		show_information_general(__("No items selected"), function() {});
	} else {
		values = Array ();
		values.push ({
				name: "page",
				value: "include/ajax/users"
			});
		values.push ({
				name: operation,
				value: true
			});
		values.push ({
				name: "ids",
				value: checked_ids
			});
		//~ if(operation == 'delete_users'){
			//~ values.push ({
				//~ name: "token",
				//~ value: token
			//~ });

			//~ show_validation_delete_general('delete_users', null, null, 0, {}, function() {
				//~ perform_operation(operation, values);
			//~ });

		//~ } else {
			perform_operation(operation, values);
		//~ }
		
	}

	function perform_operation() {
		jQuery.get ("ajax.php", values, function (data, status) {
				
				var msg = '';

				switch(operation) { 
					case 'delete_users':
						if (data !== false) {msg = "Successfully deleted"}
						else {msg = "Error in delete user"}
						break;
					case 'disable_users':
						msg = 'Successfully disabled';
						break;
					case 'enable_users':
						msg = 'Successfully enabled';
						break;
				}

				show_information_general(msg, function() {
					location.reload();
				});

			}, "json"
		);

	}

	function alerta (msg) {
		alert(msg);
	}
}
