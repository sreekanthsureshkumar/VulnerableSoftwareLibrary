function initialize_tinymce(selector_name){
	if(!selector_name){
		selector_name = 'textarea';
	}

	tinymce.init({
		selector: selector_name,
		plugins : "advlist, anchor, autolink, autoresize, charmap, code, codesample, textcolor, colorpicker, directionality, emoticons, help, hr, image, insertdatetime, link, lists, pagebreak, paste, preview, print, searchreplace, table, visualblocks, visualchars, wordcount",
		toolbar: "undo redo | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | fontsizeselect fontselect | forecolor backcolor emoticons | link image code",
		valid_children : "+body[style],-body[div],p[strong|a|#text]",
		setup : function(ed){
			ed.on('init', function(){
				this.getDoc().body.style.fontSize = '11';
				this.getDoc().body.style.fontFamily = 'Arial';
			});
		},

		font_formats: 'Andale Mono=andale mono,times;Arial=arial,helvetica,sans-serif;Arial Black=arial black,avant garde;Book Antiqua=book antiqua,palatino;Comic Sans MS=comic sans ms,sans-serif;Courier New=courier new,courier;Georgia=georgia,palatino;Helvetica=helvetica;Impact=impact,chicago;Lato=lato;League gothic=leaguegothic;Open sans=opensans;Roboto=roboto;Symbol=symbol;Tahoma=tahoma,arial,helvetica,sans-serif;Terminal=terminal,monaco;Times New Roman=times new roman,times;Trebuchet MS=trebuchet ms,geneva;Verdana=verdana,geneva;Webdings=webdings;Wingdings=wingdings,zapf dingbats ',
		fontsize_formats: '8pt 10pt 11pt 12pt 14pt 18pt 24pt 36pt 42pt 60pt',
		preview_styles: false,

		//images
		image_title: true,
		automatic_uploads: true,
		file_picker_types: 'image',
		file_picker_callback: function(cb, value, meta) {
			var input = document.createElement('input');
			input.setAttribute('type', 'file');
			input.setAttribute('accept', 'image/*');

			input.onchange = function() {
				var file = this.files[0];

				var reader = new FileReader();
				reader.onload = function () {
					var id = 'blobid' + (new Date()).getTime();
					var blobCache =  tinymce.activeEditor.editorUpload.blobCache;
					var base64 = reader.result.split(',')[1];
					var blobInfo = blobCache.create(id, file, base64);
					blobCache.add(blobInfo);

					cb(blobInfo.blobUri(), { title: file.name });
				};
				reader.readAsDataURL(file);
			};
		input.click();
		},
	});
}

/* Function to hide/unhide a specific Div id */
function toggleDiv (div, animate) {
	var item = (typeof div == "string") ? $("#" + div) : $(div);
	var id = div.replace("_div","");
	if (typeof animate !== "undefined" && animate == true) {
		item.slideToggle();
	}
	else {
		var class_img = $("#"+id+"_arrow").attr("class");
		if (class_img == 'arrow_down')
			$("#"+id+" #"+id+"_arrow").addClass('arrow_right').removeClass('arrow_down').attr("src",'images/arrow_right.png');
		else
			$("#"+id+" #"+id+"_arrow").addClass('arrow_down').removeClass('arrow_right').attr("src",'images/arrow_down.png');
		item.toggle();
	}
}

function winopeng (url, wid) {
	open (url, wid,"width=570,height=310,status=no,toolbar=no,menubar=no,scrollbar=no");
	// WARNING !! Internet Explorer DOESNT SUPPORT "-" CARACTERS IN WINDOW HANDLE VARIABLE
	status =wid;
}

function integria_help(help_id) {
	// open ("general/integria_help.php?id="+help_id, "integriahelp", "width=770,height=500,status=0,toolbar=0,menubar=0,scrollbars=1,location=0");

	$.ajax({
		type: "POST",
		url: "ajax.php",
		data: "page=general/integria_help&id="+help_id,
		dataType: "html",
		success: function(data){	
			$("#item_integria_help").html (data);
			$("#item_integria_help").show ();

			$("#item_integria_help").dialog ({
					resizable: true,
					draggable: true,
					modal: true,
					overlay: {
						opacity: 0.5,
						background: "black"
					},
					width: 850,
					height: 650,
				});
			$("#item_integria_help").dialog('open');
			$('div.ui-dialog.ui-widget.ui-widget-content.ui-corner-all #item_integria_help').parent().css('top', '100px');
			$('div.ui-dialog.ui-widget.ui-widget-content.ui-corner-all #item_integria_help').parent().css('left', '50px');
			$('#all_documentation').mouseenter(function(e){
				$("#documentation_url").css("font-size", "14px");
			});
			$('#all_documentation').mouseleave(function(e){
				$("#documentation_url").css("font-size", "13px");
			});
			$(".ui-widget-overlay").click(function(e){
				e.preventDefault();
				$("#item_integria_help").dialog("close");
			});
		}
	});
}

/**
 * Decode HTML entities into characters. Useful when receiving something from AJAX
 *
 * @param str String to convert
 *
 * @retval str with entities decoded
 */
function html_entity_decode (str) {
	if (! str)
		return "";
	var ta = document.createElement ("textarea");
	ta.innerHTML = str.replace (/</g, "&lt;").replace (/>/g,"&gt;");
	return ta.value;
}

/**
 * Refresh odd an even rows in a table.
 *
 * @param table_id If of the table to refresh.
 */
function refresh_table (table_id) {
	$("#" + table_id + " > tbody > tr:odd td").removeClass("datos").addClass("datos2");
	$("#" + table_id + " > tbody > tr:even td").removeClass("datos2").addClass("datos");
}

/**
 * Get all values of an form into an array.
 *
 * @param form Form to get the values. It can be an object or an HTML id
 *
 * @retval The input values of the form into an array.
 */
function get_form_input_values (form) {
	if (typeof form == "string") {
		return $("#" + form).formToArray ();
	} else {
		return $(form).formToArray ();
	}
}

/**
 * Show an error message in result div.
 * 
 * @param string message Message to show
 */
function result_msg_error (message) {
	$(".result").fadeOut ("fast", function () {
		$(this).empty ().append ($("<h3></h3>").addClass ("error").append (message)).fadeIn ();
	});
}

/**
 * Show an success message in result div.
 * 
 * @param string message Message to show
 */
function result_msg_success (message) {
	$(".result").fadeOut ("fast", function () {
		$(this).empty ().append ($("<h3></h3>").addClass ("suc").append (message)).fadeIn ();
	});
}

/**
 * Show an message in result div.
 * 
 * @param string message Message to show
 */
function result_msg (message) {
	$(".result").fadeOut ("fast", function () {
		$(this).empty ().append ($("<h3></h3>").append (message)).fadeIn ();
	});
}

/**
 * Pulsate an HTML element to get user attention.
 *
 * @param element HTML element to animate.
 */
function pulsate (element) {
	$(element).fadeIn ("normal", function () {
		$(this).fadeOut ("normal", function () {
			$(this).fadeIn ("normal", function () {
				$(this).fadeOut ("normal", function () {
					$(this).fadeIn ().focus ();
				});
			});
		});
	});
}


function load_form_values (form_id, values) {
	$("#"+form_id+" :input").each (function () {
		if (values[this.name] != undefined) {
			if (this.type == 'checkbox' && values[this.name])
				this.checked = "1";
			else
				this.value = values[this.name];
		}
	});
}

function __(str) {
	var r = lang[str];
	
	if (r == undefined)
		return str
	return r;
}

function cancel_msg(id) {
	$('#msg_'+id).fadeOut('slow');

}

/**
 * Exclude in a input the not alphanumeric characters
 *
 * @param id identifier of the input element to control
 * @param exceptions string with the exceptions to exclusion
 * @param lower bool true if the lowercase are allowed, false otherwise
 * @param upper bool true if the uppercase are allowed, false otherwise
 * @param numbers bool true if the numbers are allowed, false otherwise
 */
function inputControl(id,exceptions,lower,upper,numbers) {
	if(typeof(exceptions) == 'undefined') {
		exceptions = '_.';
	}
	if(typeof(lower) == 'undefined') {
		lower = true;
	}
	if(typeof(upper) == 'undefined') {
		upper = true;
	}
	if(typeof(numbers) == 'undefined') {
		numbers = true;
	}
	
	var regexpStr = '';
	
	if(lower) {
		regexpStr+= 'a-z';
	}
	if(upper) {
		regexpStr+= 'A-Z';
	}
	if(numbers) {
		regexpStr+= '0-9';
	}
	
	// Scape the special chars
	exceptions = exceptions.replace(/\./gi,"\\.");
	exceptions = exceptions.replace(/\-/gi,"\\-");
	exceptions = exceptions.replace(/\^/gi,"\\^");
	exceptions = exceptions.replace(/\$/gi,"\\$");
	exceptions = exceptions.replace(/\[/gi,"\\[");
	exceptions = exceptions.replace(/\]/gi,"\\]");
	exceptions = exceptions.replace(/\(/gi,"\\(");
	exceptions = exceptions.replace(/\)/gi,"\\)");
	exceptions = exceptions.replace(/\+/gi,"\\+");
	exceptions = exceptions.replace(/\*/gi,"\\*");
	
	regexpStr+= exceptions;
	$("#"+id).keyup(function() {
		var text = $(this).val();
		var regexp = new RegExp("[^"+regexpStr+"]","g");
		text = text.replace(regexp,'');
		$("#"+id).val(text);
	});
}

function toggleInventoryInfo(id_inventory) {
	display = $('.inventory_more_info_' + id_inventory).css('display');
	
	if (display != 'none') {
		$('.inventory_more_info_' + id_inventory).css('display', 'none');
	}
	else {
		$('.inventory_more_info_' + id_inventory).css('display', '');
	}
}

/**
 * Binds autocomplete behaviour to an input tag 
 * 
 * !!!jquery.ui.autocomplete.js must be loaded in the page before use this function!!!
 *
 * @param idTag String tag's id to bind autocomplete behavior
 * @param idUser String user's id
 * @param byProject Boolean flag to search by users in a project
 */
function bindAutocomplete (idTag, idUser, idProject, onChange, ticket, idGroup) {
	
	var ajaxUrl = "ajax.php?page=include/ajax/users&search_users=1&id_user="+idUser;
	
	if (ticket) {
		ajaxUrl = "ajax.php?page=include/ajax/users&search_users_ticket=1&id_user="+idUser+"&id_group="+idGroup;
	}
	
	if (idProject) {
		ajaxUrl = "ajax.php?page=include/ajax/users&search_users_role=1&id_user="+idUser+"&id_project="+idProject;
	}
	
	$(idTag).autocomplete ({
		source: ajaxUrl,
		minLength: 2,
		delay: 200,
		change: onChange
	});
}
/**
 * autocomplete name ticket 
 * 
 * !!!jquery.ui.autocomplete.js must be loaded in the page before use this function!!!
 *
 */
function bindTicketAutocomplete (idTag, idUser, filterType, onChange) {
	var ajaxUrl = "ajax.php?page=include/ajax/incidents&search_incidents_auto=1&id_user="+idUser;

	$(idTag).autocomplete({
		source: ajaxUrl,
		minLength: 1,
		delay: 200,
		change: onChange
	});
}

function bindAutocompleteProject (idTag, idUser, idTag2, fixed_tasks) {
	var ajaxUrl = "ajax.php?page=include/ajax/projects&search_projects=1&id_user="+idUser;

	$('#' + idTag).autocomplete ({
		source: ajaxUrl,
		minLength: 2,
		delay: 200,
		select: function(event, ui) {
			event.preventDefault();
			$('#hidden-' + '#' + idTag).val(ui.item.value);
			$('#' + idTag).val(ui.item.label);
		},
		change: function(event, ui) {
			$.ajax({
				type: "POST",
				url: "ajax.php",
				data: {
					page: "include/ajax/projects",
					get_project_id: 1,
					project_name: function() { return $('#' + idTag).val() },
					id_user: idUser
				},
				dataType: "json",
				success: function(data) {
					if (data) {
						$("#" + idTag2).empty();
						$("#" + idTag2).append ($('<option value="0">' + fixed_tasks[0] + '</option>'));
						$("#" + idTag2).append ($('<option value="-1">' + fixed_tasks[1] + '</option>'));
						$("#" + idTag2).append ($('<option value="-2">' + fixed_tasks[2] + '</option>'));
						$("#" + idTag2).append ($('<option value="-3">' + fixed_tasks[3] + '</option>'));
						$("#" + idTag2).append ($('<option value="-5">' + fixed_tasks[5] + '</option>'));
						if(data != false) {
							$.each(data, function (i, d) {
								$("#" + idTag2).append ($('<option value="' + i + '">' + d + '</option>'));
							});
						}
					}
				}
			});
		}
	});
}

function bindAutocompleteProjectMultiple (idTag, idUser, idTag2, fixed_tasks) {
	var ajaxUrl = "ajax.php?page=include/ajax/projects&search_projects=1&id_user="+idUser;

	$("[id^='" + idTag + "_']").autocomplete ({
		source: ajaxUrl,
		minLength: 2,
		delay: 200,
		select: function(event, ui) {
			event.preventDefault();
			var id_aux = this.id.split("_");
			var id = id_aux[1];
			$('#hidden-' + '#' + idTag + "_" + id).val(ui.item.value);
			$("#" + idTag + "_" + id).val(ui.item.label);
		},
		change: function(event, ui) {
			var id_aux = this.id.split("_");
			var id = id_aux[1];

			$.ajax({
				type: "POST",
				url: "ajax.php",
				data: {
					page: "include/ajax/projects",
					get_project_id: 1,
					project_name: function() {return $("#" + idTag + "_" + id).val();},
					id_user: idUser
				},
				dataType: "json",
				success: function(data) {
					if (data) {
						$("#" + idTag2 + "_" + id).empty();
						$("#" + idTag2 + "_" + id).append ($('<option value="0">' + fixed_tasks[0] + '</option>'));
						$("#" + idTag2 + "_" + id).append ($('<option value="-1">' + fixed_tasks[1] + '</option>'));
						$("#" + idTag2 + "_" + id).append ($('<option value="-2">' + fixed_tasks[2] + '</option>'));
						$("#" + idTag2 + "_" + id).append ($('<option value="-3">' + fixed_tasks[3] + '</option>'));
						$("#" + idTag2 + "_" + id).append ($('<option value="-5">' + fixed_tasks[5] + '</option>'));
						if(data != false) {
							$.each(data, function (i, d) {
								$("#" + idTag2 + "_" + id).append ($('<option value="' + i + '">' + d + '</option>'));
							});
						}
					}
				}
			});
		}
	});
}

/**
 * Binds autocomplete behaviour to an input tag 
 * 
 * !!!jquery.ui.autocomplete.js must be loaded in the page before use this function!!!
 *
 */
function bindCompanyAutocomplete (idTag, idUser, filterType) {

	var filter = $('#hidden-autocomplete_'+idTag+'_filter').val();
	if (filter) {
		filter = "&filter="+filter;
	} else {
		filter = "";
	}
	filter = filter+"&type="+filterType;
	var ajaxUrl = "ajax.php?page=include/ajax/companies&search_companies=1&id_user="+idUser;

	$('#'+idTag).autocomplete ({
		source: ajaxUrl + filter,
		minLength: 2,
		delay: 200,
		select: function(event, ui) {
			event.preventDefault();

			$('#hidden-'+idTag).val(ui.item.value);
			$('#'+idTag).val(ui.item.label);
		},
		change: function(event, ui) {
			$.ajax({
				type: "POST",
				url: "ajax.php",
				data: {
					page: "include/ajax/companies",
					get_company_id: 1,
					company_name: function() { return $('#'+idTag).val() },
					id_user: idUser,
					filter: function() { return $('#hidden-autocomplete_'+idTag+'_filter').val() }
				},
				dataType: "json",
				success: function(data) {
					if (data) {
						$('#hidden-'+idTag).val(data);
					} else {
						$('#'+idTag).val("");
						$('#hidden-'+idTag).val(0);
					}
				}
			});
		}
	});

	$('#'+idTag).keypress(function(e) {
		if ( e.which == 13 ) {
			e.preventDefault();
		}
	});
}

function beginReloadTimeout(seconds, form_id) {
	var reload;
	if (form_id) {
		reload = function () { document.getElementById(form_id).submit() };
	} else {
		reload = function () { window.location.reload() };
	}
	reloadTimeoutID = window.setTimeout(reload, seconds * 1000);
}

function clearReloadTimeout(token) {
	window.clearTimeout(reloadTimeoutID);
}

function setAutorefreshSeconds (token, seconds) {
	eraseCookie(token);
	createCookie(token, seconds, false);
}

function enableAutorefresh (id, token, form_id) {
	
	var button = $("#"+id);
	var seconds = readCookie(token);
	
	button.attr('reload_enabled', 1);
	//button.animate({ backgroundColor: "#238A1C" });
	button.html("Disable autorefresh");
	//~ $("#autorefresh_combo").show( "blind", { direction: "right" }, "slow" );
	$("#autorefresh_combo").css('visibility', 'visible');
	
	if (! seconds) {
		setAutorefreshSeconds(token, 60);
		beginReloadTimeout(60, form_id);
	} else {
		setAutorefreshSeconds(token, seconds);
		beginReloadTimeout(seconds, form_id);
	}
}

function disableAutorefresh (id, token) {
	
	var button = $("#"+id);
	
	button.attr('reload_enabled', 0);
	//button.animate({ backgroundColor: "#A82323"});
	button.html("Enable autorefresh");
	//~ $("#autorefresh_combo").hide( "blind", { direction: "left" }, "slow" );
	$("#autorefresh_combo").css('visibility', 'hidden');
	
	eraseCookie(token);
	clearReloadTimeout(token);
}

function toggleAutorefresh (id, token, form_id) {
	
	var button = $("#"+id);
	
	if (button.attr('reload_enabled') == 1) {
		disableAutorefresh(id, token);
	} else {
		enableAutorefresh(id, token, form_id);
	}
}

function changeAutorefreshTime (id, token, form_id) {
	
	var combo = $("#"+id);
	var seconds = combo.val();
	
	setAutorefreshSeconds(token, seconds);
	clearReloadTimeout(token);
	beginReloadTimeout(seconds, form_id);
	
}

function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    } else var expires = "";
    document.cookie = escape(name) + "=" + escape(value) + expires + "; path=/";
}

function readCookie(name) {
    var nameEQ = escape(name) + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return unescape(c.substring(nameEQ.length, c.length));
    }
    return null;
}

function eraseCookie(name) {
    createCookie(name, "", -1);
}

// Show the modal window of license info
function show_license_info(expiry_day, expiry_month, expiry_year, max_manager_users, max_regular_users) {

	$.ajax({
		type: "POST",
		url: "ajax.php",
		data: "page=include/ajax/license&get_license_info=1&expiry_day="+expiry_day+"&expiry_month="+expiry_month+"&expiry_year="+expiry_year+"&max_manager_users="+max_manager_users+"&max_regular_users="+max_regular_users,
		dataType: "html",
		success: function(data){	
			$("#dialog_show_license").html (data);
			$("#dialog_show_license").show ();

			$("#dialog_show_license").dialog ({
					resizable: true,
					draggable: true,
					modal: true,
					overlay: {
						opacity: 0.5,
						background: "black"
					},
					width: 500,
					height: 350
				});
			$("#dialog_show_license").dialog('open');
			
		}
	});
}

function toggleUsersInfo(id_group) {

	display = $('.group_more_info_' + id_group).css('display');
	
	if (display != 'none') {
		$('.group_more_info_' + id_group).css('display', 'none');
	}
	else {
		$('.group_more_info_' + id_group).css('display', '');
	}
}

// Helper function that formats the file sizes
function formatFileSize(bytes) {
	if (typeof bytes !== 'number') {
		return '';
	}

	if (bytes >= 1000000000) {
		return (bytes / 1000000000).toFixed(2) + ' GB';
	}

	if (bytes >= 1000000) {
		return (bytes / 1000000).toFixed(2) + ' MB';
	}

	return (bytes / 1000).toFixed(2) + ' KB';
}

$(document).ready (function () {
	

	if ($('#license_error_msg_dialog').length) {

		$( "#license_error_msg_dialog" ).dialog({
					resizable: true,
					draggable: true,
					modal: true,
					height: 290,
					width: 800,
					overlay: {
								opacity: 0.5,
								background: "black"
							}
		});
		
		$("#submit-hide-license-error-msg").click (function () {
			$("#license_error_msg_dialog" ).dialog('close')
		});
	
	}
	
});

$(document).ready(function() {
	// Containers open/close logic
	$('tr.clickable').click(function() {
		var arrow = $('#' + $(this).attr('id') + ' th.img_arrow' + ' img').attr('src');
		var arrow_class = $('#' + $(this).attr('id') + ' img').attr('class');
		var new_arrow = '';

		if($('#' + $(this).attr('id') + '_div').css('display') == 'none') {
			new_arrow = arrow.replace(/_down/gi, "_right");
			$('#' + $(this).attr('id')+ ' th.img_arrow' + ' img').attr('class', 'arrow_right');
		}
		else {
			new_arrow = arrow.replace(/_right/gi, "_down");
			$('#' + $(this).attr('id')+ ' th.img_arrow' + ' img').attr('class', 'arrow_down');
		}
		
		$('#' + $(this).attr('id')+ ' th.img_arrow' + ' img').attr('src', new_arrow);
	});
});

function openInventoryMoreInfo (id_inventory) {
	$.ajax({
		type: "POST",
		url: "ajax.php",
		data: "page=include/ajax/inventories&id_inventory=" + id_inventory + "&printTableMoreInfo=1",
		success: function(data){
			$("#info_inventory_window").html (data);
			$("#info_inventory_window").show ();

			$("#info_inventory_window").dialog ({
					resizable: true,
					draggable: true,
					modal: true,
					title: "Extended info",
					overlay: {
						opacity: 0.5,
						background: "black"
					},
					width: 620,
					height: 300
				});
			$("#info_inventory_window").dialog('open');
		}
	});
}

function isValidImg (url, callback) {
	var img = new Image();
	img.onerror = function() {
		callback(url, false);
	}
	img.onload = function() {
		callback(url, img);
	}
	img.src = url;
}

function parseURLSearch (searchStr) {
	var search = {};
	
	if (searchStr.length > 0) {
		// Remove the ? character
		searchStr = searchStr.substring(1);
		
		var searches = searchStr.split('&');
		
		for (var i = 0; i < searches.length; i++) {
			var aux = searches[i].split('=');
			var key = aux.shift();
			var value = aux.shift();
			
			if (typeof key !== 'undefined') {
				if (typeof value !== 'undefined') {
					if (typeof search[key] !== 'undefined') {
						if (search[key] instanceof Array) {
							if (value.length > 0)
								search[key].push(value);
						}
						else {
							var lastVal = search[key];
							search[key] = [];
							if (lastVal.length > 0)
								search[key].push(lastVal);
							if (value.length > 0)
								search[key].push(value);
							if (search[key].length <= 0)
								search[key] = '';
						}
					}
					else {
						search[key] = value;
					}
				}
				else if (!(search[key] instanceof Array)) {
					search[key] = '';
				}
			}
		}
	}
	
	return search;
}

function parseURL (URL) {
	// parser.href		=> "http://foo.bar:8080/pathname/?search=test#hash"
	// parser.protocol	=> "http:"
	// parser.hostname	=> "foo.bar"
	// parser.port		=> "8080"
	// parser.pathname	=> "/pathname/"
	// parser.search	=> "?search=test"
	// parser.hash		=> "#hash"
	// parser.host		=> "foo.bar:8080"
	var parser = document.createElement('a');
	parser.href = URL;
	
	return {
		href: parser.href,
		protocol: parser.protocol,
		hostname: parser.hostname,
		port: parser.port,
		pathname: parser.pathname,
		search: parseURLSearch(parser.search),
		hash: parser.hash,
		host: parser.host
	}
}

function show_information_general(message, callback) {
	$.ajax({
		type: "POST",
		url: "ajax.php",
		data: "page=include/ajax/information_message_general&message="+encodeURIComponent(message),
		dataType: "html",
		success: function(data){
			$("#item_information_window").html (data);
			$("#item_information_window").show ();
			$("#item_information_window").dialog ({
				resizable: false,
				draggable: false,
				modal: true,
				overlay: {
					opacity: 0.5,
					background: "black"
				},
				width: 440,
				height: 195
			});

			$("#item_information_window").dialog('open');

			$("#button-info_modal_cancel").click(function (e){
				e.preventDefault();
				$("#item_information_window").dialog('close');
				if(callback) {callback()}
			});

			$('.ui-widget-overlay').click(function(e){
				e.preventDefault();
				$("#item_information_window").dialog('close');
				if(callback) {callback()}
			});
		}
	});
}

function show_manage_project_people_modal(id_project, id_user) {
	$("#item_manage_people_window").show();
	$("#item_manage_people_window").dialog({
		resizable: false,
		draggable: false,
		modal: true,
		overlay: {
			opacity: 0.5,
			background: "black"
		},
		width: 282,
		height: 250
	});

	$('div.ui-dialog.ui-widget.ui-widget-content.ui-corner-all #item_manage_people_window').parent().css('top', 'center');
	$('#item_manage_people_window input[name=user]').attr('value',id_user);
	$("#item_manage_people_window").dialog('open');
	$("#form-people_manager").off('submit').on('submit', function(e){
		e.preventDefault();
		window.location.href = 'index.php?sec=projects&sec2=operation/projects/project_detail'
								+ '&id_project=' + id_project
								+ '&action=insert' 
								+ '&id_user=' + $('#form-people_manager  input[name=user]').val()
								+ '&id_role=' + $('#form-people_manager select').val();
	});

	$("#button-modal_cancel").click(function(e){
		e.preventDefault();
		$("#item_manage_people_window").dialog('close');
	});

	$('.ui-widget-overlay').click(function(e){
		e.preventDefault();
		$("#item_manage_people_window").dialog('close');
	});

}

function show_validation_delete_general (name, id, id2, offset, search_params) {
	$.ajax({
		type: "POST",
		url: "ajax.php",
		data: "page=include/ajax/delete_item_general&get_delete_validation=1",
		dataType: "html",
		success: function(data){

			$("#item_delete_window").html (data);
			$("#item_delete_window").show ();
			$("#item_delete_window").dialog ({
					resizable: false,
					draggable: false,
					modal: true,
					overlay: {
						opacity: 0.5,
						background: "black"
					},
					width: 440,
					height: 210
				}).dialog('open');
			$("#validation_delete_form").submit(function (e){
				e.preventDefault();
				//~ if (callback) {
					//~ $("#item_delete_window").dialog('close');
					//~ callback();
				//~ } else {
					delete_item_general (name, id, id2, offset, search_params);
				//~ }
			});

			$("#button-modal_cancel").click(function (e){
				e.preventDefault();
				$("#item_delete_window").dialog('close');
			});
			$('.ui-widget-overlay').click(function(e){
				e.preventDefault();
				$("#item_delete_window").dialog('close');
			});

		}
	});
}

function delete_item_general (name, id, id2, offset, search_params) {
	$.ajax({
		type: "POST",
		url: "ajax.php",
		data: "page=include/ajax/delete_item_general&delete_item=1&name="+ name+"&id="+id,
		dataType: "html",
		//~ async:false,
		success: function (data) {
			switch (name) {
				case 'delete_project':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/project&view_disabled=1&delete_project=1&id="+id+"&offset="+offset+"&search_params="+search_params);
				break;
				case 'delete_role_user_global':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/role_user_global&id_user="+id2+"&delete="+id);
				break;
				case 'delete_task_panning':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/task_planning&id_project="+id+"&delete="+id2);
				break;
				case 'delete_milestones':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/milestones&id_project="+id+"&operation=delete&id="+id2);
				break;
				case 'delete_project_people':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/project_detail&action=delete&id_user="+id+"&id_project="+id2+"&id_role="+offset);
				break;
				case 'delete_people_manager':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/people_manager&action=delete&id="+id+search_params);
				break;
				case 'delete_template':
					window.location.assign("index.php?sec=godmode&sec2=godmode/setup/setup_mailtemplates&search=1&delete_template=1&id_template="+id+search_params);
				break;
				case 'delete_people_task_human':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/people_manager&action=delete&id_project="+id+"&id_task="+id2+"&id="+offset);
				break;
				case 'delete_project_group_detail':
					window.location.assign("index.php?sec=projects&sec2=operation/projects/project_group_detail&delete_group=1&id="+id);
				break;
				case 'delete_task_wu':
					window.location.assign("index.php?sec=users&sec2=operation/users/user_spare_workunit&operation=delete&id_workunit="+id);
				break;
				case 'delete_company':
					window.location.assign("index.php?sec=customers&sec2=operation/companies/company_detail&id=0&offset="+offset+"&search_params="+search_params+"&message="+data);
				break;
				case 'delete_contract':
					window.location.assign("index.php?sec=customers&sec2=operation/contracts/contract_detail&"+search_params+"&message="+data);
				break;
				case 'delete_invoice':
					window.location.assign("index.php?sec=customers&sec2=operation/invoices/invoice_detail&offset="+offset+"&search_params="+search_params+"&message="+data);
				break;
				case 'delete_company_invoice':
					window.location.assign("index.php?sec=customers&sec2=operation/companies/company_detail&id="+id_company+"&op=invoices&offset="+offset+"&message="+data);
				break;
				case 'delete_lead':
					window.location.assign("index.php?sec=customers&sec2=operation/leads/lead&tab=search&offset="+offset+"&message="+data);
				break;
				case 'delete_template_ticket_type':
					window.location.assign("index.php?sec=incidents&sec2=operation/incidents/templates_ticket_type&delete_template=1&id="+id+"&id_incident_type="+id2);
				break;
				case 'delete_ticket_type':
					window.location.assign("index.php?sec=incidents&sec2=operation/incidents/type_detail&delete_type=1&id="+id);
				break;
				case 'delete_ticket':
					window.location.assign("index.php?sec=incidents&sec2=operation/incidents/incident_detail&quick_delete="+id);
				break;
				case 'delete_field_ticket_type':
					window.location.assign("index.php?sec=incidents&sec2=operation/incidents/incident_type_field&delete_field=1&id_field="+id+"&id="+id2);
				break;
				case 'delete_objects':
					window.location.assign("index.php?sec=inventory&sec2=operation/inventories/manage_objects&delete_object=1&id="+id);
				break;
				case 'delete_object_type_field':
					window.location.assign("index.php?sec=inventory&sec2=operation/inventories/manage_objects_types_list&delete_object_type_field=1&id="+id+"&id_object_type_field="+id2);
				break;
				case 'delete_inventory':
					window.location.assign("index.php?sec=inventory&sec2=operation/inventories/inventory_search&quick_delete=1&id_inventory="+id);
				break;
				case 'delete_manufacturer':
					window.location.assign("index.php?sec=inventory&sec2=operation/manufacturers/manufacturer_detail&delete_manufacturer=1&id="+id);
				break;
				case 'delete_report':
					window.location.assign("index.php?sec=reporting&sec2=operation/reporting/custom_reports&delete_report=1&id="+id);
				break;
				case 'delete_scheduled_report':
					window.location.assign("index.php?sec=users&sec2=enterprise/operation/user/schedule_reports&operation=delete&id="+id);
				break;
				case 'delete_company_custom_field':
					window.location.assign("index.php?sec=customers&sec2=operation/companies/company_custom_fields&delete=1&id="+id);
				break;
				case 'delete_role':
					window.location.assign("index.php?sec=customers&sec2=operation/companies/company_role&delete_role=1&id="+id);
				break;
				case 'delete_custom_contract':
					window.location.assign("index.php?sec=customers&sec2=operation/contracts/contract_custom_fields&delete=1&id="+id);
				break;
				case 'delete_contact':
					window.location.assign("index.php?sec=customers&sec2=operation/contacts/contact_detail&delete_contact=1&id="+id);
				break;
				case 'delete_crm_template':
					window.location.assign("index.php?sec=customers&sec2=operation/leads/template_manager&operation=delete&id="+id);
				break;
				case 'delete_user':
					window.location.assign("index.php?sec=users&sec2=godmode/usuarios/lista_usuarios&borrar_usuario="+id+"&token="+search_params);
				break;
				case 'delete_user_fields':
					window.location.assign("index.php?sec=users&sec2=godmode/usuarios/user_field_list&delete=1&id="+id);
				break;
				case 'delete_milestone_fields':
					window.location.assign("index.php?sec=projects&sec2=godmode/milestones/milestone_field_list&delete=1&id="+id);
				break;
				case 'delete_group':
					window.location.assign("index.php?sec=users&sec2=godmode/grupos/lista_grupos&id_grupo="+id+"&delete_group=1&id="+id);
				break;
				case 'delete_profile':
					window.location.assign("index.php?sec=users&sec2=enterprise/godmode/usuarios/profile_list&delete_profile=1&id="+id);
				break;
				case 'delete_menu_mode':
					window.location.assign("index.php?sec=users&sec2=enterprise/godmode/usuarios/menu_visibility_manager&delete_menu_mode=1&mode_id="+id);
				break;
				case 'delete_role_manager':
					window.location.assign("index.php?sec=users&sec2=godmode/usuarios/role_manager&id="+id+"&delete="+id);
				break;
				case 'delete_sla':
					window.location.assign("index.php?sec=incidents&sec2=operation/slas/sla_detail&delete_sla=1&id="+id);
				break;
				case 'delete_kb':
					window.location.assign("index.php?sec=kb&sec2=operation/kb/browse&delete_data="+id);
				break;
				case 'delete_product':
					window.location.assign("index.php?sec=kb&sec2=operation/inventories/manage_prod&delete_product=1&id="+id);
				break;
				case 'delete_kb_access':
					window.location.assign("index.php?sec=kb&sec2=operation/kb/manage_perms&delete=1&id_product="+id+"&id_group="+id2);
				break;
				case 'delete_fr_type':
					window.location.assign("index.php?sec=download&sec2=operation/download/manage_types&op=delete&id="+id);
				break;
				case 'delete_fr_download':
					window.location.assign("index.php?sec=download&sec2=operation/download/browse&delete_data="+id+"&id_type="+id2);
				break;
				case 'delete_fr_category':
					window.location.assign("index.php?sec=download&sec2=operation/download/manage_cat&delete_cat="+id);
				break;
				case 'delete_fr_access':
					window.location.assign("index.php?sec=download&sec2=operation/download/manage_perms&delete=1&id_category="+id+"&id_group="+id2);
				break;
				case 'delete_users':
					var checked_ids = new Array();
					$(".user_checkbox").each(function () {
						id = $(this).val();
						checked = $(this).attr('checked');
						if(checked) {
							$(this).attr('checked', false);
							checked_ids.push(id);
						}
					});
					if(checked_ids.length == 0) {
						show_information_general(__("No items selected"), function() {});
					} else {
						window.location.assign("index.php?sec=users&sec2=godmode/usuarios/lista_usuarios&delete_users=1&ids="+checked_ids+"&token="+search_params);
					}
				break;
				case 'delete_kb_category':
					window.location.assign("index.php?sec=kb&sec2=operation/kb/manage_cat&delete_cat="+id);
				break;
				case 'delete_workflow_rule':
					window.location.assign("index.php?sec=incidents&sec2=enterprise/operation/incidents/workflow_management&delete_rule=1&id="+id);
				break;
				case 'delete_workflow_condition':
					window.location.assign("index.php?sec=incidents&sec2=enterprise/operation/incidents/workflow_conditions&delete_condition=1&id_rule="+id+"&id_condition="+id2);
				break;
				case 'delete_workflow_action':
					window.location.assign("index.php?sec=incidents&sec2=enterprise/operation/incidents/workflow_actions&delete_action=1&id_rule="+id+"&id_action="+id2);
				break;
				case 'delete_status_mapping':
					window.location.assign("index.php?sec=incidents&sec2=enterprise/operation/incidents/workflow_status_mapping&delete_row=1&id_row="+id);
				break;
				case 'delete_contract_template':
					window.location.assign("index.php?sec=customers&sec2=operation/contracts/contract_template&delete_template=1&id="+id);
				break;
			}
		}
	});
}

function period_select_init(name) {
	// Manual mode is hidden by default
	$('#' + name + '_manual').hide();
	$('#' + name + '_default').show();
	
	// If the text input is empty, we put on it 5 minutes by default
	if ($('#text-' + name + '_text').val() == '') {
		$('#text-' + name + '_text').val(300);
		// Set the value in the hidden field too
		$('.' + name).val(300);
		if ($('#' + name + '_select option:eq(0)').val() == 0) {
			$('#' + name + '_select option:eq(2)')
				.prop('selected', true);
		}
		else {
			$('#' + name + '_select option:eq(1)')
				.prop('selected', true);
		}
	}
	else if ($('#text-' + name + '_text').val() == 0) {
		$('#' + name + '_units option:last').prop('selected', false);
		$('#' + name + '_manual').show();
		$('#' + name + '_default').hide();
	}
}

function period_select_events(name) {
	$('.' + name + '_toggler').click(function() {
		toggleBoth(name);
		$('#text-' + name + '_text').focus();
	});
	
	adjustTextUnits(name);
	
	// When select a default period, is setted in seconds
	$('#' + name + '_select').change(function() {
		var value = $('#' + name + '_select').val();
		
		if (value == -1) {
			value = 300;
			toggleBoth(name);
			$('#text-' + name + '_text').focus();
		}
		
		$('.' + name).val(value);
		$('#text-' + name + '_text').val(value);
		adjustTextUnits(name);
	});
	
	// When select a custom units, the default period changes to
	// 'custom' and the time in seconds is calculated into hidden input
	$('#' + name + '_units').change(function() {
		selectFirst(name);
		calculateSeconds(name);
	});
	
	// When write any character into custom input, it check to convert
	// it to integer and calculate in seconds into hidden input
	$('#text-' + name + '_text').keyup (function () {
		var cleanValue = parseInt($('#text-' + name + '_text').val());
		if (isNaN(cleanValue)) {
			cleanValue = '';
		}
		
		$('#text-' + name + '_text').val(cleanValue);
		
		selectFirst(name + '_select');
		calculateSeconds(name);
	});
}

function period_set_value(name, value) {
	$("#text-" + name + "_text").val(value);
	adjustTextUnits(name);
	calculateSeconds(name);
	selectFirst(name + '_select');
	$("#" + name + "_manual").hide();
	$("#" + name + "_default").show();
}

function selectFirst(name) {
	if ($('#'+name+' option:eq(0)').val() == 0) {
		$('#'+name+' option:eq(1)').prop('selected', true);
	}
	else {
		$('#'+name+' option:eq(0)').prop('selected', true);
	}
}

function toggleBoth(name) {
	if ($('#'+name+'_default').css('display') == 'none') {
		$('#'+name+'_default').css('display','inline');
	}
	else {
		$('#'+name+'_default').css('display','none');
	}
	
	if ($('#'+name+'_manual').css('display') == 'none') {
		$('#'+name+'_manual').css('display','inline');
	}
	else {
		$('#'+name+'_manual').css('display','none');
	}
}

function calculateSeconds(name) {
	var calculated =
		$('#text-' + name + '_text').val() * $('#' + name + '_units').val();
	
	$('.' + name).val(calculated);
}

function period_select_update(name, seconds) {
	$('#text-' + name + '_text').val(seconds);
	adjustTextUnits(name);
	calculateSeconds(name);
	$('#' + name + '_manual').show();
	$('#' + name + '_default').hide();
}

function adjustTextUnits(name) {
	var restPrev;
	var unitsSelected = false;
	$('#'+name+'_units option').each(function() {
		if($(this).val() < 0) {
			return;
		}
		var rest = $('#text-'+name+'_text').val()/$(this).val();
		var restInt = parseInt(rest).toString();
		
		if(rest != restInt && unitsSelected == false) {
			$('#'+name+'_units option:eq('+($(this).index()-1)+')').prop('selected', true);
			$('#text-'+name+'_text').val(restPrev);
			unitsSelected = true;
		}
		
		restPrev = rest;
	});
	
	if(unitsSelected == false) {
		$('#'+name+'_units option:last').prop('selected', true);
		$('#text-'+name+'_text').val(restPrev);
	}
	
	if($('#text-'+name+'_text').val() == 0) {
		selectFirst(name+'_units');
	}
}

/**
 * Util for check is empty object
 * 
 * @param obj the object to check
 * @returns {Boolean} True it is empty
 */
function isEmptyObject(obj) {
	for(var prop in obj) {
		if(obj.hasOwnProperty(prop))
			return false;
	}
	
	return true;
}

function paint_qrcode(text, where, width, height) {
	if (typeof(text) == 'undefined') {
		text = window.location.href;
	}
	else {
		//null value
		if (isEmptyObject(text)) {
			text = window.location.href;
		}
	}
	
	if (typeof(where) == 'undefined') {
		where = $("#qrcode_container_image").get(0);
	}
	else if (typeof(where) == 'string') {
		where = $(where).get(0);
	}
	
	if (typeof(where) == 'undefined') {
		where = $("#qrcode_container_image").get(0);
	}
	else if (typeof(where) == 'string') {
		where = $(where).get(0);
	}
	
	if (typeof(width) == 'undefined') {
		width = 256;
	}
	else {
		if (typeof(width) == 'object')
			//null value
			if (isEmptyObject(width)) {
				width = 256;
			}
	}
	
	if (typeof(height) == 'undefined') {
		height = 256;
	}
	else {
		if (typeof(height) == 'object')
			//null value
			if (isEmptyObject(height)) {
				height = 256;
			}
	}
	
	$(where).empty();
	
	var qrcode = new QRCode(where, {
		text: text,
		width: width,
		height: height,
		colorDark : "#3f3f3f",
		colorLight : "#ffffff",
		correctLevel : QRCode.CorrectLevel.M
	});

	// added this to pick back the qrcode object
	return qrcode;

}

function show_dialog_qrcode(dialog, text, where, width, height) {
	
	if (typeof(dialog) == 'undefined') {
		dialog = "#qrcode_container";
	}
	else {
		if (typeof(dialog) == 'object')
			//null value
			if (isEmptyObject(dialog)) {
				dialog = "#qrcode_container";
			}
	}
	
	if (typeof(where) == 'undefined') {
		where = $("#qrcode_container_image").get(0);
	}
	else if (typeof(where) == 'string') {
		where = $(where).get(0);
	}
	
	if (typeof(width) == 'undefined') {
		width = 256;
	}
	else {
		if (typeof(width) == 'object')
			//null value
			if (isEmptyObject(width)) {
				width = 256;
			}
	}
	
	if (typeof(height) == 'undefined') {
		height = 256;
	}
	else {
		if (typeof(height) == 'object')
			//null value
			if (isEmptyObject(height)) {
				height = 256;
			}
	}

	$(where).show();
	
	// Commented this code, seems useless
	var qrcode = /*$(where).html (*/paint_qrcode(text, where, 200, 200)/*)*/;

	//$('.result').append('<a href="'+qrcode._oDrawing._elCanvas.toDataURL("image/png")+'" download="bla"><img src="'+qrcode._oDrawing._elCanvas.toDataURL("image/png")+'"/></a>')


	$(where).dialog({ resizable: false, 
					  draggable: false,
					  autoOpen: false,
					  modal: true,
					  overlay: {
						opacity: 0.5,
						background: "black"
					  }, 
					  width: 225, 
					  height: 260,
					  title: 'Scan or click to download',
					});

	/****** Ugly piece of JQuery to add download functionality to the QR Code ************************/
	/**/	var img_src		= qrcode._oDrawing._elCanvas.toDataURL("image/png")
	/**/	var file_name	= 'id_' + text + '_inventory_item.png';
	/**/
	/**/	$(where).html(
	/**/		'<a href="' + img_src + '" download="' + file_name + '">' +
	/**/			'<img alt="Scan me!" src="'+img_src+'">' +
	/**/		'</a>'
	/**/	);
	/*************************************************************************************************/ 

	$(where).dialog('open');
}
