<?php

global $config;

require_once ('include/functions_db.php');

function print_setup_tab ($section, $title, $img_src, $selected = false) {
	echo '<a href="index.php?sec=godmode&sec2=' . $section . '" title="' . $title . '">';
	echo '<li class="' . ($selected ? 'button-bar-selected' : '') . '"><span>';
	echo '<img src="' . $img_src . '">';
	echo '</span></li>';
	echo '</a>';
}

function get_setup_tab_title ($tab) {
	switch ($tab) {
		case 'visual':
			return __('Visual setup');
		case 'password':
			return __('Password policy setup');
		case 'incidents':
			return __('Incident setup');
		case 'mail':
			return __('Mail setup');
		case 'mailtemplates':
			return __('Mail templates setup');
		case 'visibility':
			return __('Visibility management');
		case 'inventory':
			return __('Pandora FMS inventory');
		case 'auth':
			return __('Authentication configuration');
		case 'crm':
			return __('CRM setup');
		case 'maintenance':
			return (__('Old data maintenance'));
		case 'project':
			return (__('Project management'));
		case 'license':
			return (__('License'));
		case 'ehorus':
			return (__('eHorus'));
		case 'setup':
		default:
			return __('General setup');
	}
	
	return '';
}

function print_setup_tabs ($selected_tab, $is_enterprise) {
	echo '<h2>' . __('Configuration Integria') . '</h2>';
	echo '<h4>' . get_setup_tab_title($selected_tab);
	if ($selected_tab == 'mailtemplates') echo integria_help('macros', true);
	if ($selected_tab == 'visibility') echo integria_help('visibility_management', true);
	echo '<div id="button-bar-title">';
	echo '<div id="button-bar-title">';
	echo '<ul>';

	// Setup
	print_setup_tab('godmode/setup/setup', get_setup_tab_title('visual'), 'images/cog.png', $selected_tab == 'setup');
	// Visual setup
	print_setup_tab('godmode/setup/setup_visual', get_setup_tab_title('visual'), 'images/chart_bar_dark.png', $selected_tab == 'visual');
	if ($is_enterprise) {
		// Password policy
		print_setup_tab('enterprise/godmode/setup/setup_password', get_setup_tab_title('password'), 'images/lock_dark.png', $selected_tab == 'password');
	}
	// Incident setup
	print_setup_tab('godmode/setup/incidents_setup', get_setup_tab_title('incidents'), 'images/incident_dark.png', $selected_tab == 'incidents');
	// Mail setup
	print_setup_tab('godmode/setup/setup_mail', get_setup_tab_title('mail'), 'images/email_dark.png', $selected_tab == 'mail');
	// Mail templates setup
	print_setup_tab('godmode/setup/setup_mailtemplates&search=1', get_setup_tab_title('mailtemplates'), 'images/email_edit.png', $selected_tab == 'mailtemplates');
	if ($is_enterprise) {
		// Visibility management
		print_setup_tab('enterprise/godmode/usuarios/menu_visibility_manager', get_setup_tab_title('visibility'), 'images/eye.png', $selected_tab == 'visibility');
	}
	// Pandora FMS inventory
	print_setup_tab('godmode/setup/setup_pandora', get_setup_tab_title('inventory'), 'images/inventory_dark.png', $selected_tab == 'inventory');
	// Authentication
	print_setup_tab('godmode/setup/setup_auth', get_setup_tab_title('auth'), 'images/key.png', $selected_tab == 'auth');
	// CRM setup
	print_setup_tab('godmode/setup/setup_crm', get_setup_tab_title('crm'), 'images/invoice_dark.png', $selected_tab == 'crm');
	// Old data maintenance
	print_setup_tab('godmode/setup/setup_maintenance', get_setup_tab_title('maintenance'), 'images/trash.png', $selected_tab == 'maintenance');
	// Project management
	print_setup_tab('godmode/setup/setup_project', get_setup_tab_title('project'), 'images/star_dark.png', $selected_tab == 'project');
	// License
	print_setup_tab('godmode/setup/setup_license', get_setup_tab_title('license'), 'images/license.png', $selected_tab == 'license');
	// eHorus
	print_setup_tab('godmode/setup/setup_ehorus', get_setup_tab_title('ehorus'), 'images/ehorus/ehorus.png', $selected_tab == 'ehorus');
	
	echo '</ul>';
	echo '</div>';
	echo '</h4>';
}

?>
