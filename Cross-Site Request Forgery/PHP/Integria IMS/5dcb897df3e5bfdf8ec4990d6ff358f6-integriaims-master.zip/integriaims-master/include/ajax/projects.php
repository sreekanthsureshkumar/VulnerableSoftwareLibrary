<?php
// INTEGRIA - the ITIL Management System
// http://integria.sourceforge.net
// ==================================================
// Copyright (c) 2008-2012 Ártica Soluciones Tecnológicas
// http://www.artica.es  <info@artica.es>

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

global $config;

require_once ('include/functions_db.php');
require_once ('include/functions_projects.php');
require_once ('include/functions_tasks.php');

$project_tasks = (int) get_parameter ('project_tasks');
$show_actual = (int) get_parameter('show_actual');
$update_task = (int) get_parameter('update_task');
$update_task_parent = (int) get_parameter('update_task_parent');
$get_task_links = (int) get_parameter('get_task_links');
$get_task_editor = (int) get_parameter('get_task_editor');
$delete_task = (int) get_parameter('delete_task');
$create_task = (int) get_parameter('create_task');
$get_task_statistics = (int) get_parameter('get_task_statistics');
$get_task_completion_hours = (int) get_parameter('get_task_completion_hours');
$check_link = (int) get_parameter("check_link");
$delete_link = (int) get_parameter("delete_link");
$get_calculator = (int) get_parameter("get_calculator");
$get_workunits_task = (int) get_parameter('get_workunits_task', 0);
$get_scale = get_parameter('scale', 'month');
$change_id_project = (bool) get_parameter('change_id_project', 0);
$get_project_id = (bool) get_parameter('get_project_id', 0);
$search_projects = (bool) get_parameter('search_projects', 0);
$search_projects_form = (bool) get_parameter('search_projects_form', 0);
$delete_task_user = (bool) get_parameter ('delete_task_user', 0);
$add_user_task = (bool) get_parameter ('add_user_task', 0);
$upload_file = (bool) get_parameter ('upload_file');
$update_file_description = (bool) get_parameter("update_file_description");
$get_file_row = (bool) get_parameter("get_file_row");
$delete_project_file = (bool) get_parameter("delete_project_file");

function fix_date ($date, $default='') {
	$date_array = preg_split ('/[\-\s]/', $date);
	if (sizeof($date_array) < 3) {
		return false;
	}

	if ($default != '' && $date_array[0] == '0000') {
		return $default;
	}
		
	return sprintf ('%02d/%02d/%04d', $date_array[2], $date_array[1], $date_array[0]);
}

function get_tasks_gantt (&$tasks, $project_id, $project_start, $project_end, $parent_id = 0, $depth = 0, $show_actual = 0) {
	global $config;

	$id_user = $config["id_user"];
    $result = get_db_all_rows_sql ('SELECT * FROM ttask 
                            WHERE id_parent_task = ' . $parent_id
                            . ' AND id_project = ' . $project_id);
    if ($result === false) {
    	return;
    }

	if(isset($result) && is_array($result)){
		foreach ($result as $key => $value) {
			// ACL Check for this task
			// This user can see this task?
			$task_access = get_project_access ($config["id_user"], $project_id, $value['id'], false, true);
			if ($task_access["read"]) {
				$task['id'] = $value['id'];
				$task['name'] = $value['name'];

				if ($show_actual) {
					$task["name"] .= " (".__("Planned").")";
				}

				$task['parent'] = $parent_id;
				$task['link'] = 'index.php?sec=projects&sec2=operation/projects/task_detail&id_project=' . $project_id .'&id_task=' . $value['id'] .'&operation=view';
				// start > end
				$task['start'] = fix_date ($value['start'], $project_start);
				$task['end'] = fix_date ($value['end'], $project_end);
				if (date_to_epoch ($task['start']) > date_to_epoch ($task['end'])) {
					$temp = $task['start'];
					$task['start'] = $task['end'];
					$task['end']   = $temp;
				}
				$task['real_start']   = fix_date (get_db_sql ('SELECT MIN(timestamp) FROM tworkunit, tworkunit_task WHERE tworkunit_task.id_workunit = tworkunit.id AND timestamp <> \'0000-00-00 00:00:00\' AND id_task = ' . $value['id']), $task['start']);
				$task['real_end']     = fix_date (get_db_sql ('SELECT MAX(timestamp) FROM tworkunit, tworkunit_task WHERE tworkunit_task.id_workunit = tworkunit.id AND timestamp <> \'0000-00-00 00:00:00\' AND id_task = ' . $value['id']), $task['start']);
				$task['completion']   = $value['completion'];
				$task["actual_data"]  = 0;
				$task["worked_hours"] = get_task_workunit_hours ($value["id"]);
				$task["hours"]        = $value["hours"];

				array_push ($tasks, $task);

				//Add another task to represent real effort for the task
				if ($show_actual) {

					$task_aux = array();

					$task_aux["id"]          = $task["id"]."act";
					$task_aux["actual_data"] = 1;
					$task_aux["parent"]      = $task["parent"];

					if ($task['real_start']) {
						$task_aux["start"] = $task['real_start'];
					} else {
						$task_aux["start"] = $task['start'];
					}

					if ($task['real_end']) {
						$task_aux["end"] = $task['real_end'];
					} else {
						$task_aux["end"] = $task['start'];
					}
					$task_aux["completion"] = 0;
					$task_aux["name"] = $value["name"]." (".__("Actual").")";

					array_push ($tasks, $task_aux);
				}

				get_tasks_gantt ($tasks, $project_id, $project_start, $project_end, $task['id'], $depth + 1, $show_actual);
			}
		}
	}
}

// Get project milestones
function get_milestones_gantt (&$milestones, $project_id, $parent_id = 0, $depth = 0) {
    $result = get_db_all_rows_sql ('SELECT * FROM tmilestone 
                            WHERE id_project = ' . $project_id);
    if ($result === false) {
    	return;
    }
    if(isset($result) && is_array($result)){
		foreach ($result as $key => $value) {
			$milestone['id']          = $value['id'];
			$milestone['name']        = $value['name'];
			$milestone['description'] = $value['description'];
			$milestone['date']        = fix_date ($value['timestamp']);
			array_push ($milestones, $milestone);
		}
	}
}

if ($search_projects) {
	require_once ('include/functions_db.php');
	require_once ('include/functions_projects.php');

	$id_user = (string) get_parameter ('id_user', $config['id_user']);
	$string = (string) get_parameter ('term');

	$and = sprintf (' AND name LIKE "%%%s%%" ', $string);

	$sql_project = "SELECT name, id
					FROM tproject
					WHERE disabled = 0
						$and
					ORDER BY name";
	$projects = get_db_all_rows_sql($sql_project);

	//Check project ACLs
	$aux_projects = array();
	foreach ($projects as $p) {
		$project_access = get_project_access ($config["id_user"], $p['id']);
		if ($project_access["read"]) {
			array_push($aux_projects, $p);
		}
	}

	
	//Set filtered projects
	$projects = $aux_projects;

	if (!$projects) {
		return;
	}
	
	$result = array();
	
	foreach ($projects as $project) {
		array_push($result, array("value" => safe_output($project['name']), "id" => $project['id']));
	}
	
	echo json_encode($result);
	return;
}

if ($get_project_id) {
	require_once ('include/functions_db.php');
	require_once('include/functions_projects.php');

	$id_user = (string) get_parameter ('id_user', $config['id_user']);
	$project_name = (string) get_parameter ('project_name');
	$id_project = get_db_value("id", "tproject", "name", $project_name);
	
	$tasks = get_all_task_for_proyect_access($id_project);

	echo json_encode($tasks);
	return;
}

// Get project tasks
if ($project_tasks) {
	
	$tasks = array();

	$from = '00/00/0000';
	$to = '00/00/0000';

	// Minimum date from project/tasks/workunits
	$min_start = fix_date (get_db_sql ('SELECT MIN(start) FROM ttask WHERE start <> \'0000-00-00\' AND id_project = ' . $project_tasks));

	if ($min_start !== false) {
		$from = $min_start;
	}

	// Maximun date from project/tasks/workunits
	$max_end = fix_date (get_db_sql ('SELECT MAX(end) FROM ttask WHERE end <> \'0000-00-00\' AND id_project = ' . $project_tasks));

	if ($max_end !== false) {
		$to = $max_end;
	}

	// Fix undefined start/end dates
	if ($from == '00/00/0000') {
		$from = $min_start = date ('d/m/Y');
	}

	if ($to == '00/00/0000') {
		$to = $max_end = date ('d/m/Y');
	}
	
	get_tasks_gantt ($tasks, $project_tasks, $from, $to, 0, 0, $show_actual);

	$order = 1;
	$link_counter = 1;

	$tasks_gantt = array();
	$links_gantt = array();
	foreach ($tasks as $t) {

		//Add tasks with gantt format

		//Replace / with - to get the correct time format
		$aux_date = str_replace ("/", "-", $t["start"]);
		$start_time = strtotime ($aux_date);
		
		$aux_date = str_replace ("/", "-", $t["end"]);
		$end_time = strtotime ($aux_date);
		
		$duration_time = $end_time - $start_time;
		
		$day_in_seconds = 3600 * 24;

		$duration = $duration_time / $day_in_seconds;

		//Add one day, we need to show task until end of last day
		//We add this for all tasks which has a duration and for 
		//all tasks which are the estimated task not the actual one
		if ($duration || !$t["actual_data"])
			$duration++;

		//Get number of people involver
		$sql_people = sprintf("SELECT id_user, id_role FROM trole_people_task WHERE id_task = %d", $t["id"]);

		$people = process_sql ($sql_people);

		$people_task = array();
		foreach ($people as $p) {
			$aux = array();

			$aux["name"] = safe_output(get_db_value("nombre_real", "tusuario", "id_usuario", $p["id_user"]));
			$aux["role"] = safe_output(get_db_value("name", "trole", "id", $p["id_role"]));

			array_push($people_task, $aux);
		}

		$aux = array("id" => $t["id"],
				"text" => safe_output($t["name"]),
				"start_date" => $t["start"],
				"progress" => $t["completion"]/100,
				"duration" => sprintf("%.2f",$duration),
				"estimated_hours" => $t["hours"],
				"people" => $people_task,
				"order" => $order,
				"actual_data" => $t["actual_data"],
				"id_project" => $project_tasks,
				"worked_hours" => $t["worked_hours"],
				"parent" => $t["parent"]);

		//Create a link if needed
		$sql = sprintf("SELECT * FROM ttask_link WHERE target = %d", $t["id"]);

		$links = get_db_all_rows_sql($sql);

		if (!$links) {
			$links = array();
		}

		foreach ($links as $l) {
			$aux_link = array("id" => $link_counter,
							"source" => $l["source"],
							"target" => $l["target"],
							"type" => $l["type"]);

			array_push($links_gantt, $aux_link);

			$link_counter++;
		}

		array_push($tasks_gantt, $aux);

		$order++;
	}

    $tasks_array = array("data" => $tasks_gantt, "links" => $links_gantt);

	$milestones = array();

	get_milestones_gantt($milestones, $project_tasks);

	$milestones_day = array();
	$milestones_month = array();
	$milestones_week = array();

	foreach ($milestones as $m) {
		if(isset($m["date"]) && $m["date"] != false){
			$date_array = preg_split("~/~", $m["date"]);
		}
		else{
			$date_array[1] = 0;
			$date_array[0] = 0;
			$date_array[2] = 0;
		}

		$date_aux = mktime(0, 0, 0, $date_array[1], $date_array[0],$date_array[2]);
		$week = (int)date('W', $date_aux);

		if (!isset ($milestones_week[$week])) {
			$milestones_week[$week] = array();
		}

		array_push($milestones_week[$week], array("name" => safe_output($m["name"]), "date" => $m["date"]));

		if (!isset ($milestones_month[$date_array[1]])) {
			$milestones_month[$date_array[1]] = array();
		}

		array_push($milestones_month[$date_array[1]], array("name" => safe_output($m["name"]), "date" => $m["date"]));

		if (!isset ($milestones_day[$m["date"]])) {
			$milestones_day[$m["date"]] = array();
		}

		array_push($milestones_day[$m["date"]], array("name" => safe_output($m["name"]), "desc" => safe_output($m["description"])));
	}
	
	$milestones_array = array("month" => $milestones_month, "day" => $milestones_day, "week" => $milestones_week);


	$aux_date = str_replace ("/", "-", $min_start);

	$min_start_sec = strtotime($aux_date);
	$min_start_mili = $min_start_sec * 1000;

	$aux_date = str_replace ("/", "-", $max_end);
	$max_end_sec = strtotime($aux_date);
	$max_end_mili = $max_end_sec * 1000;
	
	// Add some space at end to avoid tooltip overload and too small tasks
	$last_task_seconds = get_db_sql ('SELECT UNIX_TIMESTAMP(end) - UNIX_TIMESTAMP(start) AS diff FROM ttask 
								   WHERE id_project=' . $project_tasks . ' 
								   ORDER BY UNIX_TIMESTAMP(end) 
								   DESC LIMIT 1');

	switch ($get_scale) {
		
		case "month":
			$added_seconds = 15 * 86400 - $last_task_seconds;
			if ($added_seconds > 0) {
				$max_end_mili += $added_seconds * 1000;
			}
			break;
		case "week":
			$added_seconds = 5 * 86400 - $last_task_seconds;
			if ($added_seconds > 0) $max_end_mili += $added_seconds * 1000;
			break;
		default:
	}

	//Fix dates depending on scale
	$result = array("tasks" => $tasks_array, "milestones" => $milestones_array, "min_scale" => $min_start_mili, "max_scale" => $max_end_mili);

	echo json_encode($result);

	exit;
}

if ($update_task) {
	$id_task = get_parameter("id");
	$start_date = get_parameter("start_date");
	$end_date = get_parameter("end_date");
	$progress = get_parameter("progress");

	//Fix date
	$start_date = safe_output($start_date);
	$start_date = preg_replace ('/ \(.*\)/i', '', $start_date);
	$start_time = strtotime($start_date);
	$start_date = date("Y-m-d", $start_time);

	$end_date = safe_output($end_date);
	$end_date = preg_replace ('/ \(.*\)/i', '', $end_date);
	$end_time = strtotime($end_date);
	$end_date = date("Y-m-d", $end_time);

	//Fix progress
	$progress = $progress * 100;
	$progress = (int) $progress;

	$current_task = get_db_row_sql(sprintf("SELECT * FROM ttask WHERE id = %d", $id_task));

	//If task is the same don't update it and return and OK message
	if ($start_date == $current_task["start"]
		&& $end_date == $current_task["end"]
		&& $progress == $current_task["completion"]) {

		$res = true;

	} else {
		//If something is different then update task
		$sql = sprintf ('UPDATE ttask SET completion = %d,
				start = "%s", end = "%s" WHERE id = %d',
				$progress, $start_date, $end_date, $id_task);

		$res = process_sql ($sql);
	}

	if ($res) {	
		$msg = __("Task updated");
	} else {
		$msg = __("Error updating task");
	}

	$ret = array ("res" => $res, "msg" => $msg);
	echo json_encode($ret);
	exit;
}

if ($update_task_parent) {
	$target = get_parameter("target");
	$source = get_parameter("source");
	$type = get_parameter("type");

	/**
		link types:
			0: start to finish
			1: start to start
			2: finish to finish
	**/
	$links = array($target);

	$res = projects_update_task_links ($source , $links, $type, false);

	if ($res) {
		$msg = __("Task updated");
	} else {
		$msg = __("Error updating task");
	}

	$ret = array ("res" => $res, "msg" => $msg);
	echo json_encode($ret);
	exit;
}

if ($get_task_links) {
	$type = (int) get_parameter("type");
	$id_project = get_parameter("id_project");
	$id_task = get_parameter("id_task");

	$links_all = projects_get_task_available_links ($id_project, $id_task, $type);
	$links =  projects_get_links_in_task ($id_project, $id_task, $type);

	echo '<table style="width: 100%;"><tr>';
	echo '<td>';
	if ($type == 0){
	echo '<label>'.__('Finish to start').'</label>';
	}
	if ($type == 1){
	echo '<label>'.__('Start to start').'</label>';
	}
	if ($type == 2){
	echo '<label>'.__('Finish to finish').'</label>';
	}
	echo '</td></tr>';
	echo '<tr><td style="text-align:left; width: 45%;">';
	echo '<div>';
	echo print_select ($links_all, "origin".$type, '', '', '', 0, true, true, false, false, false, 'width:99%; max-width: 230px;');
	echo '</div></td>';

	echo '<td style="text-align:left;">';
	echo '<div class="div_middle_ui">';
	echo 	'<a class="pass left"><img src="images/flecha_dcha.png"/></a><br/>';
	echo 	'<a class="passall left"><img src="images/go_finish.png"/></a><br/>';
	echo 	'<a class="remove right"><img src="images/flecha_izqda.png"/></a><br/>';
	echo 	'<a class="removeall right"><img src="images/go_begin.png"/></a>';
	echo '</div></td>';
	echo '<td style="text-align:left; width: 45%;">';
	echo '<div>';
	echo 	print_select ($links, "id_task".$type, '', '', '', 0, true, true, false, false, false, 'width:99%; max-width: 230px;', true);
	echo '</div>';
	echo '</td></tr></table>';

	echo '<div style="width: 35px; float:right;" class="action-buttons button">';
	echo "<a href='javascript: load_link(".$type.");'><strong>".__('Add')."</strong><img src='images/add.png' /></a>";
echo '</div>';

	?>
	<script type="text/javascript" >
	//mov select to select
	var type = <?php echo $type;?>;
	$('.pass').click(function() {
		return !$('#origin'+ type +' option:selected').remove().appendTo('#id_task'+type).attr('selected', 'selected'); 
	});
	$('.remove').click(function() {
		return !$('#id_task'+ type +'  option:selected').remove().appendTo('#origin'+type).attr('selected', false);
	});
	$('.remove').click(function() {
		return $('#id_task'+ type +'  option').attr('selected', 'selected');
	});
	$('.passall').click(function() {
		$('#origin'+ type +'  option').each(function() {
			$(this).remove().appendTo('#id_task'+type).attr('selected', 'selected');
		}); 
	});
	$('.removeall').click(function() {
		$('#id_task'+ type +'  option').each(function() {
			$(this).remove().appendTo('#origin'+type);
		});
	});
	</script>
<?php
}

if ($get_task_editor) {
	include($config["homedir"]."operation/projects/task_detail.php");
	exit;
}

if ($delete_task) {
	delete_task ($delete_task);

	$msg = __('Successfully deleted');

	$ret = array ("res" => true, "msg" => $msg);
	echo json_encode($ret);
	exit;
}

if ($create_task) {
	$name = get_parameter("text");
	$hours = get_parameter("duration");
	$id_project = get_parameter("id_project");
	$id_parent = get_parameter("id_parent");
	$start = get_parameter("start_date");

	//Calculate task start and end
	$start = safe_output($start);

	if ($start == "__NEW__") {
		$start = date ('Y-m-d');
	} else {
		$date_array = preg_split("~ ~", $start);
		$date_array = preg_split("~-~", $date_array[0]);
		$start = $date_array[2]."-".$date_array[1]."-".$date_array[0];
	}

	//By default tasks ends a day after it starts
	$end = date ('Y-m-d', strtotime($start. ' + 1 days'));

	$sql = sprintf('INSERT INTO ttask (`id_project`, `id_parent_task`, 
					`name`, `start`, `end`, `hours`) VALUES 
					(%d, %d, "%s", "%s", "%s", %d)', 
					$id_project, $id_parent, $name, $start, $end, $hours);

	$id_task = process_sql ($sql, 'insert_id');

	if ($id_task) {
		// Add all users assigned to current project for new task or parent task if has parent
		if ($id_parent != 0){
			$query1="SELECT * FROM trole_people_task WHERE id_task = $id_parent";
		}
		else{
			$query1="SELECT * FROM trole_people_project WHERE id_project = $id_project";
		}

		$resq1=get_db_all_rows_sql($query1);
		if(isset($resq1) && is_array($resq1)){
			foreach ($resq1 as $key => $value) {
				$id_role_tt = $value["id_role"];
				$id_user_tt = $value["id_user"];
				$sql = "INSERT INTO trole_people_task (id_task, id_user, id_role) VALUES ($id_task, '$id_user_tt', $id_role_tt)";
				process_sql ($sql);
			}
		}
		task_tracking ($id_task, TASK_CREATED);
		project_tracking ($id_project, PROJECT_TASK_ADDED);
	}

	if ($id_task) {
		$msg = __("Task created");
	} else {
		$msg = __("Error creating task");
	}

	$ret = array ("res" => $id_task, "msg" => $msg);
	echo json_encode($ret);
	exit;
}

if ($get_task_statistics) {
	include($config["homedir"]."operation/projects/task_report.php");
	exit;
}

if ($get_task_completion_hours) {
	$percentage = get_task_completion($get_task_completion_hours);

	echo json_encode(array("percentage" => $percentage));
	exit;
}

if ($check_link) {
	$source = get_parameter("source");
	$target = get_parameter("target");
	$type = get_parameter("type");

	$sql = sprintf("SELECT * FROM ttask_link WHERE type = %d
		AND ((source = %d AND target = %d) OR (source = %d AND target = %d))", 
			$type, $source, $target, $target, $source);
	
	$res = process_sql($sql);

	$valid = true;

	if ($res) {
		$valid = false;
	}

	echo json_encode(array("result" => $valid));
	exit;
}

if ($delete_link) {
	$source = get_parameter("source");
	$target = get_parameter("target");

	$sql = sprintf("DELETE FROM ttask_link WHERE source = %d AND target = %d", $source, $target);

	$res = process_sql($sql);

	$valid = true;

	if ($res) {
		$valid = false;
	}

	echo json_encode(array("result" => $valid));
	exit;
}

if ($get_calculator) {
	
	$days = get_parameter('days', 0);
	$people = get_parameter('people', 0);
	
	$hours_per_day = $config['hours_perday'];
	$total = $days * $people * $hours_per_day;
	
	$table->width = "100%";
	$table->class = "search-table-button";
	$table->data = array ();
	$table->colspan = array ();
	$table->colspan[3][1] = 2;
	$table->data[0][0] = print_label(__('Days'), '', 'text', true);
	$table->data[0][1] = print_input_text ('days', $days, '', 15, 15, true);
	$table->data[1][0] = print_label(__('People'), '', 'text', true);
	$table->data[1][1] = print_input_text ('people', $people, '', 15, 15, true);
	$table->data[2][0] = print_label(__('Total hours'), '', 'text', true);
	$table->data[2][1] = print_input_text ('total', $total, '', 15, 15, true, '',true);
	
	$table->data[3][1] = print_submit_button (__('Set value'), 'set_value', false, 'class="sub upd"', true);
	$table->data[3][1] .= print_submit_button (__('Calculate'), 'calculate', false, 'class="sub search"', true);
	
	'<form id="calculator_form">';
	print_table ($table, false);
	'</form>';
	
	exit;
}

if($get_workunits_task){
	global $config;

	$id_task = get_parameter('id_task');
	$offset = get_parameter("offset");
	$block_size = $config['block_size'];
	// Get all the workunits
	$sql_count = sprintf('SELECT count(final.id_user) FROM ( SELECT tw1.id_user,tw1.timestamp,tw1.duration,tw1.description,NULL AS id_incidencia,
															NULL AS titulo,NULL AS estado
															FROM tworkunit tw1
															INNER JOIN tworkunit_task twt
															ON tw1.id = twt.id_workunit
															AND twt.id_task = %d
					UNION
						SELECT tw2.id_user,tw2.timestamp,tw2.duration,tw2.description,twin.id_incidencia,twin.titulo,twin.estado FROM tworkunit tw2
								INNER JOIN (SELECT twi.id_workunit,ti.id_incidencia,ti.titulo,tis.name AS estado
											FROM tworkunit_incident twi
											INNER JOIN tincidencia ti
											ON twi.id_incident = ti.id_incidencia
											AND ti.id_task = %d
											INNER JOIN tincident_status tis
											ON ti.estado = tis.id
											) twin
						ON tw2.id = twin.id_workunit
						) final
				ORDER BY final.id_user, final.timestamp',
				$id_task, $id_task);

	$sql = sprintf('SELECT final.id_user AS id_user,
					DATE(final.timestamp) AS date,
					final.duration AS duration,
					final.description AS content,
					final.id_incidencia AS ticket_id,
					final.titulo AS ticket_title,
					final.estado AS ticket_status
				FROM (
					SELECT tw1.id_user,
						tw1.timestamp,
						tw1.duration,
						tw1.description,
						NULL AS id_incidencia,
						NULL AS titulo,
						NULL AS estado
					FROM tworkunit tw1
					INNER JOIN tworkunit_task twt
						ON tw1.id = twt.id_workunit
							AND twt.id_task = %d
					
					UNION
					
					SELECT tw2.id_user,
						tw2.timestamp,
						tw2.duration,
						tw2.description,
						twin.id_incidencia,
						twin.titulo,
						twin.estado
					FROM tworkunit tw2
					INNER JOIN (
						SELECT twi.id_workunit,
							ti.id_incidencia,
							ti.titulo,
							tis.name AS estado
						FROM tworkunit_incident twi
						INNER JOIN tincidencia ti
							ON twi.id_incident = ti.id_incidencia
								AND ti.id_task = %d
						INNER JOIN tincident_status tis
							ON ti.estado = tis.id
					) twin
						ON tw2.id = twin.id_workunit
				) final
				ORDER BY final.id_user, final.timestamp limit %d offset %d',
				$id_task, $id_task, $block_size, $offset);
	
	$all_wu = get_db_all_rows_sql($sql);
	$count = get_db_value_sql($sql_count);
	
	if (!empty($all_wu)) {
		$table_wu = new StdClass();
		$table_wu->class = 'listing';
		$table_wu->head = array();
		$table_wu->head['person'] = __('Person');
		$table_wu->head['date'] = __('Date');
		$table_wu->head['duration'] = __('Duration ('.__('In hours').')');
		$table_wu->head['ticket_id'] = __('Ticket id');
		$table_wu->head['ticket_title'] = __('Ticket title');
		$table_wu->head['ticket_status'] = __('Ticket status');
		if (!$pdf_output)
			$table_wu->head['content'] = __('Content');
		$table_wu->data = array();
		
		foreach ($all_wu as $wu) {
			// Add the values to the row
			$row = array();
			$row['id_user'] = $wu['id_user'];
			$row['date'] = $wu['date'];
			$row['duration'] = (float)$wu['duration'];
			
			$row['ticket_id'] = $wu['ticket_id'] ? '#'.$wu['ticket_id'] : '';
			$row['ticket_title'] = $wu['ticket_title'];
			$row['ticket_status'] = $wu['ticket_status'];
			
			if (!$pdf_output) {
				$row['content'] = sprintf(
						'<div class="tooltip_title" title="%s">%s</div>',
						$wu['content'],
						print_image ("images/note.png", true)
					);
			}
			$table_wu->data[] = $row;
		}

		echo ui_pagination ($count, $url_pag, $offset);
		echo '<div class = "get_workunits_task">';
			echo print_table ($table_wu);
		echo '<div>';
		echo ui_pagination ($count, $url_pag, $offset, 0, false, true);
	}
}

//Use in reporting for change projects and task for projects
if($change_id_project){
	$id_project = (int) get_parameter('id_project', 0);

	if($id_project){
		$return = get_all_task_for_proyect_access($id_project);
		if($return){
			echo json_encode($return);
			return;
		}
		else{
			return false;	
		}
	}
	else{
		return false;
	}
}

if ($search_projects_form) {
	global $config;
	
	$search_text = get_parameter ("search_text", "");
	$offset = get_parameter ("offset", 0);
	$id_workunit = get_parameter ("id_workunit", "");
	$limit = $config["block_size"];

	$where_clause2 = "";
	if ($search_text != "") {
		$where_clause2 .= sprintf (" AND (tproject.name LIKE '%%%s%%' OR tproject.description LIKE '%%%s%%')", $search_text, $search_text);
	}
	$limitation_sql = "LIMIT $limit OFFSET $offset";
	$projects = get_db_all_rows_sql ("SELECT * FROM tproject WHERE disabled = 0 $where_clause2 $limitation_sql");

	//Check project ACLs
	$aux_projects = array();
	foreach ($projects as $p) {
		$project_access = get_project_access ($config["id_user"], $p['id']);
		if ($project_access["read"]) {
			array_push($aux_projects, $p);
		}
	}

		
	//Set filtered projects
	$projects = $aux_projects;

	// Count total projects
	$count = get_db_sql("SELECT COUNT(id) FROM tproject WHERE disabled = 0 $where_clause2");
	

	// Build search bar and button
		$s_bar = '<div>';
			$s_bar .= '<div style="float: left; margin: 8px;">';
				$s_bar .= print_input_text ("search_text", $search_text, '', 50, 0, true, __('Search text'));
			$s_bar .= "</div>";
			$s_bar .= "<div class='button-form'>";
				$s_bar .= print_submit_button (__('Search'), 'search', false, 'class="sub search"', true);
			$s_bar .= "</div>";
		$s_bar .= "</div>";

	// Data
	$data = '';
	if ($projects !== false) {
		// Table with data only if there is data
		$table = new stdClass;
		$table->class = '';
		$table->width = '90%';
		$table->class = 'listing';
		$table->head = array (
			'<b>'.__('ID').'</b>',
			'<b>'.__('Name').'</b>',
			'<b>'.__('Description').'</b>'
		);
		foreach ($projects as $project) {
			// Mark as disabled if no access right
			$name = get_project_access ($config['id_user'], $project['id'])
				? "<a href='javascript:loadProjectName(\"" . $project['name'] . "\", \"$id_workunit\");'>" . $project['name'] . '</a>'
				: $project['name'];
			$description = $project['description'] ? $project['description'] : '--';

			// Build the row
			$row = array (
				$project['id'],
				$name,
				$description
			);
			$table->data[] = $row;
		}
		$data = print_table($table, true);
	} else {
		$data = ui_print_error_message(
			__('There are not projects to show.'), '', true, 'h3', true
		);
	}

	$pagination = ui_pagination ($count, false,	$offset, 0,	true);

	// Print the form
	$output = '<form name="wupf" method=post id="saved-projects-form">';
		$output .= $s_bar;
		$output .= $data;
		$output .= $pagination;
	$output .= '</form>';

	echo $output;
}

if ($delete_task_user) {

	$id_user_task = get_parameter('id_user_task');
	if ($id_user_task){
		$sql = sprintf('DELETE FROM trole_people_task WHERE id = %d', $id_user_task);
		$ret = process_sql($sql);
	}
}

if ($add_user_task) {
	$id_task = get_parameter('id_task');
	$id_project = get_parameter('id_project');
	
	$sql = "SELECT * FROM trole_people_project WHERE id_project = ".$id_project." ORDER by id_user";
	$user_task = get_db_all_rows_sql ($sql);
	$u_task = array ();
	if ($user_task) {
		foreach ($user_task as $u) {
			$u_task [$u['id_user']] = $u['id_user'];
		}
	}
	echo	"<div>";
	echo 		"<form id='form-people_manager' method='post' style='width:200px !important;'";
	echo 		"action='index.php?sec=projects&sec2=operation/projects/project_detail&id_project=$id_project&action=insert'>";
	echo 			"<table width=100% class='search-table'>";
	echo 				"<tr>";
	echo 					"<td>";
	echo 						__('Role');
	echo 						combo_roles();
	echo 					"</td>";
	echo 				"</tr>";
	echo 				"<tr>";
	echo 					"<td>";
	echo 						__('User')."<br>";
	echo							print_select ($u_task, 'text-user', '', '', '', '', true, 0, true, false, false, "width:218px");
	echo 					"</td>";
	echo 				"</tr>";
	echo 				"<tr>";
	echo 					"<td style='text-align:center;'>";
	echo 						"<input style='margin-bottom:-5px;' type=submit class='sub next' value='".__('Update')."'>";
	echo 					"</td>";
	echo 				"</tr>";
	echo 			"</table>";
	echo 		"<input type='hidden' id='hidden-id_task' name='task' value='".$id_task."'>";
	echo 		"</form>";
	echo 	"</div>";
}

if ($upload_file) {
	$id_project = get_parameter("id_project");
	$result = array();
	$result["status"] = false;
	$result["message"] = "";
	$result["id_attachment"] = 0;

	$upload_status = getFileUploadStatus("upfile");
	$upload_result = translateFileUploadStatus($upload_status);

	if ($upload_result === true) {
		$filename = $_FILES["upfile"]['name'];
		$extension = pathinfo($filename, PATHINFO_EXTENSION);
		$invalid_extensions = "/^(bat|exe|cmd|sh|php|php1|php2|php3|php4|php5|pl|cgi|386|dll|com|torrent|js|app|jar|iso|
			pif|vb|vbscript|wsf|asp|cer|csr|jsp|drv|sys|ade|adp|bas|chm|cpl|crt|csh|fxp|hlp|hta|inf|ins|isp|jse|htaccess|
			htpasswd|ksh|lnk|mdb|mde|mdt|mdw|msc|msi|msp|mst|ops|pcd|prg|reg|scr|sct|shb|shs|url|vbe|vbs|wsc|wsf|wsh)$/i";
		
		if (!preg_match($invalid_extensions, $extension)) {
			$filename = str_replace (" ", "_", $filename); // Replace conflictive characters
			$filename = filter_var($filename, FILTER_SANITIZE_URL); // Replace conflictive characters
			$file_tmp = $_FILES["upfile"]['tmp_name'];
			$filesize = $_FILES["upfile"]["size"]; // In bytes

			$values = array(
					"id_project" => $id_project,
					"id_usuario" => $config['id_user'],
					"filename" => $filename,
					"description" => "",
					"size" => $filesize,
					"timestamp" => date("Y-m-d H:i:s")
				);
			$id_attachment = process_sql_insert("tattachment", $values);

			if ($id_attachment) {
				$location = $config["homedir"]."/attachment/".$id_attachment."_".$filename;

				if (copy($file_tmp, $location)) {
					// Delete temporal file
					unlink ($file_tmp);
					$result["status"] = true;
					$result["id_attachment"] = $id_attachment;
				}
				else {
					unlink ($file_tmp);
					process_sql_delete ('tattachment', array('id_attachment' => $id_attachment));
					$result["message"] = __('The file could not be copied');
				}
			}
		} else {
			$result["message"] = __('Invalid extension');
		}

	} else {
		$result["message"] = $upload_result;
	}

	echo json_encode($result);
	return;
}

if ($update_file_description) {
	$id_file = (int) get_parameter("id_attachment");
	$file_description = get_parameter("file_description");
	$result = array();
	$result["status"] = false;
	$result["message"] = "";

	$result['status'] = (bool) process_sql_update('tattachment',
		array('description' => $file_description), array('id_attachment' => $id_file));

	if (!$result['status'])
		$result['message'] = __('Description not updated');

	echo json_encode($result);
	return;
}

if ($get_file_row) {
	include_once ("include/functions_projects.php");
	
	$id_file = (int) get_parameter("id_attachment");
	$id_project = (int) get_parameter("id_project");
	$file = get_db_row_filter ('tattachment', array('id_project' => $id_project, 'id_attachment' => $id_file));
	
	$section_access = get_project_access ($config['id_user']);
	if ($id_project) {
		$project_access = get_project_access ($config['id_user'], $id_project);
	}
	$html = "";
	if ($file) {
		$link = "operation/common/download_file.php?id_attachment=".$file["id_attachment"]."&type=project";
		$real_filename = $config["homedir"]."/attachment/".$file["id_attachment"]."_".rawurlencode ($file["filename"]);    

		$html .= "<tr>";
		$html .= "<td valign=top>";
		$html .= '<a target="_blank" href="'.$link.'">'. $file['filename'].'</a>';
		
		$html .= "<td valign=top class=f9>". $file["description"];
		//$html .= "<td valign=top>". $file["id_usuario"];
		$html .= "<td valign=top>". byte_convert ($file['size']);
		
		$stat = stat ($real_filename);
		$html .= "<td valign=top class=f9>".date ("Y-m-d H:i:s", $stat['mtime']);
		// Delete attachment
		if ($section_access['manage']){
		if ( (dame_admin($config["id_user"])) || ($file["id_usuario"] == $config["id_user"]) ) {
			$html .= "<td>". '<a class="delete" name="delete_file_'.$file["id_attachment"]
			.'" href="index.php?sec=projects&sec2=operation/projects/project_files&id_project='
			.$id_project.'&deletef='.$file["id_attachment"].'">
			<img src="images/cross.png"></a>';
		}
		}
	}

	echo $html;
	return;
}

if ($delete_project_file) {
	echo "<div>";
		echo "<div style='float: left;'><img style='padding:10px;' src='images/icon_delete.png' alt='".__('Delete')."'></div>";
		echo "<div style='float: left; font-size:15px; font-weight: bold; margin-top:32px;'><b>".__('Are you sure you want to delete?')."</b></br>";
		echo "<span style='font-size:13px; font-weight: normal; line-height: 1.5em;'>" . __('This action can not be undone'). "</span></div>";
		echo "<form id='validation_delete_form' method='post'>";
			echo print_submit_button (__('Delete'), "delete_btn", false, 'class="sub close" width="160px;"', true);
			echo print_button (__('Cancel'), 'modal_cancel', false, '', '', false);
		echo "</form>";
	echo "</div>";
}

?>
