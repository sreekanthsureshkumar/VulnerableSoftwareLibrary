<?php
	global $config;
	global $REMOTE_ADDR;

	$message = get_parameter('message', '');

	$global_validation = get_parameter('get_global_validation', 0);

	if(!empty($message)){
		echo "<div>";
			echo "<div style='float: left;'><img style='padding:10px;' src='images/icono_exito_grande.png' alt='".__('Information')."'></div>";
			echo "<div style='float: left; font-size:15px; font-weight: bold; margin-top:32px;'><b>".__($message)."</b></br></div>";
			echo '<form id="validation_info_form" method="post">';
				echo print_button (__('Accept'), 'info_modal_cancel', false, '', '', false);
			echo '</form>';
		echo "</div>";
	};

	if ($global_validation){
		echo "<div>";
			echo "<table style = 'border-collapse: collapse; width: 100%'><tr><td><div style='float: left;'><img style='padding:10px;' src='images/icon_delete.png' alt='".__('Global Validation')."'></div></td>";
		echo "<td><div style='float: left; font-size:15px; font-weight: bold; margin-top:32px;'><b>".__('Are you sure you want to mark this field as global?')."</b></br>";
			echo "<span style='font-size:13px; font-weight: normal; line-height: 1.5em;'>" . __('Once created, it cannot be changed.'). "</span></div></td></tr></table>";
			echo '<form id="validation_accept_form" method="post">';
				echo print_submit_button (__('Accept'), "accept_btn", false, 'class="sub close" width="160px;"', true);
				echo print_button (__('Cancel'), 'modal_cancel', false, '', '', false);
			echo '</form>';
		echo "</div>";
	}
