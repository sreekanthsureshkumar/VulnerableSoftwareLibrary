<?php

// Integria IMS - http://integriaims.com
// ==================================================
// Copyright (c) 2008 Artica Soluciones Tecnologicas
// Copyright (c) 2008 Esteban Sanchez, estebans@artica.es

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

global $config;

include_once ('include/functions.php');
include_once ('include/functions_ui.php');
include_once ('include/functions_calendar.php');

$get_alerts = get_parameter ('get_alerts', 0);
$get_alert_popup = get_parameter('get_alert_popup', 0);
$check_alarms_popup = get_parameter('check_alarms_popup', 0);
$set_alarm_checked = get_parameter('set_alarm_checked', 0);
$get_vacation_day_popup = get_parameter('get_vacation_day_popup', 0);

if ($get_alerts) {

	$check_cron = check_last_cron_execution ();
	$check_emails = check_email_queue ();
	$minutes_last_exec = check_last_cron_execution (true);
	$seconds_last_exec = $minutes_last_exec * 60;
	$queued_emails = check_email_queue (true);
	$update_manager_msg = get_parameter ('update_manager_msg', '');
	$check_alarm_calendar = check_alarm_calendar();
	$check_directory_permissions = check_directory_permissions();
	$check_minor_release_available = db_check_minor_relase_available ();
	$check_browser = check_browser();
	$is_vacation_day = check_if_today_is_vacation_day();
	$one_last_manager = check_one_last_manager();
	$one_last_regular = check_one_last_regular();

	$alerts = '<div style = "padding: 15px;">';
	
	if ($one_last_manager) {
	$manager_users = license_count_manager_users();
	$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
	$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
	$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; margin-top:20px;">'.__('You have '.$manager_users.' manager users created. One more manager user left to reach the license limit.').'</p></td>';
	$alerts .= '</tr>';
	$alerts .= '</table></div>';
	}
	
	if ($one_last_regular) {
	$regular_users = license_count_regular_users();
	$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
	$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
	$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; margin-top:20px;">'.__('You have '.$regular_users.' regular users created. One more regular user left to reach the license limit.').'</p></td>';
	$alerts .= '</tr>';
	$alerts .= '</table></div>';
	}

	if ($minutes_last_exec == '') {
	$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
	$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
	$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; margin-top:20px;">'.__('Crontask not installed. Please check documentation!').'</p></td>';
	$alerts .= '</tr>';
	$alerts .= '</table></div>';
	}
	if (!$check_cron) {
		$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
		$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
		$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; margin-top:20px;">'.__('Last time Crontask was executed was ').calendar_seconds_to_humand($seconds_last_exec).__(' ago').'</p></td>';
		$alerts .= '</tr>';
		$alerts .= '</table></div>';

	}
	if (!$check_emails) {
		$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
		$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
		$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; margin-top:20px;">'.__('Too many pending mail in mail queue: ').$queued_emails.__('. Check SMTP configuration').'</p></td>';
		$alerts .= '</tr>';
		$alerts .= '</table></div>';
	}
	if ($update_manager_msg != '') {
		$update_manager_msg .= "<br><a href='index.php?sec=godmode&sec2=godmode/setup/update_manager'>".
							__("Go to Update Manager")."</a>";
		$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
		$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
		$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:20px;">'.$update_manager_msg.'</p></td>';
		$alerts .= '</tr>';
		$alerts .= '</table></div>';

	}
	if ($check_alarm_calendar) {
		$alarm_calendar_msg = '';
		$alarms = check_alarm_calendar(false);

		if ($alarms) {
			$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
			$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>'.'<td colspan="2"><p style="width:100%; font-size:15px !important; font-weight: bold;">'.__('Calendar alert: ').'</p></td></tr>';
			foreach ($alarms as $alarm) {
				$time = substr($alarm['timestamp'], 11, 5);
				$msg = '<tr><td></td><td style = "width: 50%;"><p style="font-size:15px !important; ">
				<a href="index.php?sec=agenda&sec2=operation/agenda/agenda"><b style="color: #FF9000;">'.__('Name'). ': </b>'. __($alarm['title']).'
				</a></p></td><td><p style="font-size:15px !important; "><b style="color: #FF9000;">'.__('Time'). ': </b>'.$time.'</p>
				<td></td></tr><tr><td></td>
				<td colspan="2" style="padding-right: 30px;" ><p style="width:100%; font-size:15px !important; margin-top:13px; margin-bottom: 20px; margin-right: 20px;">'.$alarm['description'].'</p></td></tr>';
				$alerts .= $msg;
			}
			$alerts .= '</table></div>';
		}
	}
	if ($check_directory_permissions) {
		$attachment = check_writable_attachment();
		if ($attachment != '') {
			$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
			$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
			$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:13px; margin-bottom: 15px;">'.$attachment.'</p></td>';
			$alerts .= '</tr>';
			$alerts .= '</table></div>';
		}

		$tmp = check_writable_tmp();
		if ($tmp != '') {
			$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
			$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
			$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:20px;">'.$tmp.'</p></td>';
			$alerts .= '</tr>';
			$alerts .= '</table></div>';
		}

		$mr = check_writable_mr();
		if ($mr != '') {
			$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
			$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
			$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:20px;">'.$mr.'</p></td>';
			$alerts .= '</tr>';
			$alerts .= '</table></div>';
		}
	}
	if ($check_minor_release_available) {
		$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
		$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
		$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:20px;">'.__('You must logout and login again to update database schema.').'</p></td>';
		$alerts .= '</tr>';
		$alerts .= '</table></div>';
	}
	if ($check_browser) {
		$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
		$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
		$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:20px;">'.__('Recommended browsers are Firefox and Chrome. You are using another browser.').'</p></td>';
		$alerts .= '</tr>';
		$alerts .= '</table></div>';
	}
	if ($is_vacation_day) {
		$alerts .= '<div style = "background: #EEEEEE; border-radius:5px; border: 1px solid #E7E7E7; margin-top: 9px;"><table style = "border-collapse: collapse; width: 100%" >';
		$alerts .= '<tr><td style = "width: 13%;"><img style="padding:10px;" src="./images/icono_info.png"></td>';
		$alerts .= '<td style = "vertical-align: top;"><p style="width:100%; font-size:15px !important; font-weight: bold; margin-top:20px;">Today is a vacation day, click <a href="javascript:void(0);" onclick="show_mini_calendar()">here</a> to see the calendar.</p></td>';
		$alerts .= '</tr>';
		$alerts .= '</table></div>';

		echo "<div class= 'dialog ui-dialog-content' title='".__("Vacation days")."' id='vacation_day_dialog'></div>";
	}
	$alerts .= '</div>';
	echo $alerts;
	echo '<br>';
	echo '<br>';
	print_button (__("Close"), "modal_cancel", false, 'closeAlertDialog()');
	return;
}

if ($get_alert_popup) {
	$id = get_parameter('id');

	$alarm_calendar_msg = '';
	$alarm = check_alarm_calendar(false, $id);
	$time = substr($alarm['timestamp'], 11, 5);

	$alarm_calendar_msg = '<h3><a style="font-family: Verdana; font-size:16px; font-weight: normal; line-height: 1.5em;" href="index.php?sec=agenda&sec2=operation/agenda/agenda">'.$time.' '. __($alarm['title']).'</a></h3><h4 style="font-family: Verdana; font-size:14px; font-weight: normal; line-height: 1.5em;">'.$alarm['description'].'</h4>';
	echo $alarm_calendar_msg;
	return;

}

if ($get_vacation_day_popup) {
	$alarm_vacation_day_msg = '<div style="text-align:center;">';
	$alarm_vacation_day_msg .= generate_calendar (date ('y'), date ('n'), array(), 1, NULL, $config["first_day_week"]);
	$alarm_vacation_day_msg .= '</div>';

	echo $alarm_vacation_day_msg;
	return;

}

if ($check_alarms_popup) {

	$alarms = check_alarm_calendar(false);
	$i = 0;
	foreach ($alarms as $alarm) {
		$file_path = $config["homedir"]."/attachment/calendar/alarm_".$alarm['id']."_".$alarm['timestamp'].".txt";
		if (!file_exists($file_path)) {
			$result[$i]['id'] = $alarm['id'];
			$i++;
		}
	}
	echo json_encode($result);
	return;
}

// TO DO: Create a field 'checked' in tagenda
if ($set_alarm_checked) {
	$id = get_parameter('id');
	$timestamp = get_db_value('timestamp', 'tagenda', 'id', $id);
	$full_path = $config["homedir"]."/attachment/calendar/alarm_".$id."_".$timestamp.".txt";
	$file = fopen ($full_path, "w");
	fclose($file);
	return;
}



?>
