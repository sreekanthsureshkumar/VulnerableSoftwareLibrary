<?php
	global $config;
	global $REMOTE_ADDR;

$ticket_sc = get_parameter('get_ticket_sc', 0);


if ($ticket_sc){
	echo "<table style = 'border-collapse: collapse; width: 100%' ><tr><td style = 'width: 13%;'>";
	
	
	echo "<img style='padding-right:15px; padding-left:15px; padding-bottom: 28px;' src='images/icono-estrella.png' width=57, style='top:0px;'>";
	echo "</td><td style = 'padding-right: 30px'>";
		echo "<b style= 'color: #FF9000'>".__('Please rate us!')."</b><br>";
		echo  __('Please, help to improve the service and give us a score for the resolution of this ticket. People assigned to this ticket will not view directly your scoring.');
		echo "<br>";
		echo "</td></tr><tr><td></td><td><div style= 'padding: 13px'>";
				echo "<input type='radio' name='score' id='score_ticket' value='10'> ".__("Very good, excellent. ")."</option>";
				echo "<br>";
				echo "<input type='radio' name='score' id='score_ticket' value='8'> ".__("Good, very well.")."</option>";
				echo "<br>";
				echo "<input type='radio' name='score' id='score_ticket' value='6'> ".__("It's ok, but could be better.")."</option>";
				echo "<br>";
				echo "<input type='radio' name='score' id='score_ticket' value='5'> ".__("Average. Not bad, not good.")."</option>";
				echo "<br>";
				echo "<input type='radio' name='score' id='score_ticket' value='4'> ".__("Bad, you must to better.")."</option>";
				echo "<br>";
				echo "<input type='radio' name='score' id='score_ticket' value='2'> ".__("Very bad.")."</option>";
				echo "<br>";
				echo "<input type='radio' name='score' id='score_ticket' value='1'> ".__("Horrible, you need to change it.")."</option>";
				echo "<br></div>";
				echo "</td></tr><tr><td colspan= '2' style='padding-left: 50px; padding-top: 10px;'><input type='checkbox' name='never_show' id='never_show' value='11'>Don't show me again.</option></td>";

			
		echo"</tr></table>";
		echo "</form>";
		
		echo print_submit_button (__('Score'), "accept_btn", false, 'class="sub close" width="160px;"', true);
		}	