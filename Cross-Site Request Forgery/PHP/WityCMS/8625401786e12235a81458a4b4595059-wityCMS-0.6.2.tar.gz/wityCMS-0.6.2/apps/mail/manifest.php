<?php defined('WITYCMS_VERSION') or die('Access denied'); ?>
<?xml version="1.0" encoding="utf-8" ?>
<app>
	<!-- Application name -->
	<name>Mail</name>

	<version>0.6.2</version>

	<!-- Last update date -->
	<date>25-11-2013</date>

	<!-- Permissions -->
	<permission name="whitelist_manager" />

	<!-- Front actions -->
	<action default="default">send</action>
	<action>redirect</action>
</app>
