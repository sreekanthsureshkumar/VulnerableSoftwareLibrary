/**
 * Slideshow JavaScript logic for animation.
 */

require(['jquery', 'wityslider'], function($) {
	setTimeout(function() {
		$('.wity-app-slideshow .slideshow').addClass('ready');
	}, 20);
});
