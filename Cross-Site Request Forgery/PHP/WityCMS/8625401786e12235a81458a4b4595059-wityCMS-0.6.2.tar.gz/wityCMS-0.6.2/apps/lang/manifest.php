<?php defined('WITYCMS_VERSION') or die('Access denied'); ?>
<?xml version="1.0" encoding="utf-8" ?>
<app>
	<!-- Application name -->
	<name>Lang</name>

	<version>0.6.2</version>

	<!-- Last update date -->
	<date>14-06-2015</date>

	<!-- Front actions -->
	<action default="default">select</action>
</app>
