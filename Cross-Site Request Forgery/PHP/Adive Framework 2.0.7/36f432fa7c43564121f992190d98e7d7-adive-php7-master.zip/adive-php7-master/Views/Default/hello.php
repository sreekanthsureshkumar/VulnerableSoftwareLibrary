    <h1>Hello <?=$example?>!</h1>
    <p class="lead">This is a "Hello World!" example, passing a $var in the URL like <code>hello/John</code>.</p>
    
    <section style="padding-top: 20px">
        <h3>Edit this "Hello World!" example</h3>
        <p>
            The Controller is located on <code>Controller/Default.php</code>, edit this file and change it, go ahead!
        </p>

        <h3>Twitter</h3>
        <p>
            Visit <a href="https://adive.es" target="_blank">Adive PHP7 Framework</a> site to get in touch, watch it, star it and fork it!.
        </p>
    </section>
