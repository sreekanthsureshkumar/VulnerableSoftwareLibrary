<?php
/**
* My Procedure "Hello World!"
*/
function helloWorld (){
    echo 'Hello World!';
}

/**
* Some function that does nothing
*/
function someFunction(){
    echo 'Some function!';
}

/**
* Another function that does nothing
*/
function newFunction(){
    echo 'New function!';
}