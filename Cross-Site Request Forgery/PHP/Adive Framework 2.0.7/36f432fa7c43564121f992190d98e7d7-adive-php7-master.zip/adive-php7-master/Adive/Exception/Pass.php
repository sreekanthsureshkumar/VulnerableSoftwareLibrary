<?php
namespace Adive\Exception;

class Pass extends \Exception
{
}
