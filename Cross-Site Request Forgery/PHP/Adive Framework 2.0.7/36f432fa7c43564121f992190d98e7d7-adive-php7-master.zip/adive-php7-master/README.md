# adive-php7
Adive Framework for PHP7 www.adive.es

# Adive Framework 2.0.7
Adive is a PHP 7 Framework to develope webs and online apps 10 times faster with a dashboard that manages MySQL databases, a fast, easy and great alternative to PhpMyAdmin.

This version includes a developer toolkit to generate tables, fields and entities, control forms and databases, Adive is an ambitious project from Schben, which aims to turn the "coding" in "design".

# DevToolkit login
The path to DevToolkit is in admin/dashboard.

Default login details for ADMIN privileges are:
admin:admin

Default User/Client privileges access are:
user:user

# Changelog 2.0.7
- Added new security requeriments.
- Added new field type: Passwords.

# Changelog 2.0.6
- Fixed bug with image post input.

# Changelog 2.0.5
- Fixed security bug.
- Added new functionality with visible/invisible fields in forms.
- Adive.time property added for parallel workflow inclusion.

# Changelog 2.0.4
- Fixed icon design in navigation menu.
- Added icon to breadcrumb in insert/update view.

# Changelog 2.0.3
- Fixed error in upload images for C:/Fakepath.
- Added user access management.
- Added "Code generated" in Tables for copy/paste in Controller or HTML.
