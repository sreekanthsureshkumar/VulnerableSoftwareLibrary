<?php

namespace Addons\Book;
use Common\Controller\Addon;

class BookAddon extends Addon{

    public $info = array(
        'name'=>'Book',
        'title'=>'留言',
        'description'=>'留言接口',
        'status'=>1,
        'author'=>'弘讯科技',
        'version'=>'1.0',
        'group'=>'nav',
        'mold'=>'web,wap,wechat',
        'has_hook'=>0,
        'exclusive'=>0,
        'sort'=>1
    );

    public function install(){
        $dataList[] = array('name'=>'addons/book/index','title'=>'留言','value'=>'["addons/run",{"addon_name":"Book","addon_run":"index"}]','display'=>0,'addons'=>'book');
        $dataList[] = array('name'=>'addons/book/add','title'=>'添加留言','value'=>'["addons/run",{"addon_name":"Book","addon_run":"add"}]','display'=>0,'addons'=>'book');
        $dataList[] = array('name'=>'addons/book/edit','title'=>'留言编辑','value'=>'["admin/addons/run",{"addon_name":"Book","addon_run":"edit"}]','display'=>0,'addons'=>'book');
        $dataList[] = array('name'=>'addons/book/del','title'=>'留言删除','value'=>'["admin/aaddons/run",{"addon_name":"Book","addon_run":"del"}]','display'=>0,'addons'=>'book');
        $dataList[] = array('name'=>'addons/book/replydel','title'=>'回复删除','value'=>'["admin/aaddons/run",{"addon_name":"Book","addon_run":"replydel"}]','display'=>0,'addons'=>'book');
        M('route')->addAll($dataList);
        $data=array('title'=>'留言管理','pid'=>3,'url'=>'Addons/adminlist?name=Book&run=adminlist','group'=>'留言');
        M('menu')->add($data);
        $db_prefix = C('DB_PREFIX');
        $Model = M();
        $Model->execute("DROP TABLE IF EXISTS `".$db_prefix."book`");
        $Model->execute("CREATE TABLE `".$db_prefix."book` (`id` int(11) unsigned NOT NULL AUTO_INCREMENT,`user` varchar(100) NOT NULL DEFAULT '',`content` text NOT NULL,`create_time` int(11) unsigned NOT NULL DEFAULT '0',`reply_content` text COMMENT '回复内容',`reply_time` int(11) unsigned DEFAULT '0' COMMENT '回复内容',PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='留言表';");
        return true;
    }

    public function uninstall(){
        M('route')->where(array('addons'=>'book'))->delete();
        M('menu')->where(array('group'=>'留言'))->delete();
        $db_prefix = C('DB_PREFIX');
        $Model = M();
        $Model->execute("DROP TABLE `".$db_prefix."book`");
        return true;
    }

    //实现的pageFooter钩子方法
    public function index($param){
    	$addon_config=$this->getConfig();
    	$model  =   M('book');
    	$total  =   $model->count();
    	$page = new \Think\Page($total, $addon_config['rows'], $REQUEST);
        if($total>$addon_config['rows']){
            if(MOBILE=='wap'){
                $page->setConfig("theme","%UP_PAGE% %DOWN_PAGE%");
            }
        }
        $p =$page->show();
        $list=$model->limit($page->firstRow.','.$addon_config['rows'])->order('id desc')->select();
        $this->assign('_page', $p? $p: '');
        $this->assign('_total',$total);
        $this->assign('list',$list);
    	$this->display('book');
    }

    public function add(){
    	if(IS_POST){ //提交表单
            $rules = array(
                array('title', '1,30', '用户昵称1-30个字', 0, 'length' , 3),
                array('content', '4,200', '留言内容4-200个字', 0, 'length' , 3)
            );
            $book = M('book');
            if (!$book->validate($rules)->create()){     // 如果创建失败 表示验证没有通过 输出错误提示信息     
                $this->error($book->getError());
            }else{
                $book->content=$this->filterContent($book->content);
                $book->create_time=NOW_TIME;
                $book->add();
                $this->success('留言成功！', U('addons/Book/index'));
            }
        }
    }

    public function adminlist(){
        $addon_config=$this->getConfig();
        $model  =   M('book');
        $total  =   $model->count();
        $page = new \Think\Page($total, $addon_config['rows'], $REQUEST);
        $p =$page->show();
        $list=$model->limit($page->firstRow.','.$addon_config['rows'])->order('id desc')->select();
        $this->assign('_page', $p? $p: '');
        $this->assign('_total',$total);
        $this->assign('list',$list);
        $this->display('adminlist');
    }

    public function del(){
        if(M('book')->where(array('id'=>I('id')))->delete()){
            $this->success('删除成功');
        } else {
            $this->error('删除失败！');
        }
    }

    public function replydel(){
        M('book')->where(array('id'=>I('id')))->save(array('reply_content'=>null,'reply_time'=>null));
        $this->success('回复删除成功');
    }

    public function edit(){
        if(IS_POST){ //提交表单
            $book = M('book');
            $book->create();
            if(I('get.type')!='edit'){
                $book->reply_time=NOW_TIME;
            }
            $book->save();
            if(I('get.type')!='edit'){
                $this->success('回复成功！');
            }else{
                $this->success('修改成功！');
            }
        }else{
            $info=M('book')->where(array('id'=>I('id')))->find();;
            $this->assign('book',$info);
            if(I('get.type')!='edit'){
                $this->meta_title = '回复留言';
            }else{
                $this->meta_title = '修改留言';
            }
            $this->display('adminedit');
        }
    }

    protected function filterContent($str){
        $addon_config=$this->getConfig();
        $str = htmlspecialchars($str);
        $str = str_replace(explode(PHP_EOL,$addon_config['filtration']), '***', $str);
        return $str;
    }
}