<?php
return [
	'rows'=>[//配置在表单中的键名 ,这个会是config[random]
		'title'=>'每页记录数:',//表单的文字
		'type'=>'text',		 //表单的类型：text、textarea、checkbox、radio、select等
		'value'=>'20',			 //表单的默认值
	],
	'filtration'=>[//配置在表单中的键名 ,这个会是config[random]
		'title'=>'过滤敏感词:',//表单的文字
		'type'=>'textarea',		 //表单的类型：text、textarea、checkbox、radio、select等
		'value'=>'http://\r\nwww\r\nqq\r\ncom\r\nnet',			 //表单的默认值
		'tip'=>'过滤敏感词,每行一个'
	]
];