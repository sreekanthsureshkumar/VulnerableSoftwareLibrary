<?php

namespace Addons\Tv;
use Common\Controller\Addon;

class TvAddon extends Addon{

    public $info = array(
        'name'=>'Tv',
        'title'=>'电视直播',
        'description'=>'电视直播接口',
        'status'=>1,
        'author'=>'弘讯科技',
        'version'=>'1.0',
        'group'=>'nav',
        'mold'=>'web',
        'has_hook'=>0,
        'exclusive'=>0,
        'sort'=>1
    );

    public function install(){
        $dataList[] = array('name'=>'addons/tv/index','title'=>'电视直播','value'=>'["addons/run",{"addon_name":"Tv","addon_run":"index"}]','display'=>0,'addons'=>'tv');
        M('route')->addAll($dataList);
        return true;
    }

    public function uninstall(){
        M('route')->where(array('addons'=>'tv'))->delete();
        return true;
    }

    //实现的pageFooter钩子方法
    public function index($param){
    	$this->display('tv');
    }
}