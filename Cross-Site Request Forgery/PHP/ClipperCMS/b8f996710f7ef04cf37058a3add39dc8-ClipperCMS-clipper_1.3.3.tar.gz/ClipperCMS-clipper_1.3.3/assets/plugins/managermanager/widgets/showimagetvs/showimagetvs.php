<?php

//---------------------------------------------------------------------------------
// mm_widget_showimagetvs
// Shows a preview of image TVs
// Emulates showimagestv plugin, which is not compatible with ManagerManager
//--------------------------------------------------------------------------------- 


function mm_widget_showimagetvs($tvs='', $w=300, $h=100, $thumbnailerUrl='', $roles='', $templates='') {
    global $modx;
    $modx->logEvent(0, 2, 'mm_widget_showimagetvs is no longer in ManagerManager. Please remove it from any rules chunks.');
} // end of widget

?>
