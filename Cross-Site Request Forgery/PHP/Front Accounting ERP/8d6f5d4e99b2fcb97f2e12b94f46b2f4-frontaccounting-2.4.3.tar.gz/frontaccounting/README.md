FrontAccounting ERP
===================

FrontAccounting ERP is open source, web-based accounting software for small and medium enterprises.
It supports double entry accounting providing both low level journal entry and user friendly, document based 
interface for everyday business activity with automatic GL postings generation. This is multicurrency,
multilanguage system with active worldwide users community:

Project web site http://frontaccounting.com

SourceForge project page: http://sourceforge.net/projects/frontaccounting/

Central users forum: http://frontaccounting.com/punbb/index.php

Main code repository: https://sourceforge.net/p/frontaccounting/git/ci/master/tree/

GitHub mirror: http://github.com/FrontAccountingERP/FA

Mantis bugtracker: http://mantis.frontaccounting.com

FrontAccounting is available under GPL v.3 license.

