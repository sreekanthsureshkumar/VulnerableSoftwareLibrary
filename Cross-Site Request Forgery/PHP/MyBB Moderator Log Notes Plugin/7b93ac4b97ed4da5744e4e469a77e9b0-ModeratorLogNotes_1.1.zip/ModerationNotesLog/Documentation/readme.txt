Moderator Log Notes
Advanced Mode on notes moderator.
Version: 1.0
Author: Edson Ordaz
Submitted: 5th June 2011
Last Updated: 15th June 2011
Plugin Name: Moderator Log Notes
Plugin Author: Edson Ordaz
Plugin Website: http://www.mybb-es.com
Plugin Version: 1.0
Plugin Mybb Compatibility: 1.6x
Plugin Language: English
Plugin File Edits: no
Plugin File Uploads: 1
Plugin Description: Advanced Mode on notes moderator..


This plugin is an advanced way of notes moderator.
What it does is store and display a list all the notes you have in the control panel moderator, they can be removed from the panel moderated by the moderators but not be removed from the log of notes on the administration panel that is due caused by the discussions.

To delete all notes must be done from administration panel as to remove the log of administration!


* Updated to version 1.1 for MyBB 1.8.x usage by: Vintagedaddyo