<?php
/*
 * MyBB: Moderator Log Notes
 *
 * File: modnoteslog.lang.php
 * 
 * Authors: Edson Ordaz, Vintagedaddyo
 *
 * MyBB Version: 1.8
 *
 * Plugin Version: 1.1
 * 
 */

// Redirect

$l['modnoteslog_Redirect'] = 'Did not publish your note because it has too few characters.';

?>