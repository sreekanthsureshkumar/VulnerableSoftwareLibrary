<?php
/*
 * MyBB: Moderator Log Notes
 *
 * File: modnoteslog.lang.php
 * 
 * Authors: Edson Ordaz, Vintagedaddyo
 *
 * MyBB Version: 1.8
 *
 * Plugin Version: 1.1
 * 
 */

// Redirect

$l['modnoteslog_Redirect'] = 'No publicó su nota porque tiene muy pocos caracteres.';

?>