<?php
/*
 * MyBB: Moderator Log Notes
 *
 * File: modnoteslog.lang.php
 * 
 * Authors: Edson Ordaz, Vintagedaddyo
 *
 * MyBB Version: 1.8
 *
 * Plugin Version: 1.1
 * 
 */

// Redirect

$l['modnoteslog_Redirect'] = 'Non ha pubblicato la tua nota perché ha pochi caratteri.';

?>