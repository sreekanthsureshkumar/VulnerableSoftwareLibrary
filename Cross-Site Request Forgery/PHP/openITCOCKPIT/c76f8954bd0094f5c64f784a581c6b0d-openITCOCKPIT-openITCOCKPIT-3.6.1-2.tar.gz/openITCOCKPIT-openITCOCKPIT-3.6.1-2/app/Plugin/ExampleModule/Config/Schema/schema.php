<?php

class ExampleModuleSchema extends CakeSchema {

    public function before($event = []) {
        return true;
    }

    public function after($event = []) {
    }

}
