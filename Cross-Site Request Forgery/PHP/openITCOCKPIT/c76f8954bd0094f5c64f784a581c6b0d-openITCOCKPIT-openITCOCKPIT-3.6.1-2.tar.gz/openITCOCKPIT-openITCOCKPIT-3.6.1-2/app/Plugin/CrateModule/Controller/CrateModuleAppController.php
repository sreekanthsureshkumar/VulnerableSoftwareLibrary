<?php

App::uses('AppController', 'Controller');

class CrateModuleAppController extends AppController {

}
