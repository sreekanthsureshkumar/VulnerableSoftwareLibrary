SET foreign_key_checks = 0;
TRUNCATE users;



SET foreign_key_checks = 1;
