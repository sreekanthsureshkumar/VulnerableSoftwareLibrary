<?php
$config = [
    'user_rights' => [
        'viewAllServiceStatuses' => [
            Types::ROLE_ADMIN,
        ],
    ],
];