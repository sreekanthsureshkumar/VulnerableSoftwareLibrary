 	<div class="col-md-2"></div>
	</div>
	<div class="row">
  		<div class="col-md-12" style="text-align: center;">&copy; 2018 LayerBB</div>
	</div>
</div>
</body>
</html>