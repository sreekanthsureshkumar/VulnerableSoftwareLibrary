<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<title>LayerBB Installer</title>
</head>
<body>
<div class="container">
<br /><br /><br /><br />
	<div class="row">
  		<div class="col-md-2"></div>
 		<div class="col-md-8"> 	
  			<div class="row">
  				<div class="col-md-6"><img src="assets/img/LayerBB_logo.png" /></div>
  				<div class="col-md-6" style="text-align: right;"><br /><h3>1.1.2</h3></div>
			</div>
			<br />