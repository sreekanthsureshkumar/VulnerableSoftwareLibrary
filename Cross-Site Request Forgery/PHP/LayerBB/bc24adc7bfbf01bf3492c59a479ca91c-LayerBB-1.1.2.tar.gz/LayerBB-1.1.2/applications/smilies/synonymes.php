<?php

$SYNONYM = array(
    //devil
    '}:-&gt;' => ':devil:',
    '}:-)' => ':devil:',
    '}:&gt;' => ':devil:',
    '}:)' => ':devil:',
    ']:-&gt;' => ':devil:',
    ']:-)' => ':devil:',
    ']:&gt;' => ':devil:',
    ']:)' => ':devil:',

    //angel
    'O:-)' => ':angel:',
    'O:)' => ':angel:',
    '0:-)' => ':angel:',
    '0:)' => ':angel:',

    //happy
    ':)' => ':happy:',
    '(:' => ':happy:',
    ':-)' => ':happy:',
    '(-:' => ':happy:',
    '=)' => ':happy:',

    //sad
    ':(' => ':sad:',
    ':-(' => ':sad:',
    ')-:' => ':sad:',

    //laughing
    ':D' => ':laughing:',
    ':-D' => ':laughing:',

    //laughing with closed eyes
    'xD' => ':laughingclosedeyes:',
    'XD' => ':laughingclosedeyes:',

    //cry
    //':\'(' => ':cry:',
    ':-\'(' => ':cry:',

    //cool
    '8-)' => ':cool:',
    '8)' => ':cool:',

    //wink
    ';)' => ':wink:',
    ';-)' => ':wink:',

    //weary
    //':/' => ':weary:',
    ':-/' => ':weary:',
    ':\\' => ':weary:',
    ':-\\' => ':weary:'
);

?>
