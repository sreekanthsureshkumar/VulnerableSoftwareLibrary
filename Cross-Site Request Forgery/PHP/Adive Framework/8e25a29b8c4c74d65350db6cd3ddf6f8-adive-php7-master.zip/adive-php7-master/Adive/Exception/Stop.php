<?php
namespace Adive\Exception;

class Stop extends \Exception
{
}
