 <?php
  require_once ("../include/initialize.php");
   if (!isset($_SESSION['CVCodeNo'])){
      redirect(web_root."vote/index.php?view=login");
     }
 ?> 

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Vote | SSG Event Tallying</title>
    
    <!-- core CSS -->
    <link href="<?php echo web_root; ?>css/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo web_root; ?>css/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo web_root; ?>css/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo web_root; ?>css/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo web_root; ?>css/css/main.css" rel="stylesheet">
    <link href="<?php echo web_root; ?>css/css/responsive.css" rel="stylesheet"> 
	<link href="<?php echo web_root; ?>font-awesome/css/font-awesome.min.css" rel="stylesheet"> 
	<link href="<?php echo web_root; ?>css/dataTables.bootstrap.css" rel="stylesheet"> 
	<!-- datetime picker CSS -->   
	<link rel="stylesheet" href="<?php echo web_root; ?>select2/select2.min.css"> 

 	<div class="col-lg-4 row" style="float-left"><img src="../img/sclogo.png"></div>
</head><!--/head--> 

<body class="homepage" >
 
 <section id="feature" class="transparent-bg">
        <div class="container">
           <div class=" row center wow fadeInDown">
            <h2 class="">Vote Now</h2> 
           </div>

            <div class="row">
                <div class="features">

                 <div class="col-lg-6"> 
                 <!-- 	<div class="col-lg-2" style="float-left">
                 		<img src="../img/sclogo.png" style="width:100px;height:100px;">
                 	</div>
                 	<div class="col-lg-2" style="float-left">
                 		<img src="../img/sclogo.png" style="width:100px;height:100px;">
                 	</div> -->

                 </div> 
                 <div class="col-lg-6"> 
           

                        <form class="form-horizontal span6 " action="controller.php?action=votingproccess" method="POST"> 
                             <div class="form-group">
                              <div class="col-md-12">
                                <label class="col-md-4 control-label" for=
                                "President">President :</label>

                                <div class="col-md-8">

                                  <select class="form-control select2" name="President">
                                    <option value="">Select</option>
                                      <?php 
                                          $query = "SELECT * FROM `tblstudent` s , `tblcandidate` c WHERE s.`StudentID`=c.`StudentID` AND DATE_FORMAT( `RunningDate` , '%Y' )= DATE_FORMAT(NOW() , '%Y' ) AND `Position`='President'";
                                          $mydb->setQuery($query);
                                          $cur = $mydb->loadResultList();

                                        foreach ($cur as $result) {
                                          echo '<option value='.$result->StudentID.'>'.$result->Lastname.', '.$result->Firstname.'</option>';

                                        }
                                        ?>
                                  </select>
                                   
                                </div>
                              </div>
                            </div>
 
                            <div class="form-group">
                              <div class="col-md-12">
                                <label class="col-md-4 control-label" for=
                                "VicePresident">Vice-President:</label>

                                <div class="col-md-8">
                                    <select class="form-control select2" name="VicePresident">
                                    <option value="">Select</option>
                                      <?php 
                                          $query = "SELECT * FROM `tblstudent` s , `tblcandidate` c WHERE s.`StudentID`=c.`StudentID` AND DATE_FORMAT( `RunningDate` , '%Y' )= DATE_FORMAT(NOW() , '%Y' ) AND `Position`='Vice-President'";
                                          $mydb->setQuery($query);
                                          $cur = $mydb->loadResultList();

                                        foreach ($cur as $result) {
                                          echo '<option value='.$result->StudentID.'>'.$result->Lastname.', '.$result->Firstname.'</option>';

                                        }
                                        ?>
                                  </select>
                                  
                                </div>
                              </div>
                            </div>


 
                             <div class="form-group">
                              <div class="col-md-12">
                                <label class="col-md-4 control-label" for=
                                "Secretary">Secretary:</label>
           
                                <div class="col-md-8">
                                    <select class="form-control select2" name="Secretary">
                                    <option value="">Select</option>
                                      <?php 
                                          $query = "SELECT * FROM `tblstudent` s , `tblcandidate` c WHERE s.`StudentID`=c.`StudentID` AND DATE_FORMAT( `RunningDate` , '%Y' )= DATE_FORMAT(NOW() , '%Y' ) AND `Position`='Secretary'";
                                          $mydb->setQuery($query);
                                          $cur = $mydb->loadResultList();

                                        foreach ($cur as $result) {
                                          echo '<option value='.$result->StudentID.'>'.$result->Lastname.', '.$result->Firstname.'</option>';

                                        }
                                        ?>
                                  </select>
                                </div>
                              </div>
                            </div> 

                            <div class="form-group">
                              <div class="col-md-12">
                                <label class="col-md-4 control-label" for=
                                "Treasurer">Treasurer:</label>

                                <div class="col-md-8">
                                  <select class="form-control select2" name="Treasurer">
                                    <option value="">Select</option>
                                      <?php 
                                          $query = "SELECT * FROM `tblstudent` s , `tblcandidate` c WHERE s.`StudentID`=c.`StudentID` AND DATE_FORMAT( `RunningDate` , '%Y' )= DATE_FORMAT(NOW() , '%Y' ) AND `Position`='Treasurer'";
                                          $mydb->setQuery($query);
                                          $cur = $mydb->loadResultList();

                                        foreach ($cur as $result) {
                                          echo '<option value='.$result->StudentID.'>'.$result->Lastname.', '.$result->Firstname.'</option>';

                                        }
                                        ?>
                                  </select>
                                </div>
                              </div>
                            </div>  


                          <div class="form-group">
                              <div class="col-md-12">
                                <label class="col-md-4 control-label" for=
                                "Senator1">Senators 1:</label>

                                
                                <div class="col-md-8">
                                   <select class="form-control select2" name="senator1" id="senator1">
                                    <option value="">Select</option>
                                      <?php 
                                          $query = "SELECT * FROM `tblstudent` s , `tblcandidate` c WHERE s.`StudentID`=c.`StudentID` AND DATE_FORMAT( `RunningDate` , '%Y' )= DATE_FORMAT(NOW() , '%Y' ) AND `Position`='Senator'";
                                          $mydb->setQuery($query);
                                          $cur = $mydb->loadResultList();

                                        foreach ($cur as $result) {
                                          echo '<option value='.$result->StudentID.'>'.$result->Lastname.', '.$result->Firstname.'</option>';

                                        }
                                        ?>
                                  </select>
                                </div>
                              </div>
                            </div>  
                            <div class="form-group sens2" id="sens22"> 
                            </div>
                            <div class="form-group sens3" id="sens3">
                            </div>
                            <div class="form-group sens4" id="sens4">
                            </div>
                            <div class="form-group sens5" id="sens_55">
                            </div>
                            <div class="form-group sens6" id="sens_66">
                            </div>
                            <div class="form-group sens7" id="sens_77">
                            </div>
                            <div class="form-group sens8" id="sens_88"> 
                            </div> 
                        <div class="form-group">
                        <div class="col-md-12">
                          <label class="col-md-4 control-label" for=
                          "idno"></label>

                          <div class="col-md-8">
                           <button class="btn btn-primary btn-sm" name="save" type="submit" ><span class="fa fa-save fw-fa"></span>  Save</button> 
                              <!-- <a href="index.php" class="btn btn-info"><span class="fa fa-arrow-circle-left fw-fa"></span></span>&nbsp;<strong>List of Users</strong></a> -->
                           </div>
                        </div>
                        </div> 
                  </form>
       
                 
                 </div> 


                </div><!--/.services-->
            </div><!--/.row-->  
        </div><!--/.container-->
    </section><!--/#feature-->
                     
    <footer id="footer" class="midnight-blue" style="background-color:#663399">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2017 <a target="_blank" href="<?php echo web_root; ?>" title="Free Twitter Bootstrap WordPress Themes and HTML templates">SSG Events Tallying System</a>. All Rights Reserved.
                </div>
 
            </div>
        </div>
    </footer><!--/#footer-->

 
<script src="../jquery/jquery.min.js"></script> 
<script src="../js/bootstrap.min.js"></script>
  
    <!-- DataTables JavaScript --> 
<script src="../select2/select2.full.min.js"></script> 
 
<script src="../js/selectsenators.js"></script> 

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->

<script type="text/javascript" > 
     $(function () {
         $(".select2").select2();
     });
</script> 

</body>
</html>
