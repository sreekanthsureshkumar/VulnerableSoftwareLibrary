    </div>
  </div>
  <div id="footer"><div id="footer_box">感谢使用 <a href="#">MiniCMS</a> 进行创作<span>v<?php echo $mc_config['version']; ?></span></div></div>
</body>
</html>
