<?php

class GroupList extends _GroupList
{
  
  
}


