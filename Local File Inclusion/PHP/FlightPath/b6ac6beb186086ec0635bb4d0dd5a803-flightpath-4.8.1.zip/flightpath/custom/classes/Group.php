<?php


class Group extends _Group
{
  
  
}

