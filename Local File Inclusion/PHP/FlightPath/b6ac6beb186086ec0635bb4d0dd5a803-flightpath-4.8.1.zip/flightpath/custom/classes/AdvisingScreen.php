<?php

class AdvisingScreen extends _AdvisingScreen
{
  
  
}