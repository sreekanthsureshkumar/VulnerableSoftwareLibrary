<?php


class DegreePlan extends _DegreePlan
{
  
  
  
}

