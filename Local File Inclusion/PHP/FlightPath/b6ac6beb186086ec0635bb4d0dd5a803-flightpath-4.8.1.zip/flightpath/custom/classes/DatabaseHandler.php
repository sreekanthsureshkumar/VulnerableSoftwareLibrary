<?php

class DatabaseHandler extends _DatabaseHandler
{

}

