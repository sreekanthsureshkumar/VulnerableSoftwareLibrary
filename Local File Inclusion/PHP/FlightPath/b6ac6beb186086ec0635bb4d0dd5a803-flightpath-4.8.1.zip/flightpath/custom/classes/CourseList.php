<?php

class CourseList extends _CourseList
{
  
  
  
}

