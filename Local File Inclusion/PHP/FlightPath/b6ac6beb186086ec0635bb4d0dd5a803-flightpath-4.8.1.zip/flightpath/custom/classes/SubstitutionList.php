<?php

class SubstitutionList extends _SubstitutionList
{
  
  
}


