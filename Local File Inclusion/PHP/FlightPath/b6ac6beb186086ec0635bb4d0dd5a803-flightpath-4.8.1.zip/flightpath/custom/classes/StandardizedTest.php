<?php


class StandardizedTest extends _StandardizedTest
{
  
  
  
}


