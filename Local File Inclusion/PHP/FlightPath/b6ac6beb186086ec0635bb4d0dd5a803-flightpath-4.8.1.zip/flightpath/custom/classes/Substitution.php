<?php

class Substitution extends _Substitution
{
  
  
}


