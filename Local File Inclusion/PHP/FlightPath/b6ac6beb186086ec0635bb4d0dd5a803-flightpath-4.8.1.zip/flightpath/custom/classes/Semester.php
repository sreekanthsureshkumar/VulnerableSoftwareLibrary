<?php

class Semester extends _Semester
{
  
  
  
}



