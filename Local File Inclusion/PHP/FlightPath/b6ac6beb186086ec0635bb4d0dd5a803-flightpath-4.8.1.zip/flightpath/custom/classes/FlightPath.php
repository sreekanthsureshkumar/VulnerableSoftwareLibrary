<?php


class FlightPath extends _FlightPath
{
  
  
  
}

