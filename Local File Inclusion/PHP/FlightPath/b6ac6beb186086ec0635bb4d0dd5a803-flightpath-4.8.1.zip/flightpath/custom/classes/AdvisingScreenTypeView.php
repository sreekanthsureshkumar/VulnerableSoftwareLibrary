<?php

class AdvisingScreenTypeView extends _AdvisingScreenTypeView
{	
  
  
  
}
