<?php
class Course extends _Course
{
  
  
}  // end of class



