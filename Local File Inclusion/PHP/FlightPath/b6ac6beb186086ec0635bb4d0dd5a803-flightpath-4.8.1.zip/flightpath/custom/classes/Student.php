<?php

class Student extends _Student
{


	
	
	
  
}

