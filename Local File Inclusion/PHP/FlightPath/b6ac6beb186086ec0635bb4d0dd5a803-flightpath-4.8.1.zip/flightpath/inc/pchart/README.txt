This directory contains a portion of the pChart library, an excellent GPLv3
library for creating pie charts in PHP.

For more information, visit: http://pchart.net