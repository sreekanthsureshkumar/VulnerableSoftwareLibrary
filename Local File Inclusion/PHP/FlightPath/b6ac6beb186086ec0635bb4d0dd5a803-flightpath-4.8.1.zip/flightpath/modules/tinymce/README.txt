TinyMCE FlightPath Module
=========================

Though this module is included with the FlightPath software system, the editor itself
was not programmed by any member of the FlightPath production team.

For more information about the TinyMCE module, and to see its license information,
visit http://tinymce.com