README File for Batch API module
================================

For instructions on this module's use (which appeals primarily to developers), search
FlightPath's documentation: http://getflightpath.com/node/1121




====================
Testing and Examples
====================

To demonstrate how the Batch process works, a test has been created as an example.

As admin, visit example.com/batch-test-form to see it in action.

View the source code file batch.test.inc for the documented working example.