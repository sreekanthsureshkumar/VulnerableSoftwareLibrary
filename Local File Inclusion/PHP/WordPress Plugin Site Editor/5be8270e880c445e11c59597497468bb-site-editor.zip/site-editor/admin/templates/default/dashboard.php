<div id="sed_admin_dashboard_settings" class="sed_dashboard_settings">

<p class="sed_dashboard_settings_content"> <?php echo __("Congratulations! You're running SiteEditor. SiteEditor is the most powerful frontend editor for WordPress. You can build your pages and your theme via the visual frontend editor very fast and easy." , "site-editor"); ?> </p>

</div>