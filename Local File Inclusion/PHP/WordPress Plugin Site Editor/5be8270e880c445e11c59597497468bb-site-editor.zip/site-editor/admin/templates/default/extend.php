<div class="wrap">
        <hr>
        <div id="sed_admin_settings_head">
            <H1><?php _e('SiteEditor Extensions' , 'site-editor')?></H1>
        </div>
        <div id="sed_extensions_container">
            <p>
            <?php
            $etend_url = "http://www.siteeditor.org/extensions";
            echo sprintf( __('Now SiteEditor is included more than 90 free and premium modules , you can downloaded <a href="%s">here</a>' , 'site-editor') , esc_url( $etend_url ) );
            ?>
            </p>
        </div>
</div>