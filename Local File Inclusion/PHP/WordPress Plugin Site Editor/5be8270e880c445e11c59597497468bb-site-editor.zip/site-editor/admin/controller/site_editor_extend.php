<?php

Class site_editor_extendController Extends baseController {

    public function index() {

        $this->registry->template->show('extend');
    }

}