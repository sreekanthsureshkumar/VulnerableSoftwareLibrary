
(function( exports, $ ) {

    var api = sedApp.editor ;

    api.AppPreset = api.Class.extend({


    });

    $( function() {

        api.appPreset = new api.AppPreset({});

    });

}(sedApp, jQuery));