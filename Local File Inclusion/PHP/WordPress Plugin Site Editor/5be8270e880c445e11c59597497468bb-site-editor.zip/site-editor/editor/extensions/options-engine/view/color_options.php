<div class="sed-color-options">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_color_options"  title="<?php echo __("Color Scheme","site-editor");  ?>" role="button" >
        <span class="sedico sedico-color-scheme sedico-2x "></span> 
        <span class="el_txt"><?php echo __("Color Scheme","site-editor");  ?></span>
    </a>

</div>