<div class="sed-theme-options">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_theme_options"  title="<?php echo __("Theme Options","site-editor");  ?>" role="button" >
        <span class="sedico sedico-theme-options sedico-2x "></span>
        <span class="el_txt"><?php echo __("Theme Options","site-editor");  ?></span>
    </a>

</div>