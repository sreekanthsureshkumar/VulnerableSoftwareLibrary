<div class="sed-customize-post-settings">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn sed_customize_post_settings_btn" data-setting-id="sed_post_options"  title="<?php echo __("Current Post Customize","site-editor");  ?>" role="button" >
        <span class="sedico sedico-current-post-customize sedico-2x "></span>
        <span class="el_txt"><?php echo __("Current Post Customize","site-editor");  ?></span>
    </a>
</div>