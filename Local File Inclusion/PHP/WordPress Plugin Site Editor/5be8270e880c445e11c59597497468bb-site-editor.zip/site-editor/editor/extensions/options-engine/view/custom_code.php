<div class="sed-custom-code-settings">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="custom_code"  title="<?php echo __("Custom Code","site-editor");  ?>" id="custom_code_settings_btn" role="button" >
        <span class="sedico sedico-custom-code sedico-2x"></span>
        <span class="el_txt"><?php echo __("Custom Code","site-editor");  ?></span>
    </a>
</div>