<div class="sed-site-custom-css-settings">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="site_custom_css"  title="<?php echo __("Site Custom Css","site-editor");  ?>" id="site_custom_css_settings_btn" role="button" >
        <span class="sedico sedico-site-custom-css sedico-2x"></span>
        <span class="el_txt"><?php echo __("Site Custom Css","site-editor");  ?></span>
    </a>
</div> 