<div class="sed-page-general-settings">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_page_options"  title="<?php echo __("Page Options","site-editor");  ?>" id="page_general_settings_btn" role="button" >
        <span class="sedico sedico-page sedico-2x "></span>
        <span class="el_txt"><?php echo __("Page Settings","site-editor");  ?></span>
    </a> 
</div> 