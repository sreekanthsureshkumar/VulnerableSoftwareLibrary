<div class="sed-sample-options-demo">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_sample_options"  title="<?php echo __("Sample Options","site-editor");  ?>" id="sed_sample_demo_options" role="button" >
        <span class="sedico sedico-sample-options sedico-2x "></span>
        <span class="el_txt"><?php echo __("Sample Options","site-editor");  ?></span>
    </a>
</div>