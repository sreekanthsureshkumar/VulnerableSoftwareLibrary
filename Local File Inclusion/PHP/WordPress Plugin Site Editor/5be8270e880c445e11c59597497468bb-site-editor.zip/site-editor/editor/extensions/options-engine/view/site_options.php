<div class="sed-site-general-settings">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_site_options"  title="<?php echo __("Site Settings","site-editor");  ?>" id="general_site_settings_btn" role="button" >
        <span class="sedico sedico-settings sedico-2x "></span>
        <span class="el_txt"><?php echo __("Site Settings","site-editor");  ?></span>
    </a>
</div>
