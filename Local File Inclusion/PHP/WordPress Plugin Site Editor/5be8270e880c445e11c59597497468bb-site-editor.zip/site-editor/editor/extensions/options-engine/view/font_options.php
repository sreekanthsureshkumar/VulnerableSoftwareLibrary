<div class="sed-font-options">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_typography_options"  title="<?php echo __("Typography","site-editor");  ?>" role="button" >
        <span class="sedico sedico-typography sedico-2x "></span>
        <span class="el_txt"><?php echo __("Typography","site-editor");  ?></span>
    </a>
</div>