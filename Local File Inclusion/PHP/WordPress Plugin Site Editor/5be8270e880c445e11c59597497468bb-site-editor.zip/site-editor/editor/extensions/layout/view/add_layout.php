<div class="add-new-layout">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_add_layout"  title="<?php echo __("Layouts Manager","site-editor");  ?>" id="sed_add_page_layout" role="button" >
        <span class="sedico sedico-add-layout sedico-2x "></span>
        <span class="el_txt"><?php echo __("Layouts Manager","site-editor");  ?></span>
    </a> 
</div>