<div class="layout-sub-themes-settings">
    <a href="javascript:void(0)" class="btn btn-default3 sed_ajax_load_options_btn" data-setting-id="sed_pages_layouts"   title="<?php echo __("Layout settings","site-editor");  ?>" role="button" >
        <span class="sedico sedico-layout sedico-2x "></span>
        <span class="el_txt"><?php echo __("Layout settings","site-editor");  ?></span>
    </a> 
</div>