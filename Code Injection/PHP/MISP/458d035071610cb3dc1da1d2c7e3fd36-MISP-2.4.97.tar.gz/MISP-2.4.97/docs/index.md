# Welcome to the official MISP Install Guides

On the following pages you will find stock install instructions for getting a base MISP system running.

For full documentation visit [misp-book](https://www.circl.lu/doc/misp/).

[![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/fold_left.svg?style=social&label=Follow%20%40MISPProject)](https://twitter.com/MISPProject)

!!! note
    #### INSTALL Guides...
    ##### ... are stable and tested INSTALL guides.
    #### xINSTALL Guides...
    ##### ... are eXperimental guides that might be tested or not.
    #### Config Guides...
    ##### ... are CONFIGuration guides and not full blown INSTALL guides.
