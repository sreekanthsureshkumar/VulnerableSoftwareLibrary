This is a draft mascot by Marijke Wilms that has not passed QA.
