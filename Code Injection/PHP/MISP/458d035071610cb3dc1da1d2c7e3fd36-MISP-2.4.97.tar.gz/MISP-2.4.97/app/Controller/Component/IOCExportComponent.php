<?php

class IOCExportComponent extends Component
{
    // removed in favour of th IOCExportTool
    // File used as a placeholder to avoid model caching issues
}
