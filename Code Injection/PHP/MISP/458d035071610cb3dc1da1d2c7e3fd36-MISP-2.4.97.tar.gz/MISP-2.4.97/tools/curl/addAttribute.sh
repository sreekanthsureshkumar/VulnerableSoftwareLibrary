curl -i -H "Accept: application/xml" -H "content-type: application/xml" -H "Authorization: vlf4o42bYSVVWLm28jLB85my4HBZWXTri8vGdySb" \
--data "@input/attribute.xml" -X POST http://localhost/attributes

#curl -i -H "Accept: application/json" -H "content-type: application/json" -H "Authorization: vlf4o42bYSVVWLm28jLB85my4HBZWXTri8vGdySb" \
#--data "@input/attribute.xml" -X POST http://localhost/attributes
